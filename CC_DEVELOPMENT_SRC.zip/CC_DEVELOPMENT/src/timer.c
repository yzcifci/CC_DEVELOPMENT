/*
 * timer.c
 *
 *  Created on: 25 Ara 2017
 *      Author: yzcifci
 */

#include "main.h"

struct timerControl_ timerControl;
uint32_t uwPrescalerValue = 1000;

TIM_HandleTypeDef TimHandleStep;
TIM_HandleTypeDef TimX;
TIM_HandleTypeDef TimY;
TIM_HandleTypeDef TimE;
TIM_HandleTypeDef TimHandleGlobal;

uint8_t lockx=0;
uint8_t locky=0;
uint8_t locke=0;
uint8_t lockm=0;

void initTimer()
{
	memset(&timerControl,0x0,sizeof(timerControl));

	timerControl.moveCallBack= (moveCallBack_)moveTaskIdle;
	timerControl.moveCallBackX= (moveCallBack_)moveTaskIdle;
	timerControl.moveCallBackY= (moveCallBack_)moveTaskIdle;
	timerControl.moveCallBackZ= (moveCallBack_)moveTaskIdle;
	timerControl.moveCallBackE= (moveCallBack_)moveTaskIdle;

	TimHandleStep.Instance = TIM_STEP;
	TimHandleStep.Init.Period = 65040;		//100 us period
	TimHandleStep.Init.Prescaler = 123;
	TimHandleStep.Init.ClockDivision = 0;
	TimHandleStep.Init.CounterMode = TIM_COUNTERMODE_UP;
	if(HAL_TIM_Base_Init(&TimHandleStep) != HAL_OK)
	{
		Error_Handler();
	}
	if(HAL_TIM_Base_Start_IT(&TimHandleStep) != HAL_OK)
	{
		Error_Handler();
	}
	setStepTimT(MULT_FACTOR*1);

	/*timerX*/
	TimX.Instance = TIM_X;
	TimX.Init.Period = 65040;		//100 us period
	TimX.Init.Prescaler = 123;
	TimX.Init.ClockDivision = 0;
	TimX.Init.CounterMode = TIM_COUNTERMODE_UP;
	if(HAL_TIM_Base_Init(&TimX) != HAL_OK)	Error_Handler();
	if(HAL_TIM_Base_Start_IT(&TimX) != HAL_OK)Error_Handler();
	setTX(MULT_FACTOR*1);


	/*timerY*/
	TimY.Instance = TIM_Y;
	TimY.Init.Period = 65040;
	TimY.Init.Prescaler = 123;
	TimY.Init.ClockDivision = 0;
	TimY.Init.CounterMode = TIM_COUNTERMODE_UP;
	if(HAL_TIM_Base_Init(&TimY) != HAL_OK)	Error_Handler();
	if(HAL_TIM_Base_Start_IT(&TimY) != HAL_OK)Error_Handler();
	setTY(MULT_FACTOR*1);

	/*timerE*/
	TimE.Instance = TIM_E;
	TimE.Init.Period = 65040;
	TimE.Init.Prescaler = 123;
	TimE.Init.ClockDivision = 0;
	TimE.Init.CounterMode = TIM_COUNTERMODE_UP;
	if(HAL_TIM_Base_Init(&TimE) != HAL_OK)	Error_Handler();
	if(HAL_TIM_Base_Start_IT(&TimE) != HAL_OK)Error_Handler();
	setTE(MULT_FACTOR*1);

	/*GLOBAL TIMER*/
	TimHandleGlobal.Instance = TIM_GLOBAL;
	TimHandleGlobal.Init.Period =65040;
	TimHandleGlobal.Init.Prescaler = 123;
	TimHandleGlobal.Init.ClockDivision = 0;
	TimHandleGlobal.Init.CounterMode = TIM_COUNTERMODE_UP;
	if(HAL_TIM_Base_Init(&TimHandleGlobal) != HAL_OK)
	{
		Error_Handler();
	}
	if(HAL_TIM_Base_Start_IT(&TimHandleGlobal) != HAL_OK)
	{
		Error_Handler();
	}
	setGlobalTimT(0.001*MULT_FACTOR);

}

void setTimStepCallBack(uint32_t add)
{
	timerControl.moveCallBack=(moveCallBack_)add;
}

void setTimX(uint32_t add)
{
	timerControl.moveCallBackX=(moveCallBack_)add;
}

void setTimY(uint32_t add)
{
	timerControl.moveCallBackY=(moveCallBack_)add;
}

void setTimZ(uint32_t add)
{
	timerControl.moveCallBackZ=(moveCallBack_)add;
}

void setTimE(uint32_t add)
{
	timerControl.moveCallBackE=(moveCallBack_)add;
}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance==TIM_STEP)
	{
		timerControl.stepCntr++;
	}
	else if(htim->Instance==TIM_GLOBAL)
	{
		timerControl.globalCntr++;
		periodicGlobal1msCallBack();
		if(timerControl.moveCallBackZ()==TASK_COMPLETED)
		{
			taskControl.taskStatus=TASK_COMPLETED;
			tailUpdateControl();
			taskOperatorControl();
		}
	}

}


void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htim)
{
	if(htim->Instance==TIM_STEP)
	{
		__HAL_RCC_TIM7_CLK_ENABLE();
		HAL_NVIC_SetPriority(TIM_STEP_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(TIM_STEP_IRQn);
	}
	else if(htim->Instance==TIM_X)
	{
		__HAL_RCC_TIM2_CLK_ENABLE();
		HAL_NVIC_SetPriority(TIM_X_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(TIM_X_IRQn);
	}

	else if(htim->Instance==TIM_Y)
	{
		__HAL_RCC_TIM4_CLK_ENABLE();
		HAL_NVIC_SetPriority(TIM_Y_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(TIM_Y_IRQn);
	}

	else if(htim->Instance==TIM_E)
	{
		__HAL_RCC_TIM5_CLK_ENABLE();
		HAL_NVIC_SetPriority(TIM_E_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(TIM_E_IRQn);
	}
	else if(htim->Instance==TIM_GLOBAL)
	{
		__HAL_RCC_TIM3_CLK_ENABLE();
		HAL_NVIC_SetPriority(TIM_GLOBAL_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(TIM_GLOBAL_IRQn);
	}
}

void TIM_STEP_IRQHandler()
{


	HAL_TIM_IRQHandler(&TimHandleStep);
	if(lockm==1)
	{
		lockm=0;
		return;
	}
	if(timerControl.moveCallBack()==TASK_COMPLETED)
	{
		taskControl.taskStatus=TASK_COMPLETED;
		tailUpdateControl();
		taskOperatorControl();
	}
}

void TIM_X_IRQHandler()
{
	TIM_X->SR = ~(TIM_IT_UPDATE);
	if(lockx==1)
	{
		lockx=0;
		return;
	}
	if(timerControl.moveCallBackX()==TASK_COMPLETED)
	{
		taskControl.taskStatus=TASK_COMPLETED;
		tailUpdateControl();
		taskOperatorControl();
	}
}

void TIM_Y_IRQHandler()
{
	TIM_Y->SR = ~(TIM_IT_UPDATE);
	if(locky==1)
	{
		locky=0;
		return;
	}
	if(timerControl.moveCallBackY()==TASK_COMPLETED)
	{
		taskControl.taskStatus=TASK_COMPLETED;
		tailUpdateControl();
		taskOperatorControl();
	}
}


void TIM_E_IRQHandler()
{
	TIM_E->SR = ~(TIM_IT_UPDATE);
	if(locke==1)
	{
		locke=0;
		return;
	}
	if(timerControl.moveCallBackE()==TASK_COMPLETED)
	{
		taskControl.taskStatus=TASK_COMPLETED;
		tailUpdateControl();
		taskOperatorControl();
	}
}


void TIM_GLOBAL_IRQHandler()
{
	HAL_TIM_IRQHandler(&TimHandleGlobal);
}


void setStepTimT(float t)
{
	uint32_t timeoft=(SystemCoreClock*t)/(2*MULT_FACTOR); // kac adet clock cycle gerekli
	uint32_t div=timeoft/65535;
	uint32_t PSC=div+1;
	if(PSC==1)PSC=2;
	uint32_t ARR=timeoft/PSC;
	if(ARR==0)ARR=1;

	TIM_STEP->CNT=0;
	TIM_STEP->PSC=PSC-1;
	TIM_STEP->ARR=ARR;
	lockm=1;
	TIM_STEP->EGR|=1;
}

void setTX(float t)
{
	uint32_t timeoft=(SystemCoreClock*t)/(2*MULT_FACTOR); // kac adet clock cycle gerekli
	uint32_t div=timeoft/65535;
	uint32_t PSC=div+1;
	if(PSC==1)PSC=2;
	uint32_t ARR=timeoft/PSC;
	if(ARR==0)ARR=1;

	TIM_X->CNT=0;
	TIM_X->PSC=PSC-1;
	TIM_X->ARR=ARR;
	lockx=1;
	TIM_X->EGR|=1;
}

void setTY(float t)
{
	uint32_t timeoft=(SystemCoreClock*t)/(2*MULT_FACTOR); // kac adet clock cycle gerekli
	uint32_t div=timeoft/65535;
	uint32_t PSC=div+1;
	if(PSC==1)PSC=2;
	uint32_t ARR=timeoft/PSC;
	if(ARR==0)ARR=1;

	TIM_Y->CNT=0;
	TIM_Y->PSC=PSC-1;
	TIM_Y->ARR=ARR;
	locky=1;
	TIM_Y->EGR|=1;
}

void setTE(float t)
{
	uint32_t timeoft=(SystemCoreClock*t)/(2*MULT_FACTOR); // kac adet clock cycle gerekli
	uint32_t div=timeoft/65535;
	uint32_t PSC=div+1;
	if(PSC==1)PSC=2;
	uint32_t ARR=timeoft/PSC;
	if(ARR==0)ARR=1;

	TIM_E->CNT=0;
	TIM_E->PSC=PSC-1;
	TIM_E->ARR=ARR;
	locke=1;
	TIM_E->EGR|=1;
}

void setGlobalTimT(float t)
{
	uint32_t timeoft=(SystemCoreClock*t)/(2*MULT_FACTOR); // kac adet clock cycle gerekli
	uint32_t div=timeoft/65535;
	uint32_t PSC=div+1;
	if(PSC==1)PSC=2;
	uint32_t ARR=timeoft/PSC;

	TIM_GLOBAL->PSC=PSC-1;
	TIM_GLOBAL->ARR=ARR;
	TIM_GLOBAL->CNT=0;
	TIM_GLOBAL->EGR|=1;
}

void periodicGlobal1msCallBack()
{
	taskOperatorControl();
	if((timerControl.globalCntr%100)==0)periodicGlobal100msCallBack();
	if((timerControl.globalCntr%500)==0)periodicGlobal500msCallBack();

	tempBedPWMOutCntrl();
	tempExtPWMOutCntrl();
}

void periodicGlobal100msCallBack()
{
	periodicADCConvertCall();
}

void periodicGlobal500msCallBack()
{
	toggleWorkingLed();
}



/**
 * @brief  This function is executed in case of error occurrence.
 * @param  None
 * @retval None
 */
void Error_Handler(void)
{
	/* Turn LED3 on */
	//  BSP_LED_On(LED3);
	while(1)
	{
	}
}

void timerError(uint16_t index)
{
	systemOFF();
	while(1);
}
