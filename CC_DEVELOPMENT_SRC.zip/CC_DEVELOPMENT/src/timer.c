/*
 * timer.c
 *
 *  Created on: 25 Ara 2017
 *      Author: yzcifci
 */

#include "timer.h"
#include "task_operator_interface.h"

struct timerControl_ timerControl;
uint32_t uwPrescalerValue = 1000;

TIM_HandleTypeDef TimHandleStep;
TIM_HandleTypeDef TimHandleGlobal;

uint8_t tempLock=0;

void initTimer()
{



	timerControl.moveCallBack= (moveCallBack_)moveTaskIdle;

	TimHandleStep.Instance = TIM_STEP;
	TimHandleStep.Init.Period = 1;		//100 us period
	TimHandleStep.Init.Prescaler = uwPrescalerValue;
	TimHandleStep.Init.ClockDivision = 0;
	TimHandleStep.Init.CounterMode = TIM_COUNTERMODE_UP;
	if(HAL_TIM_Base_Init(&TimHandleStep) != HAL_OK)
	{
		Error_Handler();
	}
	if(HAL_TIM_Base_Start_IT(&TimHandleStep) != HAL_OK)
	{
		Error_Handler();
	}


	setStepTimT(MULT_FACTOR*1);

	TimHandleGlobal.Instance = TIM_GLOBAL;
	TimHandleGlobal.Init.Period = 1;		//100 us period
	TimHandleGlobal.Init.Prescaler = uwPrescalerValue;
	TimHandleGlobal.Init.ClockDivision = 0;
	TimHandleGlobal.Init.CounterMode = TIM_COUNTERMODE_UP;
	if(HAL_TIM_Base_Init(&TimHandleGlobal) != HAL_OK)
	{
		Error_Handler();
	}
	if(HAL_TIM_Base_Start_IT(&TimHandleGlobal) != HAL_OK)
	{
		Error_Handler();
	}
	setGlobalTimT(0.001*MULT_FACTOR);
	memset(&timerControl,0x0,sizeof(timerControl));
}

void setTimStepCallBack(uint32_t add)
{
	timerControl.moveCallBack=(moveCallBack_)add;
}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance==TIM_STEP)
	{
		timerControl.stepCntr++;
	}
	else if(htim->Instance==TIM_GLOBAL)
	{
		timerControl.globalCntr++;
		taskOperatorControl();
	}

}


void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htim)
{
	if(htim->Instance==TIM_STEP)
	{
		__HAL_RCC_TIM7_CLK_ENABLE();
		HAL_NVIC_SetPriority(TIM_STEP_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(TIM_STEP_IRQn);
	}
	else if(htim->Instance==TIM_GLOBAL)
	{
		__HAL_RCC_TIM3_CLK_ENABLE();
		HAL_NVIC_SetPriority(TIM_GLOBAL_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(TIM_GLOBAL_IRQn);
	}
}

void TIM_STEP_IRQHandler()
{

	HAL_TIM_IRQHandler(&TimHandleStep);
	if(tempLock==1)
	{
		tempLock=0;
		return;
	}
	if(timerControl.moveCallBack()==TASK_COMPLETED)
	{
		taskControl.taskStatus=TASK_COMPLETED;
		tailUpdateControl();
		taskOperatorControl();
	}
}


void TIM_GLOBAL_IRQHandler()
{

	HAL_TIM_IRQHandler(&TimHandleGlobal);
}




void setStepTimT(float t)
{
	uint32_t timeoft=(SystemCoreClock*t)/(2*MULT_FACTOR); // kac adet clock cycle gerekli
	uint32_t div=timeoft/65535;
	uint32_t PSC=div+1;
	if(PSC==1)PSC=2;
	uint32_t ARR=timeoft/PSC;
	if(ARR==0)ARR=1;

	TIM_STEP->CNT=0;
	TIM_STEP->PSC=PSC-1;
	TIM_STEP->ARR=ARR;
	tempLock=1;
	TIM_STEP->EGR|=1;
}


void setGlobalTimT(float t)
{
	uint32_t timeoft=(SystemCoreClock*t)/(2*MULT_FACTOR); // kac adet clock cycle gerekli
	uint32_t div=timeoft/65535;
	uint32_t PSC=div+1;
	if(PSC==1)PSC=2;
	uint32_t ARR=timeoft/PSC;

	TIM_GLOBAL->PSC=PSC-1;
	TIM_GLOBAL->ARR=ARR;
	TIM_GLOBAL->CNT=0;
	TIM_GLOBAL->EGR|=1;
}






/**
 * @brief  This function is executed in case of error occurrence.
 * @param  None
 * @retval None
 */
void Error_Handler(void)
{
	/* Turn LED3 on */
	//  BSP_LED_On(LED3);
	while(1)
	{
	}
}

void timerError(uint16_t index)
{
	systemOFF();
	while(1);


}
