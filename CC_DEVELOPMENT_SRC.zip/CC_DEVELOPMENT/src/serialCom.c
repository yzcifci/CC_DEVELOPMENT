/*
 * serialCom.c
 *
 *  Created on: 13 �ub 2018
 *      Author: yzcifci
 */


/*
 * uart.c
 *
 *  Created on: 18 Oca 2018
 *      Author: yzcifci
 */
#include "stm32f4xx_hal.h"
#include "task_operator_interface.h"


UART_HandleTypeDef UartHandle;

void initSerialCom()
{
	uartInit();
}
void uartInit()
{

	UartHandle.Instance = USART2;
	UartHandle.Init.BaudRate = 960000;
	UartHandle.Init.WordLength = UART_WORDLENGTH_8B;
	UartHandle.Init.StopBits = UART_STOPBITS_1;
	UartHandle.Init.Parity = UART_PARITY_NONE;
	UartHandle.Init.Mode = UART_MODE_TX_RX;
	UartHandle.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	UartHandle.Init.OverSampling = UART_OVERSAMPLING_16;

	if (HAL_UART_Init(&UartHandle) != HAL_OK)
	{
		driverError(SERIAL_PORT_INIT_ERROR);
	}

	__HAL_UART_ENABLE_IT(&UartHandle, UART_IT_RXNE) ;
}




void serialPrint(char *pData, uint16_t Size )
{
	HAL_UART_Transmit(&UartHandle, (uint8_t*)pData, Size, 5000);
//	HAL_Delay(1);
}

void printLine(char *data)
{
	uint32_t tickstart = 0U;

	tickstart = HAL_GetTick();
	while((*data)!=0)
	{
		if(UART_WaitOnFlagUntilTimeoutX(&UartHandle, UART_FLAG_TXE, RESET, tickstart, 50) != HAL_OK)
		{
			return ;
		}
		UartHandle.Instance->DR=*data++;
	}
}

void putChar(char data)
{
	uint32_t tickstart = 0U;
	tickstart = HAL_GetTick();
	if(UART_WaitOnFlagUntilTimeoutX(&UartHandle, UART_FLAG_TXE, RESET, tickstart, 5000) != HAL_OK)
	{
		return ;
	}
	UartHandle.Instance->DR=data;
}

void uartTest()
{
	while(1)
	{
		printLine("UART SENDING TEST MESSAGE\r\n");
		HAL_Delay(500);
	}
}

void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{

  GPIO_InitTypeDef GPIO_InitStruct;
  if(huart->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspInit 0 */

  /* USER CODE END USART2_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_USART2_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART2 GPIO Configuration
    PA2     ------> USART2_TX
    PA3     ------> USART2_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN USART2_MspInit 1 */

  /* USER CODE END USART2_MspInit 1 */
  }

}

void USART2_IRQHandler(void)
{
	char receiveData;

//  HAL_UART_IRQHandler(&UartHandle);
	receiveData=((UartHandle.Instance->DR)&0x000000ff);
//	serialLineParser(receiveData);
}

void driverError(uint8_t index)
{
	while(1);
}


HAL_StatusTypeDef UART_WaitOnFlagUntilTimeoutX(UART_HandleTypeDef *huart, uint32_t Flag, FlagStatus Status, uint32_t Tickstart, uint32_t Timeout)
{
  /* Wait until flag is set */
  while((__HAL_UART_GET_FLAG(huart, Flag) ? SET : RESET) == Status)
  {
    /* Check for the Timeout */
    if(Timeout != HAL_MAX_DELAY)
    {
      if((Timeout == 0U)||((HAL_GetTick() - Tickstart ) > Timeout))
      {
        /* Disable TXE, RXNE, PE and ERR (Frame error, noise error, overrun error) interrupts for the interrupt process */
        CLEAR_BIT(huart->Instance->CR1, (USART_CR1_RXNEIE | USART_CR1_PEIE | USART_CR1_TXEIE));
        CLEAR_BIT(huart->Instance->CR3, USART_CR3_EIE);

        huart->gState  = HAL_UART_STATE_READY;
        huart->RxState = HAL_UART_STATE_READY;

        /* Process Unlocked */
        __HAL_UNLOCK(huart);

        return HAL_TIMEOUT;
      }
    }
  }

  return HAL_OK;
}
