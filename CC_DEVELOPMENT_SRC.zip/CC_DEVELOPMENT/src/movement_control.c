/*
 * movement_control.c
 *
 *  Created on: 10 Oca 2018
 *      Author: yzcifci
 */

#include "movement_control.h"
#include "task_operator_interface.h"
#include "math.h"
struct taskOperatorPrepare_ taskOperatorPrepare;

struct taskOperator_ taskOperator;

void initTaskOperator()
{
	memset(&taskOperator, 0x0, sizeof(taskOperator));
	memset(&taskOperatorPrepare, 0x0, sizeof(taskOperatorPrepare));
}
void taskStart()
{
	switch(taskOperator.task)
	{
	case G00_RAPID_MOVEMENT:
		//todo

		startLinearInterPolation(taskOperator.currentPos.stepPosition,
				taskOperatorPrepare.linearInterPolationParameters.stopPos, MAXIMUM_START_STOP_FEED_RATE);
		taskOperator.currentTaskStatus=TASK_RUNNING;
		break;
	case G01_LINEAR_INTERPOLATION:
		//todo
		startLinearInterPolation(taskOperator.currentPos.stepPosition,
				taskOperatorPrepare.linearInterPolationParameters.stopPos,
				taskOperatorPrepare.linearInterPolationParameters.feedRate);
		taskOperator.currentTaskStatus=TASK_RUNNING;

		break;
	case G02_CIRCULAR_CW_INTERPOLATION:
	case G03_CIRCULAR_CCW_INTERPOLATION:
		startCircularInterpolation(taskOperator.currentPos.stepPosition,taskOperatorPrepare.circularInterPolationParameters.stopPos,
				taskOperatorPrepare.circularInterPolationParameters.centerPos,
				taskOperatorPrepare.circularInterPolationParameters.feedRate,
				taskOperatorPrepare.circularInterPolationParameters.direction);
		taskOperator.currentTaskStatus=TASK_RUNNING;
		break;
	case G90_ABSOLUTE_MODE_SELECT:
		break;
	case G91_INCREMENTAL_MODE_SELECT:
		break;

	case G17_XY_PLANE:
		taskOperator.currentTaskStatus=TASK_COMPLETED;
		break;
	case G40_CANCEL_RADIUS_COMPENSATION:
		taskOperator.currentTaskStatus=TASK_COMPLETED;
		break;
	case G49_CANCEL_LENGTH_COMPENSATION:
		taskOperator.currentTaskStatus=TASK_COMPLETED;
		break;

	case G64_CONSTANT_SPEED_MODE:
		taskOperator.currentTaskStatus=TASK_COMPLETED;
		break;
	case M_FUNCTION:
		taskOperator.currentTaskStatus=MfunctionExecuter(taskOperatorPrepare.MFUNCTIONtaskParameter);
		break;
	case SPEED:
		taskOperator.currentTaskStatus=setSpeedExecuter(taskOperatorPrepare.SPEEDparameter);
		break;
	case TOOL:
		taskOperator.currentTaskStatus=TASK_COMPLETED;
		break;
	default:
		break;
	}


}


/*
 * 100 us periodic call function
 */
void periodicMovementControl()
{

	taskController();
	if(taskOperator.currentTaskStatus!=TASK_RUNNING)return;
	switch(taskOperator.task)
	{
	case G00_RAPID_MOVEMENT:
		taskOperator.currentTaskStatus=linearInterPolationPeriodicCall();
		break;
	case G01_LINEAR_INTERPOLATION:
		taskOperator.currentTaskStatus=linearInterPolationPeriodicCall();
		break;
	case G02_CIRCULAR_CW_INTERPOLATION:
	case G03_CIRCULAR_CCW_INTERPOLATION:
		taskOperator.currentTaskStatus=circularInterPolationPeriodicCall();
		break;
	default:
		break;
	}
}


void taskController()
{
	if(taskQueueCheck())
	{
		updateLastTaskPosition();
		taskOperator.task=Gparser.parserControl.taskBuffer[++Gparser.parserControl.operatorIndex][0];
		taskOperator.taskSubIndex=Gparser.parserControl.taskBuffer[Gparser.parserControl.operatorIndex][1];
		getTaskParameters(taskOperator.task, taskOperator.taskSubIndex);
		taskStart();
	}
}


char taskQueueCheck()
{
	if((taskOperator.currentTaskStatus==TASK_COMPLETED) &&
			(operatorParserStateControl()!=OPERATOR_BUFFER_FULL)&&
		(Gparser.parserControl.taskParsestatus[Gparser.parserControl.operatorIndex+1]==TASK_PARSE_COMPLETED))
	{
		return 1;
	}
	return 0;
}


void completeTask()
{
	taskOperator.currentTaskStatus=TASK_COMPLETED;
}




void updateLastTaskPosition()
{
	switch(taskOperator.task)
	{
	case G00_RAPID_MOVEMENT:
		taskOperator.currentPos.stepPosition=linearInterPolationCurrentPos();
		break;
	case G01_LINEAR_INTERPOLATION:
		taskOperator.currentPos.stepPosition=linearInterPolationCurrentPos();
		break;
	case G02_CIRCULAR_CW_INTERPOLATION:
	case G03_CIRCULAR_CCW_INTERPOLATION:
		taskOperator.currentPos.stepPosition=circularInterPolationCurrentPos();
//todo
		break;
	default:
		break;
	}
}


void getTaskParameters(uint8_t task, uint8_t index)
{

	switch(task)
	{
	case G00_RAPID_MOVEMENT:
		taskOperatorPrepare.linearInterPolationParameters.stopPos.stepX=mmToStepX(Gparser.G00_RAPID_MOVEMENT[index].X);
		taskOperatorPrepare.linearInterPolationParameters.stopPos.stepY=mmToStepY(Gparser.G00_RAPID_MOVEMENT[index].Y);
		taskOperatorPrepare.linearInterPolationParameters.stopPos.stepZ=mmToStepZ(Gparser.G00_RAPID_MOVEMENT[index].Z);
		taskOperatorPrepare.linearInterPolationParameters.stopPos.stepE=mmToStepE(Gparser.G00_RAPID_MOVEMENT[index].E);
		break;
	case G01_LINEAR_INTERPOLATION:
		taskOperatorPrepare.linearInterPolationParameters.stopPos.stepX=mmToStepX(Gparser.G01_LINEAR_INTERPOLATION[index].X);
		taskOperatorPrepare.linearInterPolationParameters.stopPos.stepY=mmToStepY(Gparser.G01_LINEAR_INTERPOLATION[index].Y);
		taskOperatorPrepare.linearInterPolationParameters.stopPos.stepZ=mmToStepZ(Gparser.G01_LINEAR_INTERPOLATION[index].Z);
		taskOperatorPrepare.linearInterPolationParameters.stopPos.stepE=mmToStepE(Gparser.G01_LINEAR_INTERPOLATION[index].E);
		taskOperatorPrepare.linearInterPolationParameters.feedRate=Gparser.parserControl.activeFeedRate;
		break;
	case G02_CIRCULAR_CW_INTERPOLATION:
		setCircularInterpolationIJparameters(taskOperator.currentPos.stepPosition,&Gparser.G02_CIRCULAR_CW_INTERPOLATION[index]);
		taskOperatorPrepare.circularInterPolationParameters.feedRate=Gparser.G02_CIRCULAR_CW_INTERPOLATION[index].feedRate;
		taskOperatorPrepare.circularInterPolationParameters.stopPos.stepX=mmToStepX(Gparser.G02_CIRCULAR_CW_INTERPOLATION[index].X);
		taskOperatorPrepare.circularInterPolationParameters.stopPos.stepY=mmToStepY(Gparser.G02_CIRCULAR_CW_INTERPOLATION[index].Y);
		taskOperatorPrepare.circularInterPolationParameters.centerPos.stepX=mmToStepX(Gparser.G02_CIRCULAR_CW_INTERPOLATION[index].I)+
				taskOperator.currentPos.stepPosition.stepX;
		taskOperatorPrepare.circularInterPolationParameters.centerPos.stepY=mmToStepY(Gparser.G02_CIRCULAR_CW_INTERPOLATION[index].J)+
				taskOperator.currentPos.stepPosition.stepY;
		taskOperatorPrepare.circularInterPolationParameters.direction=CIRCULAR_CLOCK_WISE;

		break;
	case G03_CIRCULAR_CCW_INTERPOLATION:
		setCircularInterpolationIJparameters(taskOperator.currentPos.stepPosition,&Gparser.G03_CIRCULAR_CCW_INTERPOLATION[index]);
		taskOperatorPrepare.circularInterPolationParameters.feedRate=Gparser.G03_CIRCULAR_CCW_INTERPOLATION[index].feedRate;
		taskOperatorPrepare.circularInterPolationParameters.stopPos.stepX=mmToStepX(Gparser.G03_CIRCULAR_CCW_INTERPOLATION[index].X);
		taskOperatorPrepare.circularInterPolationParameters.stopPos.stepY=mmToStepY(Gparser.G03_CIRCULAR_CCW_INTERPOLATION[index].Y);
		taskOperatorPrepare.circularInterPolationParameters.centerPos.stepX=mmToStepX(Gparser.G03_CIRCULAR_CCW_INTERPOLATION[index].I)+
				taskOperator.currentPos.stepPosition.stepX;
		taskOperatorPrepare.circularInterPolationParameters.centerPos.stepY=mmToStepY(Gparser.G03_CIRCULAR_CCW_INTERPOLATION[index].J)+
				taskOperator.currentPos.stepPosition.stepY;
		taskOperatorPrepare.circularInterPolationParameters.direction=CIRCULAR_COUNTER_CLOCK_WISE;

		break;

	case M_FUNCTION:
		taskOperatorPrepare.MFUNCTIONtaskParameter=Gparser.M_FUNCTION[index];
		break;
	case SPEED:
		taskOperatorPrepare.SPEEDparameter=Gparser.SPEED[index];
		break;
	case TOOL:
		taskOperatorPrepare.TOOLparameter=Gparser.TOOL;
		break;


	default:
		break;
	}
}

void setCircularInterpolationIJparameters(stepPosXYZE currentPos,circularParameterPrototype *parameters)
{
	float d, h, x, y;
	switch(parameters->paramaterType)
	{
	case CIRCULAR_INTERPOLATION_R_TYPE:
		x= (parameters->X)-stepTommX((int64_t)currentPos.stepX);
		y= (parameters->Y)-stepTommY((int64_t)currentPos.stepY);
		d=sqrt((x*x) + (y*y));
		h=sqrt(parameters->radius-((d/2)*(d/2)));
		(parameters->I)=(x/2-((y*h)/d));
		(parameters->J)=(y/2+((x*h)/d));
		break;
	case CIRCULAR_INTERPOLATION_I_J_TYPE:
		x=parameters->I;
		y=parameters->J;
		parameters->radius=sqrt((x*x) + (y*y));
		break;
	default:
		break;
	}
}

void initailizeTaskParameters()
{
	memset(&taskOperator,0x0,sizeof(taskOperator));
	memset(&taskOperatorPrepare,0x0,sizeof(taskOperatorPrepare));
	taskOperator.task=0xff;
	taskOperator.currentTaskStatus=TASK_IDLE;
}





