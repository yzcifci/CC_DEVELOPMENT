///*
// * feed_rate_controller.c
// *
// *  Created on: 14 Oca 2018
// *      Author: yzcifci
// */
//
//#include "feed_rate_controller.h"
//#include "parameters.h"
//
//
//
///*
// * start from nextfeed to feedrate to find the stopping interval
// * if half of the  movement length accessed before accessing to feed rate
// * then stopping must be started at that point.
// */
//
//float declerateInterval(float feedRate, float stopFeed, float stopAngle, float, float radius,char dir, float movementLength)
//{
//	float feedRateActing;
//	float angleActing;
//	float angleSubActing;
//	float Fx;
//	float Fy;
//	float Tx;
//	float Ty;
//	uint32_t subStepX=0;
//	uint32_t subStepY=0;
//	float subMMx;
//	float subMMy;
//	float subMovement;
//	float additionalMovement;
//	float movement;
//	uint32_t timeMs=0;
//
//	Fx=stopFeed*sin(stopAngle);
//	Fy=stopFeed*cos(stopAngle);
//	Tx=((60*MM_PER_ROTATION_X)/(Fx*STEPS_PER_ROTATION_X))*1000;
//	Ty=((60*MM_PER_ROTATION_Y)/(Fy*STEPS_PER_ROTATION_Y))*1000;
//	timeMs=(uint32_t)getFeedIndex(stopFeed);
//	angleActing=stopAngle;
//
//
//	while(feedRateActing<feedRate)
//	{
//		timeMs++;
//		feedRateActing=feedRateTable[timeMs];
//
//		if(timeMs>Tx)
//		{
//			Fx=feedRateActing*sin(angleActing);
//			Tx=((60*MM_PER_ROTATION_X)/(Fx*STEPS_PER_ROTATION_X))*1000;
//			subStepX++;
//
//		}
//		if(timeMs>Ty)
//		{
//			Fy=angleActing*cos(angleActing);
//			Ty=((60*MM_PER_ROTATION_Y)/(Fy*STEPS_PER_ROTATION_Y))*1000;
//			subStepY++;
//		}
//
//		if((subStepX>0)&&(subStepY>0))
//		{
//			subMMx=subStepX*MM_PER_STEP_X;
//			subMMy=subStepY*MM_PER_STEP_Y;
//			subMovement=sqrt((subMMx*subMMx)+(subMMy*subMMy));
//			movement+=subMovement;
//			if(stopFeed>feedRateActing)additionalMovement+=subMovement;
//			if(movement>=(movementLength/2))
//			{
//				movement=movement-additionalMovement;
//				break;
//			}
//			angleSubActing=((subMovement/(2*PI*radius))*360);
//			angleActing=angleDifferentiate(angleSubActing,stopAngle,CIRCULAR_CLOCK_WISE);
//		}
//	}
//	return (movement+(movement/20));
//
//}
//
//
//void circularGetFeed(uint16_t time_ms, float* currentFeedrate, uint16_t *feedIndex, float nextFeedRate,
//		float feedRate,float currentMovingLength)
//{
//	//todo feed return funciton must be inserted here
//#ifdef ACCELERATION_ENABLE
//
//	if(currentMovingLength>currentMovingLength)
//	{//decelerate
//		if(currentFeedrate>nextFeedRate)
//		{
//			currentFeedrate=feedRateTable[feedIndex--];
//		}
//	}
//	else if(currentFeedrate<feedRate)
//	{//accelerate
//		feedIndex=time_ms;
//		if(feedRate<=feedRateTable[time_ms])
//		{// if currentFeedRate is closer than nex index take feedRate
//			currentFeedrate=feedRate;
//		}
//		else
//		{
//			currentFeedrate=feedRateTable[time_ms];
//		}
//	}
//#else
//	//NOTHING TO DO GO ON WITH THE SAME FEED
//#endif
//
//
//
//
//
//
//}
//
//uint32_t getConstantFeedMovementLength(float feedRate, float time)
//{
//
//	return(uint32_t)((feedRate*time)/60);
//}
//
//
//
//uint16_t getFeedIndex(float feedrate)
//{
//	uint16_t i=sizeof(feedRateTable)/4;
//	uint16_t index=sizeof(feedRateTable)/2;
//	while(i!=1)
//	{
//		if(feedrate>feedRateTable[index])index+=i;
//		else if(feedrate<feedRateTable[index])
//		{
//			index-=i;
//		}
//		else
//		{
//			return index;
//		}
//
//		i=i/2;
//	}
//	return index;
//}
