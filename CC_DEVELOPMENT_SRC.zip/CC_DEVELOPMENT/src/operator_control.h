/*
 * operator_control.h
 *
 *  Created on: 24 May 2018
 *      Author: yzcifci
 */

#ifndef OPERATOR_CONTROL_H_
#define OPERATOR_CONTROL_H_

extern struct deviceControl_
{
	stepPosXYZE stepPosition;
	positionXYZE mmPosition;
	uint8_t lengthMode;
	uint8_t incrementalMode;
	uint8_t ExtruderIncrementalMode;
	float feedRate;
	uint8_t microStepE;
	uint8_t microStepX;
	uint8_t microStepY;
	uint8_t microStepZ;
	float accelerationVal;

}deviceControl;


extern struct taskControl_
{
	uint8_t taskStatus;

}taskControl;


void tailUpdateControl();
void initSystem();
void initTaskOperator();
void G92_SET_POSITION_func(char*parameter);
void taskOperatorControl();
uint16_t binarySearch(uint16_t* array, uint16_t size, uint16_t search);
void systemOFF();
void systemOFF();
//uint8_t G28_MOVE_TO_ORIGIN_func(char *parameters);
void resetPositions(uint8_t x, uint8_t y, uint8_t z);
void initTaskOperator();
void _Error_Handler(char * file, int line);
#endif /* OPERATOR_CONTROL_H_ */
