/*
 * operator_control.h
 *
 *  Created on: 24 May 2018
 *      Author: yzcifci
 */

#ifndef OPERATOR_CONTROL_H_
#define OPERATOR_CONTROL_H_

extern struct deviceControl_
{
	stepPosXYZE stepPosition;
	positionXYZE mmPosition;
	uint8_t lengthMode;
	uint8_t incrementalMode;
	uint8_t ExtruderIncrementalMode;

}deviceControl;


extern struct taskControl_
{
	uint8_t taskStatus;

}taskControl;


void tailUpdateControl();
void initSystem();
void initTaskOperator();
void G92_SET_POSITION_func(char*parameter);
void taskOperatorControl();
#endif /* OPERATOR_CONTROL_H_ */
