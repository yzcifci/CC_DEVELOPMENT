/*
 * linear_interpolation.c
 *
 *  Created on: 14 Oca 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"


struct linearInterPolation_ linearInterPolation;
void startLinearInterPolation(stepPosXYZ currentPos,stepPosXYZ stopPos, float feedRate)
{
	memset(&linearInterPolation,0x0,sizeof(linearInterPolation));
	linearInterPolation.startPos=currentPos;
	linearInterPolation.stopPos=stopPos;
	linearInterPolation.currentPos=currentPos;


	linearInterPolation.subMovement.stepX=
			absDifferentiate(linearInterPolation.stopPos.stepX,linearInterPolation.currentPos.stepX);
	linearInterPolation.subMovement.stepY=
			absDifferentiate(linearInterPolation.stopPos.stepY,linearInterPolation.currentPos.stepY);
	linearInterPolation.subMovement.stepZ=
			absDifferentiate(linearInterPolation.stopPos.stepZ,linearInterPolation.currentPos.stepZ);

	linearInterPolation.angle=arctan(currentPos.stepX,currentPos.stepY, stopPos.stepX, stopPos.stepY);

	linearInterPolation.dirX=getLinearDir(currentPos.stepX,stopPos.stepX);
	linearInterPolation.dirY=getLinearDir(currentPos.stepY,stopPos.stepY);
	linearInterPolation.dirZ=getLinearDir(currentPos.stepZ,stopPos.stepZ);

	linearInterPolation.feedRate=feedRate;
	linearFeedRateControl(&linearInterPolation.feedRate, &linearInterPolation.actingFeedRate);
	linearInterPolation.actingFeedRateX=linearInterPolation.actingFeedRate*(cos(linearInterPolation.angle));
	linearInterPolation.actingFeedRateY=linearInterPolation.actingFeedRate*(sin(linearInterPolation.angle));
	linearInterPolation.actingFeedRateZ=MAXIMUM_START_STOP_FEED_RATE;
	linearInterPolation.Tx=getPulsePeriodX(linearInterPolation.actingFeedRateX);
	linearInterPolation.Ty=getPulsePeriodY(linearInterPolation.actingFeedRateY);
	linearInterPolation.Tz=getPulsePeriodZ(linearInterPolation.actingFeedRateZ);

	startStep(linearInterPolation.dirX,linearInterPolation.dirY,linearInterPolation.dirZ,
			linearInterPolation.Tx,linearInterPolation.Ty,linearInterPolation.Tz);




}

void linearFeedRateControl(float *feedRate,  float *actingFeedRate)
{
	if((*feedRate)>MAXIMUM_START_STOP_FEED_RATE)
	{
		(*feedRate)=MAXIMUM_START_STOP_FEED_RATE;

	}
	(*actingFeedRate)=(*feedRate);
}

uint8_t linearInterPolationPeriodicCall()
{
	uint8_t status;
	updateLinearInterPolationTiming();

	if((linearInterPolation.timeUs%((uint32_t)(linearInterPolation.Tx/2)))==0)
	{
		status=linearInterPolationPeriodicCallX();
	}
	if((linearInterPolation.timeUs%((uint32_t)(linearInterPolation.Ty/2)))==0)
	{
		status=linearInterPolationPeriodicCallY();
	}
	if((linearInterPolation.timeUs%((uint32_t)(linearInterPolation.Tz/2)))==0)
	{
		status=linearInterPolationPeriodicCallZ();
	}
	return status;

}


uint8_t linearInterPolationPeriodicCallX()
{
	uint8_t status=TASK_RUNNING;
	toggleX(linearInterPolation.dirX);
	if(((++linearInterPolation.stepToggleCounterX)%2)==0)
	{
		stepperLinearPosition(COORDINATE_X,linearInterPolation.dirX);
		if(linearInterPolationStopControl())
		{
			stopLinearSubMovement();
			status=TASK_COMPLETED;
		}
	}
	return status;
}

uint8_t linearInterPolationPeriodicCallY()
{
	uint8_t status=TASK_RUNNING;
	toggleY(linearInterPolation.dirY);
	if(((++linearInterPolation.stepToggleCounterY)%2)==0)
	{
		stepperLinearPosition(COORDINATE_Y,linearInterPolation.dirY);
		if(linearInterPolationStopControl())
		{
			stopLinearSubMovement();
			status=TASK_COMPLETED;
		}
	}
	return status;
}


uint8_t linearInterPolationPeriodicCallZ()
{
	uint8_t status=TASK_RUNNING;
	toggleZ(linearInterPolation.dirZ);
	if(((++linearInterPolation.stepToggleCounterZ)%2)==0)
	{
		stepperLinearPosition(COORDINATE_Z,linearInterPolation.dirZ);
		if(linearInterPolationStopControl())
		{
			stopLinearSubMovement();
			status=TASK_COMPLETED;
		}
	}
	return status;
}

void stepperLinearPosition(char coordinate, char dir)
{
	switch(coordinate)
	{
	case COORDINATE_X:
		if(linearInterPolation.dirX)linearInterPolation.currentPos.stepX++;
		else
		{
			linearInterPolation.currentPos.stepX--;
		}
		linearInterPolation.actingSubMovement.stepX++;
		break;
	case COORDINATE_Y:
		if(linearInterPolation.dirY)linearInterPolation.currentPos.stepY++;
		else
		{
			linearInterPolation.currentPos.stepY--;
		}
		linearInterPolation.actingSubMovement.stepY++;
		break;
	case COORDINATE_Z:
		if(linearInterPolation.dirZ)linearInterPolation.currentPos.stepZ++;
		else
		{
			linearInterPolation.currentPos.stepZ--;
		}
		linearInterPolation.actingSubMovement.stepZ++;
		break;
	}

}
void stopLinearSubMovement()
{
	stopMovement();
	completeTask();
}

char linearInterPolationStopControl()
{
	if((linearInterPolation.actingSubMovement.stepX>=linearInterPolation.subMovement.stepX)&&
			(linearInterPolation.actingSubMovement.stepY>=linearInterPolation.subMovement.stepY)&&
			(linearInterPolation.actingSubMovement.stepZ>=linearInterPolation.subMovement.stepZ))
	{
		return 1;
	}

	else if((linearInterPolation.currentPos.stepX==linearInterPolation.stopPos.stepX)&&
			(linearInterPolation.currentPos.stepY==linearInterPolation.stopPos.stepY)&&
			(linearInterPolation.currentPos.stepZ==linearInterPolation.stopPos.stepZ))

	{
		return 1;
	}
	else
	{
		return 0;
	}
}


void updateLinearInterPolationTiming()
{
	linearInterPolation.timeUs++;
	if((linearInterPolation.timeUs%10)==0)
	{
		linearInterPolation.timeMs++;
	}
}



char getLinearDir(uint32_t startPosAxis, uint32_t stopPosAxis)
{
	if(stopPosAxis>startPosAxis) return DIR_POSITIVE;
	else
		return DIR_NEGATIVE;
}


stepPosXYZ linearInterPolationCurrentPos()
{
	return linearInterPolation.currentPos;
}
