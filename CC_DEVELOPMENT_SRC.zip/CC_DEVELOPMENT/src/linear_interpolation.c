/*
 * linear_interpolation.c
 *
 *  Created on: 14 Oca 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"


struct linearInterPolation_ linearInterPolation;
uint8_t startLinearInterPolation(char *parameter)
{
	positionXYZE stopPosMM;
	memset(&linearInterPolation,0x0,sizeof(linearInterPolation));
	memcpy(&stopPosMM,parameter,sizeof(stopPosMM));
	//	stopPosMM=*(positionXYZE*)parameter;

	linearInterPolation.stopPos=deviceControl.stepPosition;


	uint16_t task=*(uint16_t*)&parameter[64];
	if(task==G28_MOVE_TO_ORIGIN || task==G00_RAPID_MOVEMENT  )
		linearInterPolation.feedRate=MAXIMUM_START_STOP_FEED_RATE;

	if(deviceControl.lengthMode==INCHES_MODE)
	{
		setInchToMM(&stopPosMM);
	}



	if(*(uint32_t*)&parameter[0]!=0xffffffff)linearInterPolation.stopPos.stepX=mmToStepX(stopPosMM.X);
	if(*(uint32_t*)&parameter[4]!=0xffffffff)linearInterPolation.stopPos.stepY=mmToStepY(stopPosMM.Y);
	if(*(uint32_t*)&parameter[8]!=0xffffffff)linearInterPolation.stopPos.stepZ=mmToStepZ(stopPosMM.Z);
	if(*(uint32_t*)&parameter[12]!=0xffffffff)linearInterPolation.stopPos.stepE=mmToStepE(stopPosMM.E);
	if(*(uint32_t*)&parameter[16]!=0xffffffff)deviceControl.feedRate=*(float*)(&parameter[16]);




	if(deviceControl.incrementalMode==INCREMENTAL_MODE)
	{
		linearInterPolation.stopPos.stepX+=deviceControl.stepPosition.stepX;
		linearInterPolation.stopPos.stepY+=deviceControl.stepPosition.stepY;
		linearInterPolation.stopPos.stepZ+=deviceControl.stepPosition.stepZ;

	}
	if(deviceControl.ExtruderIncrementalMode==INCREMENTAL_MODE)
	{
		linearInterPolation.stopPos.stepE+=deviceControl.stepPosition.stepE;
	}


	if((deviceControl.stepPosition.stepX==linearInterPolation.stopPos.stepX)&&
			(deviceControl.stepPosition.stepY==linearInterPolation.stopPos.stepY)&&
			(deviceControl.stepPosition.stepZ==linearInterPolation.stopPos.stepZ)&&
			(deviceControl.stepPosition.stepE==linearInterPolation.stopPos.stepE))
	{
		return TASK_COMPLETED;
	}

	linearInterPolation.stopPos.stepX+=ZERO_POINT_LENGTH_X;
	linearInterPolation.stopPos.stepY+=ZERO_POINT_LENGTH_Y;
	linearInterPolation.stopPos.stepZ+=ZERO_POINT_LENGTH_Z;




	linearInterPolation.subMovement.stepX=
			absDifferentiate(linearInterPolation.stopPos.stepX,deviceControl.stepPosition.stepX);
	linearInterPolation.subMovement.stepY=
			absDifferentiate(linearInterPolation.stopPos.stepY,deviceControl.stepPosition.stepY);
	linearInterPolation.subMovement.stepZ=
			absDifferentiate(linearInterPolation.stopPos.stepZ,deviceControl.stepPosition.stepZ);

	linearInterPolation.subMovement.stepE=
			absDifferentiate(linearInterPolation.stopPos.stepE,deviceControl.stepPosition.stepE);

	linearInterPolation.angle=arctan(deviceControl.stepPosition.stepX
			,deviceControl.stepPosition.stepY, linearInterPolation.stopPos.stepX, linearInterPolation.stopPos.stepY);

	linearInterPolation.dirX=getDir(deviceControl.stepPosition.stepX,linearInterPolation.stopPos.stepX);
	linearInterPolation.dirY=getDir(deviceControl.stepPosition.stepY,linearInterPolation.stopPos.stepY);
	linearInterPolation.dirZ=getDir(deviceControl.stepPosition.stepZ,linearInterPolation.stopPos.stepZ);

	linearInterPolation.dirE=getDir(deviceControl.stepPosition.stepE,linearInterPolation.stopPos.stepE);


	linearFeedRateControl(&deviceControl.feedRate, &linearInterPolation.actingFeedRate);
	linearInterPolation.actingFeedRateX=getLinearFeedRateX();
	linearInterPolation.actingFeedRateY=getLinearFeedRateY();
	linearInterPolation.actingFeedRateZ=getLinearFeedRateZ();
	linearInterPolation.Tx=getPulsePeriodX(linearInterPolation.actingFeedRateX);
	linearInterPolation.Ty=getPulsePeriodY(linearInterPolation.actingFeedRateY);
	linearInterPolation.Tz=getPulsePeriodZ(linearInterPolation.actingFeedRateZ);
	linearInterPolation.subMovementTick=getMovementTick(linearInterPolation.subMovement.stepX,
			linearInterPolation.subMovement.stepY,linearInterPolation.actingFeedRate);
	linearInterPolation.Te=getPulsePeriodE();

	startStep(linearInterPolation.dirX,linearInterPolation.dirY,linearInterPolation.dirZ,
			linearInterPolation.dirE, linearInterPolation.Tx,linearInterPolation.Ty,
			linearInterPolation.Tz,linearInterPolation.Te);


	return TASK_RUNNING;

}



/*
 * in terms of ms
 */
uint32_t getMovementTick(uint32_t stepX,uint32_t stepY, float feedRate)
{
//	float xinterval=stepTommX(stepX);
//	float yinterval=stepTommY(stepY);
//	uint32_t timeToGo=((sqrt((xinterval*xinterval)+(yinterval*yinterval)))*TIME_DIVISION_PER_SEC)/(feedRate/60);

	uint32_t timeToGo=0;
	uint8_t div=0;
	if(linearInterPolation.Tx)
	{
		timeToGo+=(linearInterPolation.subMovement.stepX*linearInterPolation.Tx);
		div++;
	}
	if(linearInterPolation.Ty)
	{
		timeToGo+=(linearInterPolation.subMovement.stepY*linearInterPolation.Ty);
		div++;
	}
	if(!div)return 0;
	timeToGo=timeToGo/div;
	return timeToGo;
}
float getLinearFeedRateX()
{
	if(linearInterPolation.subMovement.stepX==0)return 0;
	return fabs(linearInterPolation.actingFeedRate*
			(cos(angleToRad(linearInterPolation.angle))));
}
float getLinearFeedRateY()
{
	if(linearInterPolation.subMovement.stepY==0)return 0;
	return fabs(linearInterPolation.actingFeedRate*
			(sin(angleToRad(linearInterPolation.angle))));
}
float getLinearFeedRateZ()
{
	if(linearInterPolation.subMovement.stepZ==0)return 0;
	return linearInterPolation.actingFeedRate;
}


uint16_t getPulsePeriodE()
{
	if(linearInterPolation.subMovementTick)
	{
		return (linearInterPolation.subMovementTick/(linearInterPolation.subMovement.stepE));
	}
	else
	{
		return((60*MM_PER_ROTATION_E*TIME_DIVISION_PER_SEC)/
				(MAXIMUM_EXTRUDER_START_STOP_FEED_RATE*STEPS_PER_ROTATION_E));

	}
}


void linearFeedRateControl(float *feedRate,  float *actingFeedRate)
{
	if((*feedRate)>MAXIMUM_START_STOP_FEED_RATE)
	{
		(*feedRate)=MAXIMUM_START_STOP_FEED_RATE;

	}
	(*actingFeedRate)=(*feedRate);
}

uint8_t linearInterPolationPeriodicCall()
{
	uint8_t status=TASK_RUNNING;
	updateLinearInterPolationTiming();

	if((linearInterPolation.timeUs%((uint32_t)(linearInterPolation.Tx/2)))==0)
		status=linearInterPolationPeriodicCallX();
	if((linearInterPolation.timeUs%((uint32_t)(linearInterPolation.Ty/2)))==0)
		status=linearInterPolationPeriodicCallY();
	if((linearInterPolation.timeUs%((uint32_t)(linearInterPolation.Tz/2)))==0)
		status=linearInterPolationPeriodicCallZ();
	if((linearInterPolation.timeUs%((uint32_t)(linearInterPolation.Te/2)))==0)
		status=linearInterPolationPeriodicCallE();
	return status;

}


uint8_t linearInterPolationPeriodicCallX()
{
	uint8_t status=TASK_RUNNING;
	if(linearInterPolationStopControl())
	{
		stopLinearSubMovement();
		return TASK_COMPLETED;
	}
	if(linearInterPolation.actingSubMovement.stepX>=linearInterPolation.subMovement.stepX)return TASK_RUNNING;
	toggleX(linearInterPolation.dirX);
	if(((++linearInterPolation.stepToggleCounterX)%2)==0)
		stepperLinearPosition(COORDINATE_X,linearInterPolation.dirX);
	return status;
}

uint8_t linearInterPolationPeriodicCallY()
{
	uint8_t status=TASK_RUNNING;
	if(linearInterPolationStopControl())
	{
		stopLinearSubMovement();
		return TASK_COMPLETED;
	}
	if(linearInterPolation.actingSubMovement.stepY>=linearInterPolation.subMovement.stepY)return TASK_RUNNING;
	toggleY(linearInterPolation.dirY);
	if(((++linearInterPolation.stepToggleCounterY)%2)==0)
	{
		stepperLinearPosition(COORDINATE_Y,linearInterPolation.dirY);
	}
	return status;
}


uint8_t linearInterPolationPeriodicCallZ()
{
	uint8_t status=TASK_RUNNING;
	if(linearInterPolationStopControl())
	{
		stopLinearSubMovement();
		return TASK_COMPLETED;
	}
	if(linearInterPolation.actingSubMovement.stepZ>=linearInterPolation.subMovement.stepZ)return TASK_RUNNING;
	toggleZ(linearInterPolation.dirZ);
	if(((++linearInterPolation.stepToggleCounterZ)%2)==0)
	{
		stepperLinearPosition(COORDINATE_Z,linearInterPolation.dirZ);

	}
	return status;
}

uint8_t linearInterPolationPeriodicCallE()
{
	uint8_t status=TASK_RUNNING;
	if(linearInterPolationStopControl())
	{
		stopLinearSubMovement();
		return TASK_COMPLETED;
	}
	if(linearInterPolation.actingSubMovement.stepE>=linearInterPolation.subMovement.stepE)return TASK_RUNNING;
	toggleE(linearInterPolation.dirE);
	if(((++linearInterPolation.stepToggleCounterE)%2)==0)
	{
		stepperLinearPosition(EXTRUDER,linearInterPolation.dirE);

	}
	return status;
}


void stepperLinearPosition(char coordinate, char dir)
{
	switch(coordinate)
	{
	case COORDINATE_X:
		if(linearInterPolation.dirX)deviceControl.stepPosition.stepX++;
		else
		{
			deviceControl.stepPosition.stepX--;
		}
		linearInterPolation.actingSubMovement.stepX++;
		break;
	case COORDINATE_Y:
		if(linearInterPolation.dirY)deviceControl.stepPosition.stepY++;
		else
		{
			deviceControl.stepPosition.stepY--;
		}
		linearInterPolation.actingSubMovement.stepY++;
		break;
	case COORDINATE_Z:
		if(linearInterPolation.dirZ)deviceControl.stepPosition.stepZ++;
		else
		{
			deviceControl.stepPosition.stepZ--;
		}
		linearInterPolation.actingSubMovement.stepZ++;
		break;
	case EXTRUDER:
		if(linearInterPolation.dirE)deviceControl.stepPosition.stepE++;
		else
		{
			deviceControl.stepPosition.stepE--;
		}
		linearInterPolation.actingSubMovement.stepE++;
		break;
	}

}
void stopLinearSubMovement()
{
	stopMovement();
}

char linearInterPolationStopControl()
{
	if((linearInterPolation.actingSubMovement.stepX>=linearInterPolation.subMovement.stepX)&&
			(linearInterPolation.actingSubMovement.stepY>=linearInterPolation.subMovement.stepY)&&
			(linearInterPolation.actingSubMovement.stepZ>=linearInterPolation.subMovement.stepZ)&&
			(linearInterPolation.actingSubMovement.stepE>=linearInterPolation.subMovement.stepE))
	{
		return 1;
	}

	else if((deviceControl.stepPosition.stepX==linearInterPolation.stopPos.stepX)&&
			(deviceControl.stepPosition.stepY==linearInterPolation.stopPos.stepY)&&
			(deviceControl.stepPosition.stepZ==linearInterPolation.stopPos.stepZ)&&
			(deviceControl.stepPosition.stepE==linearInterPolation.stopPos.stepE))

	{
		return 1;
	}
	else
	{
		return 0;
	}
}


void updateLinearInterPolationTiming()
{
	linearInterPolation.timeUs++;
	if((linearInterPolation.timeUs%10)==0)
	{
		linearInterPolation.timeMs++;
	}
}







