/*
 * task_operator_interface.c
 *
 *  Created on: 15 �ub 2018
 *      Author: yzcifci
 */

#include "Gparser.h"
#include "movement_control.h"
#include "task_operator_interface.h"

struct operatorParserStateMachine_ operatorParserStateMachine;

//uint8_t operatorParserStateControl()
//{
//	uint8_t state;
//
//	operatorParserStateMachine.status.operatorFull=CHECK_BIG(Gparser.parserControl.operatorIndex,Gparser.parserControl.taskIndex);
//	operatorParserStateMachine.status.parserFull=CHECK_BIG(Gparser.parserControl.taskIndex, MAX_ITEM_NUMBER);
//
//	state=(operatorParserStateMachine.status.parserFull<<1)|operatorParserStateMachine.status.operatorFull;
//
//	switch (state)
//	{
//	case 0b01:
//		operatorParserStateMachine.operatorParserState= OPERATOR_BUFFER_FULL;
//		break;
//	case 0b10 :
//		operatorParserStateMachine.operatorParserState= PARSER_BUFFER_FULL;
//		break;
//	case 0b11 :
//		operatorParserStateMachine.operatorParserState= OPERATOR_PARSER_BUFFER_NOT_FULL;
//		Gparser.parserControl.operatorIndex=0;
//		Gparser.parserControl.taskIndex=0;
//		memset(&Gparser.indexer, 0x0, sizeof(Gparser.indexer));
//		break;
//	case 0b00 :
//		operatorParserStateMachine.operatorParserState= OPERATOR_PARSER_BUFFER_NOT_FULL;
//		break;
//	default:
//		break;
//
//	}
//
//	return operatorParserStateMachine.operatorParserState;
//}
//
//void initSystem()
//{
//	initializeParser();
//	initTaskOperator();
//	initPorts();
//	initTimer();
//	initSerialCom();
//}


