/*
 * GPIO_control.h
 *
 *  Created on: 14 Oca 2018
 *      Author: yzcifci
 */

#ifndef GPIO_CONTROL_H_
#define GPIO_CONTROL_H_


#include "parameters.h"

void setDirX(uint8_t dir);
void setDirY(uint8_t dir);
void setDirZ(uint8_t dir);
void setDirE(uint8_t dir);
void toggleX(char dirX);
void toggleY(char dirY);
void toggleZ(char dirZ);
void toggleE(char dirE);
void enableX();
void enableY();
void enableZ();
void enableE();
void disableX();
void disableY();
void disableZ();
void disableE();
void stopMovement();
void resetPinMovementPinStates();
void startStep(char dirX,char dirY, char dirZ, char dirE, uint16_t Tx,uint16_t Ty,uint16_t Tz, uint16_t Te);
void initPorts();

void GPIO_CLOCK_ENABLE(GPIO_TypeDef* GPIO);

uint8_t readLimitSwitchX();
uint8_t readLimitSwitchY();
uint8_t readLimitSwitchZ();

void extruderHeaterOn();
void extruderHeaterOff();
void extruderCoolerOn();
void extruderCoolerOff();
void heatBedHeaterOn();
void heatBedHeaterOff();
void setMicroStepX(uint8_t microStep);
void setMicroStepY(uint8_t microStep);
void setMicroStepZ(uint8_t microStep);
void setMicroStepE(uint8_t microStep);

#endif /* GPIO_CONTROL_H_ */
