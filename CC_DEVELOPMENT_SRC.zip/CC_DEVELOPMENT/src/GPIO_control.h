/*
 * GPIO_control.h
 *
 *  Created on: 14 Oca 2018
 *      Author: yzcifci
 */

#ifndef GPIO_CONTROL_H_
#define GPIO_CONTROL_H_


#include "parameters.h"


void toggleX(char dirX);
void toggleY(char dirY);
void toggleZ(char dirZ);
void stopMovement();
void startStep(char dirX,char dirY, char dirZ, uint16_t Tx,uint16_t Ty,uint16_t Tz);
void initPorts();
void laserSwitch(uint8_t state);
void coolantSwitch(uint8_t state);
void GPIO_CLOCK_ENABLE(GPIO_TypeDef* GPIO);


#endif /* GPIO_CONTROL_H_ */
