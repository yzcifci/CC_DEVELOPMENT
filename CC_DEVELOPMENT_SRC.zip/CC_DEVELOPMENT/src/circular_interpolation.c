/*
 * circular_interpolation.c
 *
 *  Created on: 7 Oca 2018
 *      Author: yzcifci
 */

//#include "circular_interpolation.h"
//#include "math.h"
//
//#include "parameters.h"
//#include "string.h"
#include "task_operator_interface.h"

struct circularInterpolation_ circularInterpolation;



void startCircularInterpolation( stepPosXYZE currentPos,stepPosXY stopPos, stepPosXY centerPos, float feedRate, char CW_CCW)
{
	memset(&circularInterpolation,0x0,sizeof(circularInterpolation));
	circularInterpolation.angleStart=arctan(centerPos.stepX,centerPos.stepY, currentPos.stepX,currentPos.stepY);
	circularInterpolation.angleStop=arctan(centerPos.stepX,centerPos.stepY, stopPos.stepX,stopPos.stepY);
	circularInterpolation.angleCurrent=circularInterpolation.angleStart;
	circularInterpolation.angleToMove=angleDifferentiate(circularInterpolation.angleStart,circularInterpolation.angleStop,CW_CCW );
	circularInterpolation.CW_CCW=CW_CCW;
	circularInterpolation.feedRate=feedRate;
	circularFeedRateStartControl();
	circularInterpolation.dirX=getDirX(circularInterpolation.angleCurrent,CW_CCW);
	circularInterpolation.dirY=getDirY(circularInterpolation.angleCurrent,CW_CCW);

	circularInterpolation.TX=getPulsePeriodX(circularInterpolation.currentFeedRateX);
	circularInterpolation.TY=getPulsePeriodY(circularInterpolation.currentFeedRateY);

	circularInterpolation.currentPos=currentPos;
	circularInterpolation.centerPos=centerPos;
	circularInterpolation.stopPos=stopPos;
//	startStep(circularInterpolation.dirX,circularInterpolation.dirY,0,circularInterpolation.TX,circularInterpolation.TY,0);

}

void circularFeedRateStartControl()
{
#ifdef ACCELERATION_ENABLE

	circularInterpolation.deceleratePoint=circularInterpolation.movementLength-
			declerateInterval(circularInterpolation.feedRate,circularInterpolation.nextFeedRate,
					circularInterpolation.angleStop,circularInterpolation.radius,circularInterpolation.CW_CCW);

	/*
	 * three cases must be handled for starting feedRate decision
	 * feed rate: the feed rate that will be handled during movement that is max feed for current sub movement
	 * next feed rate: next feed rate that will be handled
	 *
	 * 1-if next feed rate is bigger than the feed rate then next feed rate is equal to feed rate
	 * 2-if next feed rate is smaller than  feed rate and we will not be able to stop with next feed at
	 * stop point when we start
	 * 3-if feed rate is smaller than start stop max feed rate =feedRateTable[0] then nothing must change
	 * go on with smaller feed rate
	 *
	 */
	if(circularInterpolation.nextFeedRate>circularInterpolation.feedRate)
		circularInterpolation.nextFeedRate=circularInterpolation.feedRate;


	circularInterpolation.currentFeedrate=getFeed(circularInterpolation.timeMs);
	circularInterpolation.currentFeedRateX=	circularInterpolation.currentFeedrate*(sin(circularInterpolation.angleCurrent));
	circularInterpolation.currentFeedRateY=	circularInterpolation.currentFeedrate*(cos(circularInterpolation.angleCurrent));

#else
	if(circularInterpolation.feedRate>MAXIMUM_START_STOP_FEED_RATE)
		circularInterpolation.feedRate=MAXIMUM_START_STOP_FEED_RATE;

	circularInterpolation.currentFeedrate=circularInterpolation.feedRate;
	circularInterpolation.currentFeedRateX=	circularInterpolation.currentFeedrate*(sin(circularInterpolation.angleCurrent));
	circularInterpolation.currentFeedRateY=	circularInterpolation.currentFeedrate*(cos(circularInterpolation.angleCurrent));

#endif
}
float angleDifferentiate(float angle1, float angle2 ,char direction)
{
	float subAngle=0.0;
	switch (direction)
	{
	case CIRCULAR_CLOCK_WISE:
		subAngle=angle1-angle2;
		if(subAngle<0)subAngle+=360;
		break;

	case CIRCULAR_COUNTER_CLOCK_WISE:
		subAngle=angle2-angle1;
		if(subAngle<0)subAngle+=360;
		break;

	}
	return subAngle;
}
/*
 * Must be called periodically 100 us period
 */
uint8_t circularInterPolationPeriodicCall()
{
	char status=TASK_RUNNING;
	updateCircularInterPolationTiming();
	if((circularInterpolation.tim100_us_counter%((uint32_t)(circularInterpolation.TX/2)))==0)
		status=circularInterPolationXstepCall();

	if((circularInterpolation.tim100_us_counter%((uint32_t)(circularInterpolation.TY/2)))==0)
		status=circularInterPolationYstepCall();
	return status;

}


float circularMovementLength(float angle, float radius)
{
	return ((angle*2*PI*radius)/360);
}



char  circularInterPolationXstepCall()
{

	toggleX(circularInterpolation.dirX);
	if(((++circularInterpolation.subXcounter)%2)!=0)
	{
		return TASK_RUNNING;
	}
	else
	{

		if(circularInterpolation.dirX)circularInterpolation.currentPos.stepX++;
		else
		{
			circularInterpolation.currentPos.stepX--;
		}
		circularInterpolation.angleCurrent=arctan(circularInterpolation.centerPos.stepX,circularInterpolation.centerPos.stepY,
				circularInterpolation.currentPos.stepX,circularInterpolation.currentPos.stepY);
		circularInterpolation.currentFeedRateX=	circularInterpolation.currentFeedrate*(sin(circularInterpolation.angleCurrent));
		circularInterpolation.TX=((60*MM_PER_ROTATION_X)/(circularInterpolation.currentFeedRateX*STEPS_PER_ROTATION_X))*10*1000;//*1000 for interms of ms; *10 for in terms of us
		circularInterpolation.dirX=getDirX(circularInterpolation.angleCurrent,circularInterpolation.CW_CCW);
		circularInterpolation.angleSubRotating=angleDifferentiate(circularInterpolation.angleStart,
				circularInterpolation.angleCurrent,circularInterpolation.CW_CCW);
		if(checkCircularMovementEnd())
		{
			stopMovement();
			return TASK_COMPLETED;
		}
	}

	return TASK_RUNNING;



}

char  circularInterPolationYstepCall()
{

	toggleY(circularInterpolation.dirY);
	if(((++circularInterpolation.subXcounter)%2)!=0)
	{
		return TASK_RUNNING;
	}
	else
	{

		if(circularInterpolation.dirY)circularInterpolation.currentPos.stepY++;
		else
		{
			circularInterpolation.currentPos.stepY--;
		}
		circularInterpolation.angleCurrent=arctan(circularInterpolation.centerPos.stepX,circularInterpolation.centerPos.stepY,
				circularInterpolation.currentPos.stepX,circularInterpolation.currentPos.stepY);
		circularInterpolation.currentFeedRateY=	circularInterpolation.currentFeedrate*(cos(circularInterpolation.angleCurrent));
		circularInterpolation.TY=((60*MM_PER_ROTATION_Y)/(circularInterpolation.currentFeedRateY*STEPS_PER_ROTATION_Y))*10*1000;//*1000 for interms of ms; *10 for in terms of us
		circularInterpolation.dirY=getDirY(circularInterpolation.angleCurrent,circularInterpolation.CW_CCW);
		circularInterpolation.angleSubRotating=angleDifferentiate(circularInterpolation.angleStart,
				circularInterpolation.angleCurrent,circularInterpolation.CW_CCW);
		if(checkCircularMovementEnd())
		{
			stopMovement();
			return TASK_COMPLETED;
		}
	}

	return TASK_RUNNING;



}


stepPosXYZE circularInterPolationCurrentPos()
{
	return circularInterpolation.currentPos;
}
char checkCircularMovementEnd()
{

	if((circularInterpolation.currentPos.stepX==circularInterpolation.stopPos.stepX)&&
			(circularInterpolation.currentPos.stepY==circularInterpolation.stopPos.stepY))return 1;

	if(circularInterpolation.angleSubRotating>=circularInterpolation.angleToMove)return 1;

	return 0;
}
void updateCircularInterPolationTiming()
{
	circularInterpolation.tim100_us_counter++;
	if((circularInterpolation.tim100_us_counter%10)==0)circularInterpolation.timeMs++;
}











char getDirX(float angleX, char CW_CCW)
{
	switch(CW_CCW)
	{
	case CIRCULAR_CLOCK_WISE:
		if((0<angleX) && (angleX<180)) return DIR_POSITIVE;
		else if((180<angleX) && (angleX<360)) return DIR_NEGATIVE;
		break;

	case CIRCULAR_COUNTER_CLOCK_WISE:
		if((0<angleX) && (angleX<180)) return DIR_NEGATIVE;
		else if((180<angleX) && (angleX<360)) return DIR_POSITIVE;
		break;
	default:
		return 0;

	}
	return 0;
}

char getDirY(float angleY, char CW_CCW)
{
	switch(CW_CCW)
	{
	case CIRCULAR_CLOCK_WISE:
		if((0<angleY) && (angleY<90)) return DIR_NEGATIVE;
		else if((270<angleY) && (angleY<360)) return DIR_NEGATIVE;
		else if((90<angleY) && (angleY<270)) return DIR_POSITIVE;
		break;

	case CIRCULAR_COUNTER_CLOCK_WISE:
		if((0<angleY) && (angleY<90)) return DIR_POSITIVE;
		else if((270<angleY) && (angleY<360)) return DIR_POSITIVE;
		else if((90<angleY) && (angleY<270)) return DIR_NEGATIVE;
		break;
	default:
		return 0;

	}

	return 0;
}
