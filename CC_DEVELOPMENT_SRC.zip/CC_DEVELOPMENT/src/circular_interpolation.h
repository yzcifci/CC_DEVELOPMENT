/*
 * circular_interpolation.h
 *
 *  Created on: 7 Oca 2018
 *      Author: yzcifci
 */

#ifndef CIRCULAR_INTERPOLATION_H_
#define CIRCULAR_INTERPOLATION_H_

#include "stm32f4xx_hal.h"
#include "parameters.h"


typedef struct uniPos_
{
	float mmX;
	float mmY;
	float mmZ;
	uint32_t stepX;
	uint32_t stepY;
	uint32_t stepZ;
}uniPos;
extern struct circularInterpolation_
{
	float angleStart;
	float angleStop;
	float angleCurrent;
	float angleToMove;
	float angleSubRotating;
	float currentFeedrate;
	float currentFeedRateX;
	float currentFeedRateY;
	float feedRate;
	uint16_t feedIndex;
	uint16_t feedDecelerateTimePoint;
	char dirX;
	char dirY;
	uint32_t timeMs;
	uint32_t tim100_us_counter;
	uint16_t TX;
	uint16_t TY;
	char CW_CCW;
	stepPosXYZ currentPos;
	stepPosXY centerPos;
	stepPosXY stopPos;
	float radius;
	char subXcounter;
	char subYcounter;

}circularInterpolation;

void startCircularInterpolation( stepPosXYZ currentPos,stepPosXY stopPos, stepPosXY centerPos, float feedRate, char CW_CCW);
void circularFeedRateStartControl();
float angleDifferentiate(float angle1, float angle2 ,char direction);
uint8_t circularInterPolationPeriodicCall();
float circularMovementLength(float angle, float radius);
char  circularInterPolationXstepCall();
char  circularInterPolationYstepCall();
stepPosXYZ circularInterPolationCurrentPos();
char checkCircularMovementEnd();
void updateCircularInterPolationTiming();
char getDirX(float angleX, char CW_CCW);
char getDirY(float angleY, char CW_CCW);





/*function definitions*/



#endif /* CIRCULAR_INTERPOLATION_H_ */
