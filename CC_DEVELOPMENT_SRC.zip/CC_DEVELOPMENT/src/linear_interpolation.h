/*
 * linear_interpolation.h
 *
 *  Created on: 14 Oca 2018
 *      Author: yzcifci
 */

#ifndef LINEAR_INTERPOLATION_H_
#define LINEAR_INTERPOLATION_H_
#include "stm32f4xx_hal.h"
#include "parameters.h"

extern struct linearInterPolation_
{
	float feedRate;
	stepPosXYZ startPos;
	stepPosXYZ stopPos;
	stepPosXYZ currentPos;
	stepPosXYZ actingSubMovement;
	stepPosXYZ subMovement;
	float angle;
	char dirX;
	char dirY;
	char dirZ;
	float actingFeedRate;
	float actingFeedRateX;
	float actingFeedRateY;
	float actingFeedRateZ;
	uint16_t Tx;
	uint16_t Ty;
	uint16_t Tz;
	uint32_t timeMs;
	uint32_t timeUs;
	char stepToggleCounterX;
	char stepToggleCounterY;
	char stepToggleCounterZ;

}linearInterPolation;



void startLinearInterPolation(stepPosXYZ currentPos,stepPosXYZ stopPos, float feedRate);
float getLinearFeedRateX();
float getLinearFeedRateY();
float getLinearFeedRateZ();
void linearFeedRateControl(float *feedRate,  float *actingFeedRate);
uint8_t linearInterPolationPeriodicCall();
uint8_t linearInterPolationPeriodicCallX();
uint8_t linearInterPolationPeriodicCallY();
uint8_t linearInterPolationPeriodicCallZ();
void stepperLinearPosition(char coordinate, char dir);
void stopLinearSubMovement();
char linearInterPolationStopControl();
void updateLinearInterPolationTiming();
char getLinearDir(uint32_t startPosAxis, uint32_t stopPosAxis);
stepPosXYZ linearInterPolationCurrentPos();


#endif /* LINEAR_INTERPOLATION_H_ */
