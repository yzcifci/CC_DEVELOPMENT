/*
 * linear_interpolation.h
 *
 *  Created on: 14 Oca 2018
 *      Author: yzcifci
 */

#ifndef LINEAR_INTERPOLATION_H_
#define LINEAR_INTERPOLATION_H_
#include "stm32f4xx_hal.h"
#include "parameters.h"
#include "task_operator_interface.h"

extern struct linearInterPolation_
{
	float feedRate;
	stepPosXYZE stopPos;
	stepPosXYZE actingSubMovement;
	stepPosXYZE subMovement;
	float angle;
	/*char dirX;
	char dirY;
	char dirZ;
	char dirE;*/
	float actingFeedRate;
	float actingFeedRateX;
	float actingFeedRateY;
	float actingFeedRateZ;
	uint16_t Tx;
	uint16_t Ty;
	uint16_t Tz;
	uint16_t Te;
	uint32_t subMovementTick;
	uint32_t timeMs;
	uint32_t timeUs;
	char stepToggleCounterX;
	char stepToggleCounterY;
	char stepToggleCounterZ;
	char stepToggleCounterE;

	float startFeed;
	float endFeed;








	float x;
	float y;
	float z;
	float e;
	float f;

	float stepX;
	float stepY;
	float stepZ;
	float stepE;

	float t1sx;
	float t1ax;
	float p1x;
	float t1sy;
	float t1ay;
	float p1y;

	float t2sx;
	float t2ax;
	float p2x;
	float t2sy;
	float t2ay;
	float p2y;

	float tz;

	float t1se;
	float t1ae;
	float p1e;

	float t2se;
	float teae;
	float p2e;


	uint8_t dirX;
	uint8_t dirY;
	uint8_t dirZ;
	uint8_t dirE;




}linearInterPolation;



uint8_t startLinearInterPolation(char *parameter);
uint32_t getMovementTick(uint32_t stepX,uint32_t stepY, float feedRate);
float getLinearFeedRateX();
float getLinearFeedRateY();
float getLinearFeedRateZ();
uint16_t getPulsePeriodE();
void linearFeedRateControl(float *feedRate,  float *actingFeedRate);
uint8_t linearInterPolationPeriodicCall();
uint8_t linearInterPolationPeriodicCallX();
uint8_t linearInterPolationPeriodicCallY();
uint8_t linearInterPolationPeriodicCallZ();
uint8_t linearInterPolationPeriodicCallE();
void stepperLinearPosition(char coordinate, char dir);
void stopLinearSubMovement();
char linearInterPolationStopControl();
void updateLinearInterPolationTiming();
stepPosXYZE linearInterPolationCurrentPos();


#endif /* LINEAR_INTERPOLATION_H_ */
