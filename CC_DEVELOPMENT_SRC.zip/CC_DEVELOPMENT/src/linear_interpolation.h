/*
 * linear_interpolation.h
 *
 *  Created on: 14 Oca 2018
 *      Author: yzcifci
 */

#ifndef LINEAR_INTERPOLATION_H_
#define LINEAR_INTERPOLATION_H_
#include "stm32f4xx_hal.h"
#include "parameters.h"

extern struct linearInterPolation_
{
	float feedRate;
	stepPosXYZE startPos;
	stepPosXYZE stopPos;
	stepPosXYZE currentPos;
	stepPosXYZE actingSubMovement;
	stepPosXYZE subMovement;
	float angle;
	char dirX;
	char dirY;
	char dirZ;
	char dirE;
	float actingFeedRate;
	float actingFeedRateX;
	float actingFeedRateY;
	float actingFeedRateZ;
	uint16_t Tx;
	uint16_t Ty;
	uint16_t Tz;
	uint16_t Te;
	uint32_t subMovementTime;
	uint32_t timeMs;
	uint32_t timeUs;
	char stepToggleCounterX;
	char stepToggleCounterY;
	char stepToggleCounterZ;
	char stepToggleCounterE;

}linearInterPolation;



uint8_t startLinearInterPolation(stepPosXYZE currentPos,stepPosXYZE stopPos, float feedRate);
uint32_t getMovementTime(uint32_t stepX,uint32_t stepY, float feedRate);
float getLinearFeedRateX();
float getLinearFeedRateY();
float getLinearFeedRateZ();
void linearFeedRateControl(float *feedRate,  float *actingFeedRate);
uint8_t linearInterPolationPeriodicCall();
uint8_t linearInterPolationPeriodicCallX();
uint8_t linearInterPolationPeriodicCallY();
uint8_t linearInterPolationPeriodicCallZ();
uint8_t linearInterPolationPeriodicCallE();
void stepperLinearPosition(char coordinate, char dir);
void stopLinearSubMovement();
char linearInterPolationStopControl();
void updateLinearInterPolationTiming();
stepPosXYZE linearInterPolationCurrentPos();


#endif /* LINEAR_INTERPOLATION_H_ */
