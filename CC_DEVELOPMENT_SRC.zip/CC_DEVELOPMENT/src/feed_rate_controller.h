///*
// * feed_rate_controller.h
// *
// *  Created on: 14 Oca 2018
// *      Author: yzcifci
// */
//
//#ifndef FEED_RATE_CONTROLLER_H_
//#define FEED_RATE_CONTROLLER_H_
//
//#include "parameters.h"
//
//float declerateInterval(float feedRate, float stopFeed, float stopAngle, float, float radius,char dir, float movementLength);
//void circularGetFeed(uint16_t time_ms, float* currentFeedrate, uint16_t *feedIndex, float nextFeedRate,
//		float feedRate,float currentMovingLength);
//uint32_t getConstantFeedMovementLength(float feedRate, float time);
//uint16_t getFeedIndex(float feedrate);
//
//
//#endif /* FEED_RATE_CONTROLLER_H_ */
