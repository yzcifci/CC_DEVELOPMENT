/*
 * temperature_control.c
 *
 *  Created on: 19 May 2019
 *      Author: yzcifci
 */

#include "main.h"


uint16_t histHeatBed=0;
uint16_t histHeatExt=0;
int16_t readBedTemp()
{
	int16_t index;
	int16_t temp;
	int16_t maxTemp=HEATBED_MAX_TEMP;
	index=binarySearch(heatbedNTCtable, sizeof(heatbedNTCtable)/2,ADC_control.readADCVal[0] );
	temp=(index*10)+HEATBED_MIN_TEMP;
	if(temp>maxTemp)
	{
		parameterError(HEATBED_TEMP_READ_ERROR);
	}
	return temp;
}

int16_t readExtruderTemp()
{
	int16_t index;
	int16_t temp;
	int16_t maxTemp=EXTRUDER_MAX_TEMP;
	index=binarySearch(extruderNTCtable, sizeof(extruderNTCtable)/2,ADC_control.readADCVal[1] );
	temp=(index)+EXTRUDER_MIN_TEMP;
	if(temp>maxTemp)
	{
		parameterError(EXTRUDER_TEMP_READ_ERROR);
	}
	return temp;
}


void extruderTempControl()
{
	int16_t temp=0;
	temp=readExtruderTemp();
	printerIOParameters.currentExturderTemp=((printerIOParameters.currentExturderTemp*3)+temp)/4;
}

void bedTempControl()
{
	int16_t temp=0;
	temp=readBedTemp();
	printerIOParameters.currentBedTemp=((printerIOParameters.currentBedTemp*3)+temp)/4;
}

void readBedTempCurrent()
{
	int16_t temp=0;
	temp=readBedTemp();
	printerIOParameters.currentBedTemp=((printerIOParameters.currentBedTemp*15)+temp)/16;
}

void tempControl()
{
	if(ADC_control.readFlag==0)return;
	ADC_control.readFlag=0;
	extruderTempControl();
	bedTempControl();

}

uint8_t heatBetonOf=0;
void tempBedPWMOutCntrl()
{
	static uint8_t pwmPercent=30;
	static uint32_t checkCntr=0;
	static uint8_t pwmPeriod=50;
	static uint8_t pwmCntr=0;
	static uint8_t pwmPercentCount=15;

	switch(printerIOParameters.heatBedSt)
	{
	case HEAT_BED_HEAT_OFF:
		heatBedHeaterOff();
		break;
	case HEAT_BED_HEAT_UP:
		heatBedHeaterOn();
		break;

	case HEAT_BED_HEAT_UP_THEN_STEADY:
		heatBedHeaterOn();
		if(printerIOParameters.currentBedTemp>=printerIOParameters.desiredBedTemp)printerIOParameters.heatBedSt=HEAT_BED_HEAT_STEADY;
		break;

	case HEAT_BED_HEAT_STEADY:
		if(checkCntr++==10000)
		{
			checkCntr=0;
			if(printerIOParameters.currentBedTemp<printerIOParameters.desiredBedTemp)pwmPercent++;
			else if(printerIOParameters.currentBedTemp>printerIOParameters.desiredBedTemp)pwmPercent--;
			//edit start temporarily pwmPercent assigned to %30
			pwmPercent=30;
			//edit end
			pwmPercentCount=(pwmPercent*pwmPeriod)/100;

		}
		if(++pwmCntr>pwmPeriod)pwmCntr=0;
		if(pwmCntr<pwmPercentCount)
		{
			heatBedHeaterOn();
			heatBetonOf=1;
		}
		else
		{
			heatBedHeaterOff();
			heatBetonOf=0;
		}

		break;
	default:
		heatBedHeaterOff();
		break;

	}
}

void tempExtPWMOutCntrl()
{
	static uint8_t pwmPercent=40;
	static uint32_t checkCntr=0;
	static uint8_t pwmPeriod=50;
	static uint8_t pwmCntr=0;
	static uint8_t pwmPercentCount=20;

	switch(printerIOParameters.heatExtSt)
	{
	case EXT_HEAT_OFF:
		extruderHeaterOff();
		break;
	case EXT_HEAT_UP:
		extruderHeaterOn();
		break;

	case EXT_HEAT_UP_THEN_STEADY:
		extruderHeaterOn();
		if(printerIOParameters.currentExturderTemp>=printerIOParameters.desiredExturderTemp)printerIOParameters.heatExtSt=EXT_HEAT_STEADY;
		break;

	case EXT_HEAT_STEADY:
		if(checkCntr++==2000)
		{
			checkCntr=0;
			if(printerIOParameters.currentExturderTemp<printerIOParameters.desiredExturderTemp)pwmPercent=100;//pwmPercent++;
			else if(printerIOParameters.currentExturderTemp>printerIOParameters.desiredExturderTemp)pwmPercent=0;//pwmPercent--;
			pwmPercentCount=(pwmPercent*pwmPeriod)/100;
			// test start
//			extTempArray[extTempCntr][0]=printerIOParameters.currentExturderTemp;
//			extTempArray[extTempCntr++][1]=heatBetonOf;
			//test end
		}
		if(++pwmCntr>pwmPeriod)pwmCntr=0;
		if(pwmCntr<pwmPercentCount)extruderHeaterOn();
		else
		{
			extruderHeaterOff();
		}

		break;
	default:
		extruderHeaterOff();
		break;

	}
}

void setHistHeatBed(uint16_t hist)
{
	histHeatBed=hist;
}
void setHistHeatExt(uint16_t hist)
{
	histHeatExt=hist;
}


