/*
 * taksPrepare.h
 *
 *  Created on: 16 Mar 2019
 *      Author: yzcifci
 */

#ifndef TASKPREPARE_H_
#define TASKPREPARE_H_

#define MM_TO_INCH_MULT 25.4

extern struct prepData_
{
	float x;
	float y;
	float z;
	float e;

	uint8_t lengthMode;
	uint8_t incrementalMode;

}prepData;



void taskPrepare();
void updatePositions(char *add);
void convertDatasInchesToMetric(char *add);
void setPositions(char *add);

#endif /* TASKPREPARE_H_ */
