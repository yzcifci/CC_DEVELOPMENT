/*
 * parameters.c
 *
 *  Created on: 7 Oca 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"
/*
 * accelerating feed rate table
 * starts from feed value that is the maximum
 * feed rate in the start stop reigon and stops maximum feed rate
 */
float feedRateTable[256]={

};



int32_t mmToStepX(float mm)
{
	if((mm<WORK_AREA_START_MM_X) || (mm>WORK_AREA_STOP_MM_X))
	{
		parameterError(PARAMETER_X_OUTSIDE_WORK_AREA);
	}

	return((mm*STEPS_PER_ROTATION_X)/MM_PER_ROTATION_X);
}

int32_t mmToStepY(float mm)
{
	if((mm<WORK_AREA_START_MM_Y) || (mm>WORK_AREA_STOP_MM_Y))
	{
		parameterError(PARAMETER_Y_OUTSIDE_WORK_AREA);
	}
	return((mm*STEPS_PER_ROTATION_Y)/MM_PER_ROTATION_Y);
}

int32_t mmToStepZ(float mm)
{
	if((mm<WORK_AREA_START_MM_Z) || (mm>WORK_AREA_STOP_MM_Z))
	{
		parameterError(PARAMETER_Z_OUTSIDE_WORK_AREA);
	}
	return((mm*STEPS_PER_ROTATION_Z)/MM_PER_ROTATION_Z);
}

int32_t mmToStepE(float mm)
{
	return((mm*STEPS_PER_ROTATION_E)/MM_PER_ROTATION_E);
}


float stepTommX(int64_t step)
{
	float val1;
	float val2;
	float val3;
	val1=((float)step*MM_PER_ROTATION_X);
	val2=STEPS_PER_ROTATION_X;
	val3=val1/val2;
	return val3;
	val1= (float)(((float)(step*MM_PER_ROTATION_X))/STEPS_PER_ROTATION_X);
	return val1;
}

float stepTommY(int64_t step)
{
	return (float)(((float)step*MM_PER_ROTATION_Y)/STEPS_PER_ROTATION_Y);
}

float stepTommZ(int64_t step)
{
	return (float)(((float)step*MM_PER_ROTATION_Z)/STEPS_PER_ROTATION_Z);
}



void setInchToMM (positionXYZE *position)
{
	position->X*=INCHES_TO_MM;
	position->Y*=INCHES_TO_MM;
	position->Z*=INCHES_TO_MM;
	position->E*=INCHES_TO_MM;
}




uint16_t getPulsePeriodX(float feedRateX)
{
	if(!feedRateX)return 0;
	uint16_t pulsePeriod=((60*MM_PER_ROTATION_X*TIME_DIVISION_PER_SEC)/(feedRateX*STEPS_PER_ROTATION_X));
	return pulsePeriod;
}


uint16_t getPulsePeriodY(float feedRateY)
{
	if(!feedRateY)return 0;
	uint16_t pulsePeriod=((60*MM_PER_ROTATION_Y*TIME_DIVISION_PER_SEC)/(feedRateY*STEPS_PER_ROTATION_Y));
	return pulsePeriod;
}

uint16_t getPulsePeriodZ(float feedRateZ)
{
	if(!feedRateZ)return 0;
	uint16_t pulsePeriod=((60*MM_PER_ROTATION_Z*TIME_DIVISION_PER_SEC)/(feedRateZ*STEPS_PER_ROTATION_Z));
	return pulsePeriod;
}




/*
 * returns the angle in terms of degree
 * inputs: in terms of step
 * output : interm of float
 */
float arctan(uint32_t stepX1, uint32_t stepY1, uint32_t stepX2, uint32_t stepY2)
{
	float angle;
	float tanVal;
	uint32_t absValX;
	uint32_t absValY;
	absValX=absDifferentiate(stepX2,stepX1);
	absValY=absDifferentiate(stepY2,stepY1);
	if((absValX!=0) && (absValY!=0))
	{
		tanVal=(float)((float)absValY/(float)absValX);
		angle= ((atan(tanVal))*360)/(2*PI);

		if((stepX1<stepX2)&&(stepY1>stepY2)) //east north
		{
			return (angle);
		}
		else if((stepX1>stepX2)&&(stepY1>stepY2)) // west north
		{
			return (180-angle);
		}
		else if((stepX1>stepX2)&&(stepY1<stepY2)) //- + 2. reigon
		{
			return (180+angle);
		}
		else if((stepX1<stepX2)&&(stepY1<stepY2)) //- + 2. reigon
		{
			return (360-angle);
		}
	}
	else
	{
		if((stepX1==stepX2)&&(stepY1<stepY2))
		{
			return 270;
		}
		else if((stepX1==stepX2)&&(stepY1>stepY2))
		{
			return 90;
		}
		else if((stepX1>stepX2)&&(stepY1==stepY2))
		{
			return 180;
		}
		else if((stepX1<stepX2)&&(stepY1==stepY2))
		{
			return 0;
		}
		else if((stepX1==stepX2)&&(stepY1==stepY2))
		{
			return 0;
		}
	}

	return angle;

}
float angleToRad(float angle)
{
	return ((angle/360)*2*PI);
}
float getLinearmmLength(float startX, float startY, float stopX, float stopY)
{
	float subX=(stopX-startX);
	float subY=(stopY-startY);
	float subLength=sqrt((subX*subX)+(subY*subY));
	return subLength;
}


void updataPosStepToMM(uniPosXYZE* position)
{
	position->mmPosition.X=stepTommX(position->stepPosition.stepX);
	position->mmPosition.Y=stepTommY(position->stepPosition.stepY);
	position->mmPosition.Z=stepTommZ(position->stepPosition.stepZ);
}

uint32_t absDifferentiate(uint32_t val1, uint32_t val2)
{
	if(val1>val2)return (val1-val2);
	return (val2-val1);
}

void parameterError(uint16_t index)
{
	systemOFF();
	while(1);
	//todo will be inserted here
}


char getDir(uint32_t startPosAxis, uint32_t stopPosAxis)
{
	if(stopPosAxis>startPosAxis) return DIR_POSITIVE;
	else
		return DIR_NEGATIVE;
}
