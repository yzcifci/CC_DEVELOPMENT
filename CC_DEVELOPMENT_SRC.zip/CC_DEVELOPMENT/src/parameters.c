/*
 * parameters.c
 *
 *  Created on: 7 Oca 2018
 *      Author: yzcifci
 */

#include "main.h"
/*
 * accelerating feed rate table
 * starts from feed value that is the maximum
 * feed rate in the start stop reigon and stops maximum feed rate
 */



int32_t mmToStepX(float mm)
{
	if((mm<WORK_AREA_START_MM_X) || (mm>WORK_AREA_STOP_MM_X))
	{
		parameterError(PARAMETER_X_OUTSIDE_WORK_AREA);
	}

	return((mm*STEPS_PER_ROTATION_X*deviceControl.microStepX)/MM_PER_ROTATION_X);
}

int32_t mmToStepY(float mm)
{
	if((mm<WORK_AREA_START_MM_Y) || (mm>WORK_AREA_STOP_MM_Y))
	{
		parameterError(PARAMETER_Y_OUTSIDE_WORK_AREA);
	}
	return((mm*STEPS_PER_ROTATION_Y*deviceControl.microStepY)/MM_PER_ROTATION_Y);
}

int32_t mmToStepZ(float mm)
{
	if((mm<WORK_AREA_START_MM_Z) || (mm>WORK_AREA_STOP_MM_Z))
	{
		parameterError(PARAMETER_Z_OUTSIDE_WORK_AREA);
	}
	return((mm*STEPS_PER_ROTATION_Z*deviceControl.microStepZ)/MM_PER_ROTATION_Z);
}

int32_t mmToStepE(float mm)
{
	return((mm*STEPS_PER_ROTATION_E*deviceControl.microStepE)/MM_PER_ROTATION_E);
}


float stepTommX(int64_t step)
{
	float val1;
	float val2;
	float val3;
	val1=((float)step*MM_PER_ROTATION_X);
	val2=STEPS_PER_ROTATION_X;
	val3=val1/val2;
	return val3;
	val1= (float)(((float)(step*MM_PER_ROTATION_X))/STEPS_PER_ROTATION_X);
	return val1;
}

float stepTommY(int64_t step)
{
	return (float)(((float)step*MM_PER_ROTATION_Y)/STEPS_PER_ROTATION_Y);
}

float stepTommZ(int64_t step)
{
	return (float)(((float)step*MM_PER_ROTATION_Z)/STEPS_PER_ROTATION_Z);
}



void setInchToMM (positionXYZE *position)
{
	position->X*=INCHES_TO_MM;
	position->Y*=INCHES_TO_MM;
	position->Z*=INCHES_TO_MM;
	position->E*=INCHES_TO_MM;
}

float getPulsePeriodXFrac(float feedRateX)
{
	if(!feedRateX)return 0;
	float pulsePeriod=((60*(MM_PER_ROTATION_X/deviceControl.microStepX)*TIME_DIVISION_PER_SEC)/(feedRateX*STEPS_PER_ROTATION_X));
	return pulsePeriod;
}


float getPulsePeriodYFrac(float feedRateY)
{
	if(!feedRateY)return 0;
	float pulsePeriod=((60*(MM_PER_ROTATION_Y/deviceControl.microStepY)*TIME_DIVISION_PER_SEC)/(feedRateY*STEPS_PER_ROTATION_Y));
	return pulsePeriod;
}

float getPulsePeriodEFrac(float feedRateE)
{
	if(!feedRateE)return 0;
	float pulsePeriod=((60*(MM_PER_ROTATION_E/deviceControl.microStepE)*TIME_DIVISION_PER_SEC)/(feedRateE*STEPS_PER_ROTATION_E));
	return pulsePeriod;
}

uint16_t getPulsePeriodX(float feedRateX)
{
	if(!feedRateX)return 0;
	uint16_t pulsePeriod=((60*(MM_PER_ROTATION_X/deviceControl.microStepX)*TIME_DIVISION_PER_SEC)/(feedRateX*STEPS_PER_ROTATION_X));
	return pulsePeriod;
}


uint16_t getPulsePeriodY(float feedRateY)
{
	if(!feedRateY)return 0;
	uint16_t pulsePeriod=((60*(MM_PER_ROTATION_Y/deviceControl.microStepY)*TIME_DIVISION_PER_SEC)/(feedRateY*STEPS_PER_ROTATION_Y));
	return pulsePeriod;
}

uint16_t getPulsePeriodZ(float feedRateZ)
{
	if(!feedRateZ)return 0;
	uint16_t pulsePeriod=(((60*MM_PER_ROTATION_Z*TIME_DIVISION_PER_SEC)/deviceControl.microStepZ)/(feedRateZ*STEPS_PER_ROTATION_Z));
	return pulsePeriod;
}




/*
 * returns the angle in terms of degree
 * inputs: in terms of step
 * output : interm of float
 */
float arctan(uint32_t stepX1, uint32_t stepY1, uint32_t stepX2, uint32_t stepY2)
{
	float angle;
	float tanVal;
	uint32_t absValX;
	uint32_t absValY;
	absValX=absDifferentiate(stepX2,stepX1);
	absValY=absDifferentiate(stepY2,stepY1);
	if((absValX!=0) && (absValY!=0))
	{
		tanVal=(float)((float)absValY/(float)absValX);
		angle= ((atan(tanVal))*360)/(2*PI);

		if((stepX1<stepX2)&&(stepY1>stepY2)) //east north
		{
			return (angle);
		}
		else if((stepX1>stepX2)&&(stepY1>stepY2)) // west north
		{
			return (180-angle);
		}
		else if((stepX1>stepX2)&&(stepY1<stepY2)) //- + 2. reigon
		{
			return (180+angle);
		}
		else if((stepX1<stepX2)&&(stepY1<stepY2)) //- + 2. reigon
		{
			return (360-angle);
		}
	}
	else
	{
		if((stepX1==stepX2)&&(stepY1<stepY2))
		{
			return 270;
		}
		else if((stepX1==stepX2)&&(stepY1>stepY2))
		{
			return 90;
		}
		else if((stepX1>stepX2)&&(stepY1==stepY2))
		{
			return 180;
		}
		else if((stepX1<stepX2)&&(stepY1==stepY2))
		{
			return 0;
		}
		else if((stepX1==stepX2)&&(stepY1==stepY2))
		{
			return 0;
		}
	}

	return angle;

}


/*
 * returns the angle in terms of degree
 * inputs: in terms of step
 * output : interm of float
 */
float arctanFloatInpRad0_90(float x1, float y1, float x2, float y2)
{
	float angle;
	float angleRad;
	float tanVal;
	float absValX;
	float absValY;
	absValX=fabs(x2-x1);
	absValY=fabs(y2-y1);
	if((absValX!=0) && (absValY!=0))
	{
		tanVal=(float)((float)absValY/(float)absValX);
		angleRad= atan(tanVal);
	}
	else
	{
		if((x1==x2)&&(y1<y2))
		{
			angle= 90;
		}
		else if((x1==x2)&&(y1>y2))
		{
			angle= 90;
		}
		else if((x1>x2)&&(y1==y2))
		{
			angle= 0;
		}
		else if((x1<x2)&&(y1==y2))
		{
			angle= 0;
		}
		else if((x1==x2)&&(y1==y2))
		{
			angle= 0;
		}
		angleRad=((angle*2*PI)/360);
	}
	return angleRad;
}

/*
 * returns the angle in terms of degree
 * inputs: in terms of step
 * output : interm of float
 */
float arctanFloatInpRad(float x1, float y1, float x2, float y2)
{
	float angle;
	float angleRad;
	float tanVal;
	float absValX;
	float absValY;
	absValX=fabs(x2-x1);
	absValY=fabs(y2-y1);
	if((absValX!=0) && (absValY!=0))
	{
		tanVal=(float)((float)absValY/(float)absValX);
		angle= ((atan(tanVal))*360)/(2*PI);

		if((x1<x2)&&(y1>y2)) //east north
		{
			// nothing
		}
		else if((x1>x2)&&(y1>y2)) // west north
		{
			angle= (180-angle);
		}
		else if((x1>x2)&&(y1<y2)) //- + 2. reigon
		{
			angle= (180+angle);
		}
		else if((x1<x2)&&(y1<y2)) //- + 2. reigon
		{
			angle= (360-angle);
		}
	}
	else
	{
		if((x1==x2)&&(y1<y2))
		{
			angle= 270;
		}
		else if((x1==x2)&&(y1>y2))
		{
			angle= 90;
		}
		else if((x1>x2)&&(y1==y2))
		{
			angle= 180;
		}
		else if((x1<x2)&&(y1==y2))
		{
			angle= 0;
		}
		else if((x1==x2)&&(y1==y2))
		{
			angle= 0;
		}
	}

	angleRad=(angle/360)*2*PI;
	return angleRad;

}

float getAngleFromMmPos(float subX, float subY)
{
	float angleRad=0;
	if(subX==0 && subY>0)angleRad=PI/2;
	else if(subX==0 && subY<0)angleRad=3*(PI/2);
	else if(subX>0 && subY==0)angleRad=0;
	else if(subX<0 && subY==0)angleRad=PI;
	else if(subX==0 && subY==0)angleRad=0;
	else
	{
		if(subX>0 && subY>0)
		{// 1. b�lge
			angleRad=atan(subY/subX);
		}
		else if(subX<0 && subY>0)
		{// 2. b�lge
			angleRad=PI-atan(fabs(subY/subX));
		}
		else if(subX<0 && subY<0)
		{// 3. b�lge
			angleRad=PI+atan(fabs(subY/subX));
		}
		else if(subX>0 && subY<0)
		{// 4. b�lge
			angleRad=(2*PI)-atan(fabs(subY/subX));
		}
	}
	return angleRad;
}

float getAngleFromStepPos(int32_t subX, int32_t subY)
{
	float angleRad=0;
	if(subX==0 && subY>0)angleRad=PI/2;
	else if(subX==0 && subY<0)angleRad=3*(PI/2);
	else if(subX>0 && subY==0)angleRad=0;
	else if(subX<0 && subY==0)angleRad=PI;
	else if(subX==0 && subY==0)angleRad=0;
	else
	{
		float slope=(float)((float)subY/(float)subX);
		if(subX>0 && subY>0)
		{// 1. b�lge
			angleRad=atan(slope);
		}
		else if(subX<0 && subY>0)
		{// 2. b�lge
			angleRad=PI-atan(fabs(slope));
		}
		else if(subX<0 && subY<0)
		{// 3. b�lge
			angleRad=PI+atan(fabs(slope));
		}
		else if(subX>0 && subY<0)
		{// 4. b�lge
			angleRad=(2*PI)-atan(fabs(slope));
		}
	}
	return angleRad;
}



float angleToRad(float angle)
{
	return ((angle/360)*2*PI);
}
float getLinearmmLength(float startX, float startY, float stopX, float stopY)
{
	float subX=(stopX-startX);
	float subY=(stopY-startY);
	float subLength=sqrt((subX*subX)+(subY*subY));
	return subLength;
}


void updataPosStepToMM(uniPosXYZE* position)
{
	position->mmPosition.X=stepTommX(position->stepPosition.stepX);
	position->mmPosition.Y=stepTommY(position->stepPosition.stepY);
	position->mmPosition.Z=stepTommZ(position->stepPosition.stepZ);
}

uint32_t absDifferentiate(uint32_t val1, uint32_t val2)
{
	if(val1>val2)return (val1-val2);
	return (val2-val1);
}

void parameterError(uint16_t index)
{
	systemOFF();
	while(1);
	//todo will be inserted here
}


char getDir(uint32_t startPosAxis, uint32_t stopPosAxis)
{
	if(stopPosAxis>startPosAxis) return DIR_POSITIVE;
	else
		return DIR_NEGATIVE;
}

uint16_t plusIndex(uint16_t index,uint16_t buffSize)
{
	index++;
	if(index>=buffSize)index=0;
	return index;
}



uint16_t minusIndex(uint16_t index,uint16_t buffSize)
{

	if(index==0)index=buffSize;
	else
	{
		index--;
	}
	return index;
}

uint16_t addSubtractIndex(uint16_t index,uint16_t buffSize,int16_t size)
{
	int32_t newIndex;
	newIndex=index+size;
	if(newIndex>buffSize)
	{
		newIndex=newIndex%buffSize;
	}
	else if(newIndex<0)newIndex=buffSize+newIndex;
	if((newIndex<0)||(newIndex>buffSize))errorLog(PARAMETER_INDEX_ADDITION_SUBTRACTION_ERROR);
	return (uint16_t)newIndex;
}


uint16_t getIndex(uint16_t currentIndex, int16_t offset, uint16_t fullScale)
{
	uint8_t index=currentIndex;
	if(offset>0)
	{
		if((currentIndex+offset)>=fullScale)
		{
			index=offset-(fullScale-currentIndex);
		}
		else
		{
			index=currentIndex+offset;
		}
	}
	else if(offset<0)
	{
		if(currentIndex<(-offset))
		{
			index=fullScale+currentIndex+offset;
		}
		else
		{
			index=currentIndex+offset;
		}
	}
	return index;
}


uint16_t binarySearch(uint16_t* array, uint16_t size, uint16_t search)
{
	uint16_t first, last, middle;

	if(search>array[size-1])return (size-1);
	else if(search<array[0])
		return 0;
	first = 0;
	last = size - 1;
	middle = (first+last)/2;

	while (first <= last)
	{
		if((array[middle]<search) && (search<array[middle+1]))
		{
			if((search-array[middle])>(array[middle+1]-search))
			{
				return middle+1;
			}
			else
			{
				return middle;
			}
		}

		else if (array[middle] < search)
		{
			first = middle + 1;
		}
		else if (array[middle] == search)
		{
			return middle;
		}

		else
			last = middle - 1;

		middle = (first + last)/2;
	}
	if (first > last)
		parameterError(BINARY_SEARCH_INDEX_ERROR);

	return 0;
}

