/*
 * parameters.c
 *
 *  Created on: 7 Oca 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"
/*
 * accelerating feed rate table
 * starts from feed value that is the maximum
 * feed rate in the start stop reigon and stops maximum feed rate
 */
float feedRateTable[256]={

};



uint32_t mmToStepX(float mm)
{
	return((mm*STEPS_PER_ROTATION_X)/MM_PER_ROTATION_X);
}

uint32_t mmToStepY(float mm)
{
	return((mm*STEPS_PER_ROTATION_Y)/MM_PER_ROTATION_Y);
}

uint32_t mmToStepZ(float mm)
{
	return((mm*STEPS_PER_ROTATION_Z)/MM_PER_ROTATION_Z);
}


float stepTommX(int64_t step)
{
	return (float)(((float)step*MM_PER_ROTATION_X)/STEPS_PER_ROTATION_X);
}

float stepTommY(int64_t step)
{
	return (float)(((float)step*MM_PER_ROTATION_Y)/STEPS_PER_ROTATION_Y);
}

float stepTommZ(int64_t step)
{
	return (float)(((float)step*MM_PER_ROTATION_Z)/STEPS_PER_ROTATION_Z);
}





uint16_t getPulsePeriodX(float feedRateX)
{
	if(!feedRateX)return 0;
	uint16_t pulsePeriod=((60*MM_PER_ROTATION_X)/(feedRateX*STEPS_PER_ROTATION_X))*10;
	return pulsePeriod;
}

uint16_t getPulsePeriodY(float feedRateY)
{
	if(!feedRateY)return 0;
	uint16_t pulsePeriod=((60*MM_PER_ROTATION_Y)/(feedRateY*STEPS_PER_ROTATION_Y))*10;
	return pulsePeriod;
}

uint16_t getPulsePeriodZ(float feedRateZ)
{
	if(!feedRateZ)return 0;
	uint16_t pulsePeriod=((60*MM_PER_ROTATION_Z)/(feedRateZ*STEPS_PER_ROTATION_Z))*10;
	return pulsePeriod;
}




/*
 * returns the angle in terms of degree
 * inputs: in terms of step
 * output : interm of float
 */
float arctan(uint16_t stepX1, uint16_t stepY1, uint16_t stepX2, uint16_t stepY2)
{
	float angle;
	float subx;
	float suby;

	subx=stepTommX((stepX2-stepX1));
	suby=stepTommY((stepY2-stepY1));
	angle= ((atan(suby/suby))*360)/(2*PI);
	if(angle<0)
	{
		if(subx<0)	angle+=180;
		else
		{
			angle+=360;
		}
	}
	else
	{
		if(subx<0)	angle+=180;
	}
	return angle;
}

float getLinearmmLength(float startX, float startY, float stopX, float stopY)
{
	float subX=(stopX-startX);
	float subY=(stopY-startY);
	float subLength=sqrt((subX*subX)+(subY*subY));
	return subLength;
}


void updataPosStepToMM(uniPosXYZ* position)
{
	position->mmPosition.X=stepTommX(position->stepPosition.stepX);
	position->mmPosition.Y=stepTommY(position->stepPosition.stepY);
	position->mmPosition.Z=stepTommZ(position->stepPosition.stepZ);
}

uint32_t absDifferentiate(uint32_t val1, uint32_t val2)
{
	if(val1>val2)return (val1-val2);
	return (val2-val1);
}
