/*
 * timer.h
 *
 *  Created on: 25 Ara 2017
 *      Author: yzcifci
 */

#ifndef TIMER_H_
#define TIMER_H_

/* Includes ------------------------------------------------------------------*/


//#include "stm32f4_discovery.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* User can use this section to tailor TIMx instance used and associated
   resources */
/* Definition for TIMx clock resources */
/*#define TIMx                           TIM3
#define TIMx_CLK_ENABLE                __HAL_RCC_TIM3_CLK_ENABLE
#define TIMx_IRQn                      TIM3_IRQn
#define TIMx_IRQHandler                TIM3_IRQHandler

#define TIM_STEP                        TIM2
#define TIM_STEP_CLK_ENABLE             __HAL_RCC_TIM2_CLK_ENABLE*/

/* Definition for TIMx's NVIC */




#define TIM_STEP                       		TIM7
#define TIM_STEP_CLK_ENABLE                __HAL_RCC_TIM7_CLK_ENABLE
#define TIM_STEP_IRQn                      TIM7_IRQn
#define TIM_STEP_IRQHandler                TIM7_IRQHandler


#define TIM_X                       	TIM2
#define TIM_X_CLK_ENABLE                __HAL_RCC_TIM2_CLK_ENABLE
#define TIM_X_IRQn                      TIM2_IRQn
#define TIM_X_IRQHandler                TIM2_IRQHandler


#define TIM_Y                       	TIM4
#define TIM_Y_CLK_ENABLE                __HAL_RCC_TIM4_CLK_ENABLE
#define TIM_Y_IRQn                      TIM4_IRQn
#define TIM_Y_IRQHandler                TIM4_IRQHandler


#define TIM_E                       	TIM5
#define TIM_E_CLK_ENABLE                __HAL_RCC_TIM5_CLK_ENABLE
#define TIM_E_IRQn                      TIM5_IRQn
#define TIM_E_IRQHandler                TIM5_IRQHandler


#define TIM_GLOBAL                       		TIM3
#define TIM_GLOBAL_CLK_ENABLE                __HAL_RCC_TIM3_CLK_ENABLE
#define TIM_GLOBAL_IRQn                      TIM3_IRQn
#define TIM_GLOBAL_IRQHandler                TIM3_IRQHandler

/* Exported functions ------------------------------------------------------- */

typedef uint8_t (*moveCallBack_)(void);

extern struct timerControl_
{
	uint64_t globalCntr;
	uint32_t stepCntr;
	moveCallBack_ moveCallBack;
	moveCallBack_ moveCallBackX;
	moveCallBack_ moveCallBackY;
	moveCallBack_ moveCallBackZ;
	moveCallBack_ moveCallBackE;

}timerControl;

extern  void Error_Handler(void);
void timerError(uint16_t index);
void initTimer();
void setTimStepCallBack(uint32_t add);
void setTimX(uint32_t add);
void setTimY(uint32_t add);
void setTimZ(uint32_t add);
void setTimE(uint32_t add);
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim);

void setTX(float t);
void setTY(float t);
void setTE(float t);

void setStepTimT(float t);
void setGlobalTimT(float t);
void periodicGlobal1msCallBack();
void periodicGlobal100msCallBack();
void periodicGlobal500msCallBack();
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

#endif /* TIMER_H_ */
