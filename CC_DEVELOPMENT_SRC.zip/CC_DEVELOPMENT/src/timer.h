/*
 * timer.h
 *
 *  Created on: 25 Ara 2017
 *      Author: yzcifci
 */

#ifndef TIMER_H_
#define TIMER_H_

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include "parameters.h"

//#include "stm32f4_discovery.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* User can use this section to tailor TIMx instance used and associated
   resources */
/* Definition for TIMx clock resources */
#define TIMx                           TIM3
#define TIMx_CLK_ENABLE                __HAL_RCC_TIM3_CLK_ENABLE

/* Definition for TIMx's NVIC */
#define TIMx_IRQn                      TIM3_IRQn
#define TIMx_IRQHandler                TIM3_IRQHandler

/* Exported functions ------------------------------------------------------- */

extern struct timerControl_
{
uint64_t globalCntr;
uint32_t xPulsePeriod;
uint32_t yPulsePeriod;
uint32_t zPulsePeriod;
}timerControl;
extern  void Error_Handler(void);
void initTimer();
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim);
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

#endif /* TIMER_H_ */
