/*
 * task_operator_interface.h
 *
 *  Created on: 15 �ub 2018
 *      Author: yzcifci
 */

#ifndef TASK_OPERATOR_INTERFACE_H_
#define TASK_OPERATOR_INTERFACE_H_

#include <testIO.h>
#include "parameters.h"
#include "Gparser.h"
#include "auxiliaryOperator.h"
#include "feed_rate_controller.h"
#include "GPIO_control.h"
#include "linear_interpolation.h"
#include "movement_control.h"
#include "serialCom.h"
#include "serialComController.h"
#include "circular_interpolation.h"
#include "timer.h"
#include "test.h"
#include "serialTest.h"
#include "testIO.h"
#include "periph_control_3d.h"
#include "adc_control.h"

#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

enum
{
	OPERATOR_PARSER_BUFFER_NOT_FULL,
	OPERATOR_BUFFER_FULL,
	PARSER_BUFFER_FULL,
	OPERATOR_PARSER_BUFFER_FULL,
};
extern struct operatorParserStateMachine_
{
	uint8_t operatorParserState;
	struct
	{
		uint32_t operatorFull:1;
		uint32_t parserFull:1;
		uint32_t resetOperatorIndex:1;
		uint32_t resetParserIndex:1;
	}status;

}operatorParserStateMachine;


uint8_t operatorParserStateControl();
void initSystem();
#endif /* TASK_OPERATOR_INTERFACE_H_ */
