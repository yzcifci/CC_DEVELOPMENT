/*
 * main.h
 *
 *  Created on: 9 Haz 2019
 *      Author: yzcifci
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "stm32f4xx_hal.h"

#include "main.h"
#include "Gparser.h"
#include "GPIO_control.h"
#include "serialCom.h"
#include "timer.h"
#include "test.h"
#include "serialTest.h"
#include "adc_control.h"
#include "M_func_control.h"
#include "operator_control.h"
#include "fatfs_control.h"
#include "ntc_res_table.h"
#include "accelerationControl.h"
#include "stepper.h"
#include "taskPrepare.h"
#include "temperature_control.h"


#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

#endif /* MAIN_H_ */
