/*
 * temperature_control.h
 *
 *  Created on: 19 May 2019
 *      Author: yzcifci
 */

#ifndef TEMPERATURE_CONTROL_H_
#define TEMPERATURE_CONTROL_H_

int16_t readBedTemp();
int16_t readExtruderTemp();
void extruderTempControl();
void bedTempControl();
void readBedTempCurrent();
void tempControl();
void tempBedPWMOutCntrl();
void tempExtPWMOutCntrl();
void setHistHeatBed(uint16_t hist);
void setHistHeatExt(uint16_t hist);


#endif /* TEMPERATURE_CONTROL_H_ */
