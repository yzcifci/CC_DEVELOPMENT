/*
 * auxiliaryOperator.h
 *
 *  Created on: 16 �ub 2018
 *      Author: yzcifci
 */

#ifndef AUXILIARYOPERATOR_H_
#define AUXILIARYOPERATOR_H_

#include "parameters.h"

#define T1_POSITION_X	10
#define T1_POSITION_Y   10
#define T1_POSITION_Z	10
#define T1_POSITION_Z_PUT_OFFSET	10

enum
{
	TOOL_CHANGE_START,
	TOOL_GOTO_CHANGE_POSITION,
	TOOL_GOTO_PUT_POSITION,
	TOOL_PUT,
	TOOL_GOBACK_PUT_POSITION,
	TOOL_GOTO_PULL_POSITION,
	TOOL_PULL,
	TOOL_GOBACK_PULL_POSITION,
	TOOL_GOBACK_CHANGE_POSITION,
	TOOL_CHANGE_END
};

enum
{
	GOTO_POSITION_START,
	GOTO_POSITION_RUNNING,
	GOTO_POSITION_END
};

extern struct toolChangeController_
{
uint8_t tool;
uint8_t state;
uint8_t positionControlState;

}toolChangeController;


uint8_t MfunctionExecuter(uint8_t mFunction);
uint8_t setSpeedExecuter(uint16_t speed);
#endif /* AUXILIARYOPERATOR_H_ */
