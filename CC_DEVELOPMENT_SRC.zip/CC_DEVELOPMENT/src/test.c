/*
 * test.c
 *
 *  Created on: 22 �ub 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

char testGlineData[256]={"G00 X0.745 Y3.876 Z1.34\n"};
void gLineSendTest()
{
	uint16_t cntr=0;
	while(testGlineData[cntr]!='\n')
	{
		serialLineParser(testGlineData[cntr]);
		cntr++;
	}
	serialLineParser('\n');

}
