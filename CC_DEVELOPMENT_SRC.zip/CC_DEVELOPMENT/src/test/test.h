/*
 * test.h
 *
 *  Created on: 22 �ub 2018
 *      Author: yzcifci
 */

#ifndef TEST_H_
#define TEST_H_

#define MOVEMENT_TEST_ENABLE 0

extern struct movementTest_
{
	char sendBuffer[32];
	uint32_t stepX;
	uint32_t stepY;
	uint32_t stepZ;
	uint8_t dirX;
	uint8_t dirY;
	uint8_t dirZ;

}movementTest;


void gLineSendTest();
void movementTestHandler(uint8_t coordinate, uint8_t dir);
void movementSerialTest();
void limitSwitchTest();
void moveXtest();
void moveYtest();
void moveZtest();
void moveEtest();
void readLimXTest();
void readLimYTest();
void readLimZTest();
void moveXYZbackwardTest();
void moveExtruderTest();
void readExtruderTempTest();
void readHeatBedTempTest();
void IOtoggleTest();
#endif /* TEST_H_ */
