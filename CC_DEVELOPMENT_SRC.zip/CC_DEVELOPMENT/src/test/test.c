/*
 * test.c
 *
 *  Created on: 22 Þub 2018
 *      Author: yzcifci
 */

#include "main.h"

struct movementTest_ movementTest;




void movementTestHandler(uint8_t coordinate, uint8_t dir)
{
	static uint8_t cntrx=0;
	static uint8_t cntry=0;
	static uint8_t cntrz=0;
	char sendData=0;

	switch (coordinate)
	{
	case COORDINATE_X:
		if(((++cntrx)%2)!=0)return;
		if(dir)movementTest.stepX++;
		else
			movementTest.stepX--;

		movementTest.dirX=dir;
		sendData=(dir<<2);
		putChar(sendData);
		break;
	case COORDINATE_Y:
		if(((++cntry)%2)!=0)return;
		if(dir)movementTest.stepY++;
		else
			movementTest.stepY--;

		movementTest.dirY=dir;
		sendData=((dir<<2)|0x01);
		putChar(sendData);
		break;
	case COORDINATE_Z:
		if(((++cntrz)%2)!=0)return;
		if(dir)movementTest.stepZ++;
		else
			movementTest.stepZ--;

		movementTest.dirZ=dir;
		sendData=((dir<<2)|0x02);
		putChar(sendData);
		break;
	}
	//	printLine("START");
	//
	//	movementTest.sendBuffer[0]=movementTest.stepX;
	//	movementTest.sendBuffer[1]=movementTest.stepX>>8;
	//	movementTest.sendBuffer[2]=movementTest.stepX>>16;
	//	movementTest.sendBuffer[3]=movementTest.stepX>>24;
	//	movementTest.sendBuffer[4]=movementTest.stepY;
	//	movementTest.sendBuffer[5]=movementTest.stepY>>8;
	//	movementTest.sendBuffer[6]=movementTest.stepY>>16;
	//	movementTest.sendBuffer[7]=movementTest.stepY>>24;
	//	movementTest.sendBuffer[8]=movementTest.stepZ;
	//	movementTest.sendBuffer[9]=movementTest.stepZ>>8;
	//	movementTest.sendBuffer[10]=movementTest.stepZ>>16;
	//	movementTest.sendBuffer[11]=movementTest.stepZ>>24;
	//	movementTest.sendBuffer[12]=movementTest.dirX;
	//	movementTest.sendBuffer[13]=movementTest.dirY;
	//	movementTest.sendBuffer[14]=movementTest.dirZ;
	//
	//	serialPrint((char*)&movementTest.sendBuffer,15);
	//	printLine("END");
}







void movementSerialTest()
{
	printLine("STARTSYSTEM");
	while(1)
	{
		HAL_Delay(50);
		movementTestHandler(COORDINATE_X, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Y, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Z, 1);
	}
}


void limitSwitchTest()
{
	/*
	uint8_t limitSwitchX=LIMIT_SWITCH_NOT_PRESSED;
	uint8_t limitSwitchY=LIMIT_SWITCH_NOT_PRESSED;
	uint8_t limitSwitchZ=LIMIT_SWITCH_NOT_PRESSED;
	while(1)
	{
		limitSwitchX=readLimitSwitchX();
		limitSwitchY=readLimitSwitchY();
		limitSwitchZ=readLimitSwitchZ();
		HAL_Delay(100);
	}*/
}


void moveXtest()
{
	uint32_t moveCntr=0;
	setDirX(1);
	HAL_GPIO_WritePin(PORT_X1,PIN_X1,GPIO_PIN_SET);
	while(moveCntr++<20000)
	{
		HAL_Delay(2);
		HAL_GPIO_TogglePin(PORT_X1,PIN_X1);
	}
}

void moveYtest()
{
	uint32_t moveCntr=0;
	setDirY(1);
	HAL_GPIO_WritePin(PORT_Y,PIN_Y,GPIO_PIN_SET);
	while(moveCntr++<20000)
	{
		HAL_Delay(2);
		HAL_GPIO_TogglePin(PORT_Y,PIN_Y);
	}
}

void moveZtest()
{
	uint32_t stepCntr=0;
	HAL_GPIO_WritePin(PORT_Z,PIN_Z,GPIO_PIN_SET);

	setDirZ(1);
	while(stepCntr<5000)
	{
		HAL_Delay(2);
		HAL_GPIO_TogglePin(PORT_Z,PIN_Z);
		stepCntr++;
	}

	setDirZ(0);
	stepCntr=0;
	while(stepCntr<5000)
	{
		HAL_Delay(2);
		HAL_GPIO_TogglePin(PORT_Z,PIN_Z);
		stepCntr++;
	}
}

void moveEtest()
{
	uint32_t moveCntr=0;
	setDirE(1);
	HAL_GPIO_WritePin(PORT_E,PIN_E,GPIO_PIN_SET);
	while(moveCntr++<20000)
	{
		HAL_Delay(2);
		HAL_GPIO_TogglePin(PORT_E,PIN_E);
	}
}

void readLimXTest()
{
	while(1)
	{
		if(readLimitSwitchX()==1)HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_RESET);
		else
		{
			HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_SET);
		}
		HAL_Delay(100);
	}
}

void readLimYTest()
{
	while(1)
	{
		if(readLimitSwitchY()==1)HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_RESET);
		else
		{
			HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_SET);
		}
		HAL_Delay(100);
	}
}


void readLimZTest()
{
	while(1)
	{
		if(readLimitSwitchZ()==1)HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_RESET);
		else
		{
			HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_SET);
		}
		HAL_Delay(100);
	}
}



void moveXYZbackwardTest()
{
	startStep(1,1,1,1, 100,100,100,100);
	while(1)
	{
		toggleX(0);
		toggleY(0);
		toggleZ(0);
		HAL_Delay(10);
	}
}


void moveExtruderTest()
{
	uint32_t cntrx=0;
	while(cntrx<10000)
	{
		toggleE(1);
		HAL_Delay(2);
		cntrx++;
	}
}

void readExtruderTempTest()
{
	/*
	volatile uint16_t temp;
	//	extruderHeaterOn();
	//	HAL_Delay(20000);
	//	extruderHeaterOff();
	while(1)
	{
		startADCconversions();
		HAL_Delay(50);
		temp=readExtruderTemp();
		HAL_Delay(200);

	}*/

}


void readHeatBedTempTest()
{
	/*
	volatile uint16_t temp;
	heatBedHeaterOn();
	HAL_Delay(30000);
	heatBedHeaterOff();
	while(1)
	{
		startADCconversions();
		HAL_Delay(50);
		temp=readBedTemp();
		HAL_Delay(200);

	}
	*/

}


uint8_t limxTest=2;
uint8_t limyTest=2;
uint8_t limzTest=2;
void IOtoggleTest()
{
	/*init pa0 pa1 as gpio for ıo test */
	GPIO_InitTypeDef  GPIO_InitStruct;
	GPIO_InitStruct.Pin = GPIO_PIN_0;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(GPIOA);
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);


	GPIO_InitStruct.Pin = GPIO_PIN_1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(GPIOA);
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);




	while(1)
	{
		HAL_GPIO_TogglePin(PORT_X1, PIN_X1);
		HAL_GPIO_TogglePin(PORT_Y, PIN_Y);
		HAL_GPIO_TogglePin(PORT_Z, PIN_Z);
		HAL_GPIO_TogglePin(PORT_E, PIN_E);

		HAL_GPIO_TogglePin(ENABLE_PORT_X1, ENABLE_PIN_X1);
		HAL_GPIO_TogglePin(ENABLE_PORT_Y, ENABLE_PIN_Y);
		HAL_GPIO_TogglePin(ENABLE_PORT_Z, ENABLE_PIN_Z);
		HAL_GPIO_TogglePin(ENABLE_PORT_E, ENABLE_PIN_E);

		HAL_GPIO_TogglePin(DIR_PORT_X1, DIR_PIN_X1);
		HAL_GPIO_TogglePin(DIR_PORT_Y, DIR_PIN_Y);
		HAL_GPIO_TogglePin(DIR_PORT_Z, DIR_PIN_Z);
		HAL_GPIO_TogglePin(DIR_PORT_E, DIR_PIN_E);

		HAL_GPIO_TogglePin(PORT_SLP_CLKX, PIN_SLP_CLKX);
		HAL_GPIO_TogglePin(PORT_SLP_CLKY, PIN_SLP_CLKY);
		HAL_GPIO_TogglePin(PORT_SLP_CLKZ, PIN_SLP_CLKZ);
		HAL_GPIO_TogglePin(PORT_SLP_CLKE, PIN_SLP_CLKE);

		HAL_GPIO_TogglePin(PORT_RST_PDNX, PIN_RST_PDNX);
		HAL_GPIO_TogglePin(PORT_RST_PDNY, PIN_RST_PDNY);
		HAL_GPIO_TogglePin(PORT_RST_PDNZ, PIN_RST_PDNZ);
		HAL_GPIO_TogglePin(PORT_RST_PDNE, PIN_RST_PDNE);

		HAL_GPIO_TogglePin(LIMIT_SWITCH_PORT_X, LIMIT_SWITCH_PIN_X);
		HAL_GPIO_TogglePin(LIMIT_SWITCH_PORT_Y, LIMIT_SWITCH_PIN_Y);
		HAL_GPIO_TogglePin(LIMIT_SWITCH_PORT_Z, LIMIT_SWITCH_PIN_Z);

		HAL_GPIO_TogglePin(PORTX_MS1, PORTX_PIN_MS1);
		HAL_GPIO_TogglePin(PORTX_MS2, PORTX_PIN_MS2);
		HAL_GPIO_TogglePin(PORTX_MS3, PORTX_PIN_MS3);

		HAL_GPIO_TogglePin(PORTY_MS1, PORTY_PIN_MS1);
		HAL_GPIO_TogglePin(PORTY_MS2, PORTY_PIN_MS2);
		HAL_GPIO_TogglePin(PORTY_MS3, PORTY_PIN_MS3);

		HAL_GPIO_TogglePin(PORTZ_MS1, PORTZ_PIN_MS1);
		HAL_GPIO_TogglePin(PORTZ_MS2, PORTZ_PIN_MS2);
		HAL_GPIO_TogglePin(PORTZ_MS3, PORTZ_PIN_MS3);

		HAL_GPIO_TogglePin(PORTE_MS1, PORTE_PIN_MS1);
		HAL_GPIO_TogglePin(PORTE_MS2, PORTE_PIN_MS2);
		HAL_GPIO_TogglePin(PORTE_MS3, PORTE_PIN_MS3);

		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_0);
		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_1);

//		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_15);
//		HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_9);
//		HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_11);

		limxTest=readLimitSwitchX();
		limyTest=readLimitSwitchY();
		limzTest=readLimitSwitchZ();



		HAL_Delay(1000);
	}
}


