/*
 * test.c
 *
 *  Created on: 22 �ub 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct movementTest_ movementTest;



char testGlineData[]={

//		"M106\n"
//		"M190 S60\n"

//		"M109 S205\n"

//		"G28 X0 Y0\n"

//		"G1 F1800 X30 Y30 Z30\n"
//		"G1 F1800 X40 Y40 Z40\n"
		"G28 X0 Y0 Z0\n"



//		";FLAVOR:Marlin\n"
//		";TIME:2455\n"
//		";Filament used: 2.42322m\n"
//		";Layer height: 0.15\n"
//		";Generated with Cura_SteamEngine 3.2.1\n"
//		"M190 S60\n"
//		"M104 S215\n"
//		"M109 S215\n"
//		"M82 ;absolute extrusion mode\n"
//		"G21 ;metric values\n"
//		"G90 ;absolute positioning\n"
//		"M82 ;set extruder to absolute mode\n"
//		"M107 ;start with the fan off\n"
//		"G28 X0 Y0 ;move X/Y to min endstops\n"
//		"G28 Z0 ;move Z to min endstops\n"
//		"G1 Z15.0 F9000 ;move the platform down 15mm\n"
//		"G92 E0 ;zero the extruded length\n"
//		"G1 F200 E3 ;extrude 3mm of feed stock\n"
//		"G92 E0 ;zero the extruded length again\n"
//		"G1 F9000\n"
//		";Put printing message on LCD screen\n"
//		"M117 Printing...\n"
//		";LAYER_COUNT:139\n"
//		";LAYER:0\n"
//		"M107\n"
//		"G0 F3600 X82.08 Y70.375 Z0.3\n"
//		";TYPE:SKIRT\n"
//		"G1 F1800 X82.485 Y69.938 E0.02973\n"
//		"G1 X82.602 Y69.821 E0.03798\n"
//		"G1 X83.188 Y69.291 E0.0774\n"
//		"G1 X83.824 Y68.824 E0.11677\n"
//		"G1 X84.504 Y68.423 E0.15615\n"
//		"G1 X85.222 Y68.093 E0.19557\n"
//		"G1 X85.969 Y67.838 E0.23495\n"
//		"G1 X86.738 Y67.659 E0.27434\n"
//		"G1 X87.522 Y67.559 E0.31378\n"
//		"G1 X88.117 Y67.536 E0.34348\n"
//		"G1 X111.883 Y67.536 E1.52917\n"
//		"G1 X112.672 Y67.576 E1.56859\n"
//		"G1 X113.452 Y67.695 E1.60795\n"
//		"G1 X114.217 Y67.893 E1.64737\n"
//		"G1 X114.957 Y68.167 E1.68674\n"
//		"G1 X115.666 Y68.515 E1.72615\n"
//		"G1 X116.337 Y68.933 E1.76559\n"
//		"G1 X116.961 Y69.416 E1.80495\n"





		//		"G1 F1800 X0 Y0 Z0\n"
		//		"G1 F1800 X0 Y0 Z30\n"
		//		"G1 F1800 X0 Y0 Z0\n"
		//		"G1 F1800 X0 Y0 Z30\n"
		//		"G1 F1800 X0 Y0 Z0\n"

		//		"G1 F1800 X0 Y0 Z0\n"
		//		"G1 F1800 X30 Y30 Z30\n"
		//		"G1 F1800 X0 Y0 Z0\n"
		//		"G1 F1800 X30 Y30 Z30\n"
		//		"G1 F1800 X0 Y0 Z0\n"
		//		"G1 F1800 X30 Y30 Z30\n"
		//		"G1 F1800 X0 Y0 Z0\n"
		//		"G1 F1800 X30 Y30 Z30\n"
		//		"G1 F1800 X0 Y0 Z0\n"
		//		"G1 F1800 X30 Y30 Z30\n"

//		"G1 F1250 X0 Y0 Z0\n"
//		"G1 F1250 X70 Y0 Z0\n"
//		"G1 F1250 X0 Y0 Z0\n"
//		"G1 F1250 X70 Y0 Z0\n"
//		"G1 F1250 X0 Y0 Z0\n"
//		"G1 F1250 X70 Y0 Z0\n"
//		"G1 F1250 X0 Y0 Z0\n"
//		"G1 F1250 X70 Y0 Z0\n"
//		"G1 F1250 X0 Y0 Z0\n"
//		"G1 F1250 X70 Y0 Z0\n"
//		"G1 F1250 X0 Y0 Z0\n"
//		"G1 F1250 X70 Y0 Z0\n"

//		"G1 F3000 X0 Y0 Z0\n"
//		"G1 F3000 X70 Y0 Z0\n"
//		"G1 F3000 X0 Y0 Z0\n"
//		"G1 F3000 X70 Y0 Z0\n"
//		"G1 F3000 X0 Y0 Z0\n"
//		"G1 F3000 X70 Y0 Z0\n"
//		"G1 F3000 X0 Y0 Z0\n"
//		"G1 F3000 X70 Y0 Z0\n"
//		"G1 F3000 X0 Y0 Z0\n"
//		"G1 F3000 X70 Y0 Z0\n"
//
//		"G1 F3000 X0 Y0 Z0\n"
//		"G1 F3000 X70 Y70 Z0\n"
//		"G1 F3000 X0 Y0 Z0\n"
//		"G1 F3000 X70 Y70 Z0\n"
//		"G1 F3000 X0 Y0 Z0\n"
//		"G1 F3000 X70 Y70 Z0\n"
//		"G1 F3000 X0 Y0 Z0\n"
//		"G1 F3000 X70 Y70 Z0\n"
//		"G1 F3000 X0 Y0 Z0\n"
//		"G1 F3000 X70 Y70 Z0\n"
//		"G1 F3000 X0 Y0 Z0\n"
//		"G1 F3000 X70 Y70 Z0\n"


//		"G1 F800 X0 Y0 Z0 E50\n"
//		"G1 F500 X0 Y0 Z0 E0\n"
//		"G1 F500 X0 Y0 Z0 E10\n"
//		"G1 F500 X0 Y0 Z0 E0\n"
//		"G1 F500 X0 Y0 Z0 E10\n"
//		"G1 F500 X0 Y0 Z0 E0\n"
//		"G1 F500 X0 Y0 Z0 E10\n"
//		"G1 F500 X0 Y0 Z0 E0\n"
};


void gLineSendTest()
{

	printLine("STARTSYSTEM");
	char *dataPntr=testGlineData;

	pars(dataPntr);

	while(1)
	{
		while(*dataPntr!='\n')dataPntr++;
		dataPntr++;
		while(parser.bufferStatus==BUFFER_FULL)
		{
			tempControl();
		}

		if((dataPntr-testGlineData)>=(sizeof(testGlineData)-1))
		{
			return;
		}
		pars(dataPntr);



	}


}



void movementTestHandler(uint8_t coordinate, uint8_t dir)
{
	static uint8_t cntrx=0;
	static uint8_t cntry=0;
	static uint8_t cntrz=0;
	char sendData=0;

	switch (coordinate)
	{
	case COORDINATE_X:
		if(((++cntrx)%2)!=0)return;
		if(dir)movementTest.stepX++;
		else
			movementTest.stepX--;

		movementTest.dirX=dir;
		sendData=(dir<<2);
		putChar(sendData);
		break;
	case COORDINATE_Y:
		if(((++cntry)%2)!=0)return;
		if(dir)movementTest.stepY++;
		else
			movementTest.stepY--;

		movementTest.dirY=dir;
		sendData=((dir<<2)|0x01);
		putChar(sendData);
		break;
	case COORDINATE_Z:
		if(((++cntrz)%2)!=0)return;
		if(dir)movementTest.stepZ++;
		else
			movementTest.stepZ--;

		movementTest.dirZ=dir;
		sendData=((dir<<2)|0x02);
		putChar(sendData);
		break;
	}
	//	printLine("START");
	//
	//	movementTest.sendBuffer[0]=movementTest.stepX;
	//	movementTest.sendBuffer[1]=movementTest.stepX>>8;
	//	movementTest.sendBuffer[2]=movementTest.stepX>>16;
	//	movementTest.sendBuffer[3]=movementTest.stepX>>24;
	//	movementTest.sendBuffer[4]=movementTest.stepY;
	//	movementTest.sendBuffer[5]=movementTest.stepY>>8;
	//	movementTest.sendBuffer[6]=movementTest.stepY>>16;
	//	movementTest.sendBuffer[7]=movementTest.stepY>>24;
	//	movementTest.sendBuffer[8]=movementTest.stepZ;
	//	movementTest.sendBuffer[9]=movementTest.stepZ>>8;
	//	movementTest.sendBuffer[10]=movementTest.stepZ>>16;
	//	movementTest.sendBuffer[11]=movementTest.stepZ>>24;
	//	movementTest.sendBuffer[12]=movementTest.dirX;
	//	movementTest.sendBuffer[13]=movementTest.dirY;
	//	movementTest.sendBuffer[14]=movementTest.dirZ;
	//
	//	serialPrint((char*)&movementTest.sendBuffer,15);
	//	printLine("END");
}







void movementSerialTest()
{
	printLine("STARTSYSTEM");
	while(1)
	{
		HAL_Delay(50);
		movementTestHandler(COORDINATE_X, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Y, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Z, 1);
	}
}


void limitSwitchTest()
{
	uint8_t limitSwitchX=LIMIT_SWITCH_NOT_PRESSED;
	uint8_t limitSwitchY=LIMIT_SWITCH_NOT_PRESSED;
	uint8_t limitSwitchZ=LIMIT_SWITCH_NOT_PRESSED;
	while(1)
	{
		limitSwitchX=readLimitSwitchX();
		limitSwitchY=readLimitSwitchY();
		limitSwitchZ=readLimitSwitchZ();
		HAL_Delay(100);
	}
}


void moveXYZbackwardTest()
{
	startStep(1,1,1,1, 100,100,100,100);
	while(1)
	{
		toggleX(0);
		toggleY(0);
		toggleZ(0);
		HAL_Delay(10);
	}
}


void moveExtruderTest()
{
	uint32_t cntrx=0;
	while(cntrx<10000)
	{
		toggleE(0);
		HAL_Delay(2);
		cntrx++;
	}
}

void readExtruderTempTest()
{
	volatile uint16_t temp;
//	extruderHeaterOn();
//	HAL_Delay(20000);
//	extruderHeaterOff();
	while(1)
	{
		startADCconversions();
		HAL_Delay(50);
		temp=readExtruderTemp();
		HAL_Delay(200);

	}

}


void readHeatBedTempTest()
{
	volatile uint16_t temp;
	heatBedHeaterOn();
	HAL_Delay(30000);
	heatBedHeaterOff();
	while(1)
	{
		startADCconversions();
		HAL_Delay(50);
		temp=readBedTemp();
		HAL_Delay(200);

	}

}


