/*
 * test.c
 *
 *  Created on: 22 �ub 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct movementTest_ movementTest;



char testGlineData[]={

		"G28 X0 Y0\n"
		"G28 Z0\n"
		"G1 Z20\n"
		"G1 F1000 X0 Y100 E150 Z10\n"
		"G1 F1000 X100 Y0\n"
		"G1 F1000 X100 Y100\n"
		"G1 F1000 X190 Y0\n"
				"G1 F1000 X0 Y0\n"
				"G1 F1000 X2 Y1.33\n"
				"G1 X3 Y6\n"
				"G1 X4 Y8\n"
				"G1 X5 Y10\n"
				"G1 X6 Y12\n"
				"G1 X7 Y14\n"
				"G1 X8 Y16\n"
				"G1 X9 Y18\n"
				"G1 X10 Y20\n"
				"G1 X11 Y22\n"
				"G1 X12 Y24\n"
				"G1 X13 Y26\n"
				"G1 X14 Y28\n"
				"G1 X15 Y30\n"
				"G1 X16 Y32\n"
				"G1 X17 Y34\n"
				"G1 X18 Y36\n"
				"G1 X19 Y38\n"
				"G1 X20 Y40\n"
				"G1 X21 Y42\n"
				"G1 X22 Y44\n"
				"G1 X23 Y46\n"
				"G1 X24 Y48\n"
				"G1 X25 Y50\n"
				"G1 X26 Y52\n"
				"G1 X27 Y54\n"
				"G1 X28 Y56\n"
				"G1 X29 Y58\n"
				"G1 X30 Y60\n"
				"G1 X31 Y62\n"
				"G1 X32 Y64\n"
				"G1 X33 Y66\n"
				"G1 X34 Y68\n"
				"G1 X35 Y70\n"
				"G1 X36 Y72\n"
				"G1 X37 Y74\n"
				"G1 X38 Y76\n"
				"G1 X39 Y78\n"
				"G1 X40 Y80\n"
				"G1 X41 Y82\n"
				"G1 X42 Y84\n"
				"G1 X43 Y86\n"
				"G1 X44 Y88\n"
				"G1 X45 Y90\n"
				"G1 X46 Y92\n"


		//		"G1 F1000 X1 Y1\n"
		//		"G1 X2 Y2\n"
		//		"G1 X3 Y3\n"
		//		"G1 X4 Y4\n"
		//		"G1 X5 Y5\n"
		//		"G1 X6 Y6\n"
		//		"G1 X7 Y7\n"
		//		"G1 X8 Y8\n"
		//		"G1 X9 Y9\n"
		//		"G1 X10 Y10\n"
		//		"G1 X11 Y11\n"
		//		"G1 X12 Y12\n"
		//		"G1 X13 Y13\n"
		//		"G1 X14 Y14\n"
		//		"G1 X15 Y15\n"
		//		"G1 X16 Y16\n"
		//		"G1 F2000 X17 Y17\n"
		//		"G1 X18 Y18\n"
		//		"G1 X19 Y19\n"
		//		"G1 X20 Y20\n"
		//		"G1 X21 Y21\n"
		//		"G1 X22 Y22\n"
		//		"G1 X23 Y23\n"
		//		"G1 X24 Y24\n"
		//		"G1 X25 Y25\n"
		//		"G1 X26 Y26\n"
		//		"G1 X27 Y27\n"
		//		"G1 X28 Y28\n"
		//		"G1 X29 Y29\n"
		//		"G1 X30 Y30\n"
		//		"G1 X31 Y31\n"
		//		"G1 X32 Y32\n"
		//		"G1 X33 Y33\n"
		//		"G1 X34 Y34\n"
		//		"G1 X35 Y35\n"
		//		"G1 X36 Y36\n"
		//		"G1 X38 Y38\n"
		//		"G1 X39 Y39\n"
		//		"G1 X40 Y40\n"
		//		"G1 X41 Y41\n"
		//		"G1 X42 Y42\n"
		//		"G1 X43 Y43\n"
		//		"G1 X44 Y44\n"
		//		"G1 X45 Y45\n"
		//		"G1 X46 Y46\n"
		//		"G1 X47 Y47\n"
		//		"G1 X48 Y48\n"
		//		"G1 X49 Y49\n"
		//		"G1 X50 Y50\n"
		//		"G1 X51 Y51\n"
		//		"G1 X52 Y52\n"
		//		"G1 X53 Y53\n"
		//		"G1 X54 Y54\n"
		//		"G1 X55 Y55\n"
		//		"G1 X56 Y56\n"
		//		"G1 X57 Y57\n"
		//		"G1 X58 Y58\n"
		//		"G1 X59 Y59\n"
		//		"G1 X60 Y60\n"
		//		"G1 X61 Y61\n"
		//		"G1 X62 Y62\n"
		//		"G1 X63 Y63\n"
		//		"G1 X64 Y64\n"
		//		"G1 X65 Y65\n"
		//		"G1 X66 Y66\n"
		//		"G1 X67 Y67\n"
		//		"G1 X68 Y68\n"
		//		"G1 X69 Y69\n"
		//		"G1 X70 Y70\n"
		//		"G1 X71 Y71\n"
		//		"G1 X72 Y72\n"
		//		"G1 X73 Y73\n"
		//		"G1 X74 Y74\n"
		//		"G1 X75 Y75\n"
		//		"G1 X76 Y76\n"
		//		"G1 X77 Y77\n"
		//		"G1 X78 Y78\n"
		//		"G1 X79 Y79\n"


//
//		"G1 F6000 X100 Y100 Z1 E20\n"
//		"G1 X90 Y90\n"
//		"G1 X80 Y10\n"
//		"G1 X3 Y3\n"
//		"G1 X4 Y4\n"
//		"G1 X5 Y5\n"
//		"G1 X6 Y6\n"
//		"G1 X7 Y7\n"
//		"G1 X8 Y8\n"
//		"G1 X9 Y9\n"
//		"G1 X10 Y10\n"
//		"G1 X11 Y11\n"
//		"G1 X12 Y12\n"
//		"G1 X13 Y13\n"
//		"G1 X14 Y14\n"
//		"G1 X15 Y15\n"
//		"G1 X16 Y16\n"
//		"G1 X0 Y0\n"
//		"G1 X18 Y18\n"
//		"G1 X19 Y19\n"
//		"G1 X20 Y20\n"
//		"G1 X21 Y21\n"
//		"G1 X22 Y22\n"
//		"G1 X23 Y23\n"
//		"G1 X24 Y24\n"
//		"G1 X25 Y25\n"
//		"G1 X26 Y26\n"
//		"G1 X27 Y27\n"
//		"G1 X28 Y28\n"
//		"G1 X29 Y29\n"
//		"G1 X30 Y30\n"
//		"G1 X31 Y31\n"
//		"G1 X32 Y32\n"
//		"G1 X33 Y33\n"
//		"G1 X34 Y34\n"
//		"G1 X35 Y35\n"
//		"G1 X36 Y36\n"
//		"G1 X38 Y38\n"
//		"G1 X39 Y39\n"
//		"G1 X40 Y40\n"
//		"G1 X41 Y41\n"
//		"G1 X42 Y42\n"
//		"G1 X43 Y43\n"
//		"G1 X44 Y44\n"
//		"G1 X45 Y45\n"
//		"G1 X46 Y46\n"
//		"G1 X47 Y47\n"
//		"G1 X48 Y48\n"
//		"G1 X49 Y49\n"
//		"G1 X50 Y50\n"
//		"G1 X51 Y51\n"
//		"G1 X52 Y52\n"
//		"G1 X53 Y53\n"
//		"G1 X54 Y54\n"
//		"G1 X55 Y55\n"
//		"G1 X56 Y56\n"
//		"G1 X57 Y57\n"
//		"G1 X58 Y58\n"
//		"G1 X59 Y59\n"
//		"G1 X60 Y60\n"
//		"G1 X61 Y61\n"
//		"G1 X62 Y62\n"
//		"G1 X63 Y63\n"
//		"G1 X64 Y64\n"
//		"G1 X65 Y65\n"
//		"G1 X66 Y66\n"
//		"G1 X67 Y67\n"
//		"G1 X68 Y68\n"
//		"G1 X69 Y69\n"
//		"G1 X70 Y70\n"
//		"G1 X71 Y71\n"
//		"G1 X72 Y72\n"
//		"G1 X73 Y73\n"
//		"G1 X74 Y74\n"
//		"G1 X75 Y75\n"
//		"G1 X76 Y76\n"
//		"G1 X77 Y77\n"
//		"G1 X78 Y78\n"
//		"G1 X79 Y79\n"


//		";FLAVOR:Marlin\n"
//		";TIME:667\n"
//		";Filament used: 1.38786m\n"
//		";Layer height: 0.3\n"
//		";Generated with Cura_SteamEngine 3.2.1\n"
//		"M106\n"
//		"M190 S50\n"
//		"M104 S205\n"
//		"M109 S205\n"
//		"M82 ;absolute extrusion mode\n"
//		"G21 ;metric values\n"
//		"G90 ;absolute positioning\n"
//		"M82 ;set extruder to absolute mode\n"
//		"G28 X0 Y0 ;move X/Y to min endstops\n"
//		"G28 Z0 ;move Z to min endstops\n"
//		"G1 Z15.0 F9000 ;move the platform down 15mm\n"
//		"G92 E0 ;zero the extruded length\n"
//		"G1 F200 E3 ;extrude 3mm of feed stock\n"
//		"G92 E0 ;zero the extruded length again\n"
//		"G1 F9000\n"
//		";Put printing message on LCD screen\n"
//		"M117 Printing...\n"
//		";LAYER_COUNT:67\n"
//		";LAYER:0\n"
//		"G0 F1800 X90.901 Y91.148 Z0.3\n"
//		";TYPE:SKIRT\n"
//		"G1 X91.147 Y90.902 E0.02603\n"
//		"G1 X92.13 Y90.038 E0.12397\n"
//		"G1 X92.414 Y89.82 E0.15077\n"
//		"G1 X93.501 Y89.095 E0.24855\n"
//		"G1 X93.804 Y88.92 E0.27473\n"
//		"G1 X94.977 Y88.341 E0.37263\n"
//		"G1 X95.387 Y88.179 E0.40562\n"
//		"G1 X97.263 Y87.609 E0.55234\n"
//		"G1 X97.696 Y87.515 E0.5855\n"
//		"G1 X98.995 Y87.344 E0.68355\n"
//		"G1 X99.347 Y87.321 E0.70995\n"
//		"G1 X100.653 Y87.321 E0.80769\n"
//		"G1 X101.094 Y87.357 E0.8408\n"
//		"G1 X103.028 Y87.677 E0.9875\n"
//		"G1 X103.454 Y87.784 E1.02037\n"
//		"G1 X104.695 Y88.205 E1.11844\n"
//		"G1 X105.023 Y88.341 E1.14501\n"
//		"G1 X106.194 Y88.919 E1.24273\n"
//		"G1 X106.496 Y89.093 E1.26882\n"
//		"G1 X107.584 Y89.818 E1.36666\n"
//		"G1 X107.869 Y90.037 E1.39356\n"
//		"G1 X108.852 Y90.901 E1.4915\n"
//		"G1 X109.098 Y91.147 E1.51753\n"
//		"G1 X109.962 Y92.13 E1.61547\n"
//		"G1 X110.18 Y92.414 E1.64226\n"
//		"G1 X110.905 Y93.501 E1.74004\n"
//		"G1 X111.08 Y93.804 E1.76623\n"
//		"G1 X111.659 Y94.977 E1.86412\n"
//		"G1 X111.821 Y95.387 E1.89711\n"
//		"G1 X112.391 Y97.263 E2.04384\n"
//		"G1 X112.485 Y97.695 E2.07693\n"
//		"G1 X112.656 Y98.993 E2.1749\n"
//		"G1 X112.679 Y99.346 E2.20137\n"
//		"G1 X112.679 Y100.653 E2.29918\n"
//		"G1 X112.643 Y101.094 E2.3323\n"
//		"G1 X112.323 Y103.028 E2.479\n"
//		"G1 X111.795 Y104.695 E2.60994\n"
//		"G1 X111.659 Y105.023 E2.63651\n"
//		"G1 X111.081 Y106.194 E2.73423\n"
//		"G1 X110.907 Y106.496 E2.76032\n"
//		"G1 X110.182 Y107.584 E2.85816\n"
//		"G1 X109.963 Y107.869 E2.88506\n"
//		"G1 X109.099 Y108.852 E2.983\n"
//		"G1 X108.785 Y109.156 E3.0157\n"
//		"G1 X107.27 Y110.401 E3.16245\n"
//		"G1 X106.906 Y110.653 E3.19558\n"
//		"G1 X105.773 Y111.307 E3.29348\n"
//		"G1 X105.454 Y111.464 E3.32009\n"
//		"G1 X104.244 Y111.964 E3.41806\n"
//		"G1 X103.826 Y112.098 E3.45091\n"
//		"G1 X101.918 Y112.543 E3.59753\n"
//		"G1 X101.483 Y112.608 E3.63045\n"
//		"G1 X100.178 Y112.694 E3.72832\n"


};


void gLineSendTest()
{

	printLine("STARTSYSTEM");
	char *dataPntr=testGlineData;

	pars(dataPntr);
	accelerationCorrect();
	while(1)
	{
		while(*dataPntr!='\n')dataPntr++;
		dataPntr++;
		while(parser.bufferStatus==BUFFER_FULL)
		{
			tempControl();
		}

		if((dataPntr-testGlineData)>=(sizeof(testGlineData)-1))
		{
			return;
		}
		pars(dataPntr);
		taskPrepare();
		accelerationCorrect();
	}
}



void movementTestHandler(uint8_t coordinate, uint8_t dir)
{
	static uint8_t cntrx=0;
	static uint8_t cntry=0;
	static uint8_t cntrz=0;
	char sendData=0;

	switch (coordinate)
	{
	case COORDINATE_X:
		if(((++cntrx)%2)!=0)return;
		if(dir)movementTest.stepX++;
		else
			movementTest.stepX--;

		movementTest.dirX=dir;
		sendData=(dir<<2);
		putChar(sendData);
		break;
	case COORDINATE_Y:
		if(((++cntry)%2)!=0)return;
		if(dir)movementTest.stepY++;
		else
			movementTest.stepY--;

		movementTest.dirY=dir;
		sendData=((dir<<2)|0x01);
		putChar(sendData);
		break;
	case COORDINATE_Z:
		if(((++cntrz)%2)!=0)return;
		if(dir)movementTest.stepZ++;
		else
			movementTest.stepZ--;

		movementTest.dirZ=dir;
		sendData=((dir<<2)|0x02);
		putChar(sendData);
		break;
	}
	//	printLine("START");
	//
	//	movementTest.sendBuffer[0]=movementTest.stepX;
	//	movementTest.sendBuffer[1]=movementTest.stepX>>8;
	//	movementTest.sendBuffer[2]=movementTest.stepX>>16;
	//	movementTest.sendBuffer[3]=movementTest.stepX>>24;
	//	movementTest.sendBuffer[4]=movementTest.stepY;
	//	movementTest.sendBuffer[5]=movementTest.stepY>>8;
	//	movementTest.sendBuffer[6]=movementTest.stepY>>16;
	//	movementTest.sendBuffer[7]=movementTest.stepY>>24;
	//	movementTest.sendBuffer[8]=movementTest.stepZ;
	//	movementTest.sendBuffer[9]=movementTest.stepZ>>8;
	//	movementTest.sendBuffer[10]=movementTest.stepZ>>16;
	//	movementTest.sendBuffer[11]=movementTest.stepZ>>24;
	//	movementTest.sendBuffer[12]=movementTest.dirX;
	//	movementTest.sendBuffer[13]=movementTest.dirY;
	//	movementTest.sendBuffer[14]=movementTest.dirZ;
	//
	//	serialPrint((char*)&movementTest.sendBuffer,15);
	//	printLine("END");
}







void movementSerialTest()
{
	printLine("STARTSYSTEM");
	while(1)
	{
		HAL_Delay(50);
		movementTestHandler(COORDINATE_X, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Y, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Z, 1);
	}
}


void limitSwitchTest()
{
	uint8_t limitSwitchX=LIMIT_SWITCH_NOT_PRESSED;
	uint8_t limitSwitchY=LIMIT_SWITCH_NOT_PRESSED;
	uint8_t limitSwitchZ=LIMIT_SWITCH_NOT_PRESSED;
	while(1)
	{
		limitSwitchX=readLimitSwitchX();
		limitSwitchY=readLimitSwitchY();
		limitSwitchZ=readLimitSwitchZ();
		HAL_Delay(100);
	}
}


void moveXtest()
{
	uint32_t moveCntr=0;
	setDirX(1);
	HAL_GPIO_WritePin(PORT_X1,PIN_X1,GPIO_PIN_SET);
	while(moveCntr++<20000)
	{
		HAL_Delay(2);
		HAL_GPIO_TogglePin(PORT_X1,PIN_X1);
	}
}
void moveXYZbackwardTest()
{
	startStep(1,1,1,1, 100,100,100,100);
	while(1)
	{
		toggleX(0);
		toggleY(0);
		toggleZ(0);
		HAL_Delay(10);
	}
}


void moveExtruderTest()
{
	uint32_t cntrx=0;
	while(cntrx<10000)
	{
		toggleE(1);
		HAL_Delay(2);
		cntrx++;
	}
}

void readExtruderTempTest()
{
	volatile uint16_t temp;
	//	extruderHeaterOn();
	//	HAL_Delay(20000);
	//	extruderHeaterOff();
	while(1)
	{
		startADCconversions();
		HAL_Delay(50);
		temp=readExtruderTemp();
		HAL_Delay(200);

	}

}


void readHeatBedTempTest()
{
	volatile uint16_t temp;
	heatBedHeaterOn();
	HAL_Delay(30000);
	heatBedHeaterOff();
	while(1)
	{
		startADCconversions();
		HAL_Delay(50);
		temp=readBedTemp();
		HAL_Delay(200);

	}

}


