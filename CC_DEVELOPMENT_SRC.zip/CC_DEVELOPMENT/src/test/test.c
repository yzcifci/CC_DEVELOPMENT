/*
 * test.c
 *
 *  Created on: 22 Þub 2018
 *      Author: yzcifci
 */

#include "main.h"

struct movementTest_ movementTest;



char testGlineData[]={
		"M204 S1000\n"
		"G28 X0 Y0\n"
		"G1 F2400 E340\n"
		"G1 F2400 X94.635 Y96.802 E340.30404\n"
		"G1 X94.103 Y98.999 E340.36043\n"
		"G1 X94.036 Y99.484 E340.37264\n"
		"G1 X94.002 Y100.19 E340.39028\n"
		"G1 X94.009 Y100.481 E340.39754\n"
		"G1 X94.056 Y100.831 E340.40635\n"
		"G1 X94.082 Y101.09 E340.41284\n"
		"G1 X94.167 Y101.512 E340.42358\n"
		"G1 X94.335 Y102.08 E340.43835\n"
		"G1 X94.5 Y102.498 E340.44956\n"
		"G1 X94.751 Y103.009 E340.46376\n"
		"G1 X94.962 Y103.35 E340.47377\n"
		"G1 X95.317 Y103.86 E340.48927\n"
		"G1 X95.653 Y104.242 E340.50196\n"
		"G1 X96.012 Y104.589 E340.51441\n"
		"G1 X96.012 Y101.412 E340.59366\n"
		"G1 X96.061 Y101.559 E340.59753\n"
		"G1 X96.248 Y101.998 E340.60943\n"
		"G1 X96.401 Y102.281 E340.61746\n"
		"G1 X96.665 Y102.672 E340.62923\n"
		"G1 X97.016 Y103.066 E340.64239\n"
		"G1 X97.333 Y103.341 E340.65286\n"
		"G1 X97.694 Y103.611 E340.6641\n"
		"G1 X98.108 Y103.857 E340.67612\n"
		"G1 X98.472 Y104.017 E340.68603\n"
		"G1 X98.679 Y104.082 E340.69145\n"
		"G1 X98.679 Y105.952 E340.73809\n"
		"G1 X98.724 Y105.965 E340.73926\n"
		"G1 X99.22 Y106.051 E340.75182\n"
		"G1 X99.698 Y106.096 E340.7638\n"
		"G1 X100.145 Y106.098 E340.77495\n"
		"G1 X100.817 Y106.046 E340.79176\n"
		"G1 X101.165 Y105.987 E340.80056\n"
		"G1 X101.346 Y105.94 E340.80523\n"
		"G1 X101.346 Y104.077 E340.8517\n"
		"G1 X101.382 Y104.067 E340.85263\n"
		"G1 X101.849 Y103.871 E340.86527\n"
		"G1 X102.312 Y103.599 E340.87866\n"
		"G1 X102.495 Y103.48 E340.88411\n"
		"G1 X102.876 Y103.173 E340.89631\n"
		"G1 X103.214 Y102.812 E340.90865\n"
		"G1 X103.489 Y102.446 E340.92007\n"
		"G1 X103.709 Y102.075 E340.93083\n"
		"G1 X103.886 Y101.69 E340.9414\n"
		"G1 X104.013 Y101.337 E340.95076\n"
		"G1 X104.013 Y104.563 E341.03123\n"
		"G1 X104.328 Y104.26 E341.04213\n"
		"G1 X104.644 Y103.903 E341.05403\n"
		"G1 X104.991 Y103.427 E341.06872\n"
		"G1 X105.25 Y103.006 E341.08105\n"
		"G1 X105.457 Y102.593 E341.09257\n"
		"G1 X105.661 Y102.093 E341.10605\n"
		"G1 X105.798 Y101.654 E341.11752\n"
		"G1 X105.919 Y101.08 E341.13215\n"
		"G1 X105.984 Y100.504 E341.14661\n"
		"G1 X106.001 Y100.097 E341.15677\n"
		"G1 X105.969 Y99.513 E341.17136\n"
		"G1 X105.884 Y98.923 E341.18623\n"
		"G1 X105.375 Y96.802 E341.24064\n"
		"G1 X104.013 Y96.802 E341.27462\n"
		"G1 X104.013 Y98.87 E341.3262\n"
		"G1 X103.971 Y98.713 E341.33026\n"
		"G1 X103.767 Y98.259 E341.34267\n"
		"G1 X103.529 Y97.825 E341.35502\n"
		"G1 X103.316 Y97.527 E341.36416\n"
		"G1 X102.967 Y97.127 E341.3774\n"
		"G1 X102.599 Y96.802 E341.38965\n"
		"G1 X104.013 Y96.802 E341.42492\n"
		"G0 F3000 X104.013 Y98.87\n"
		"G1 F2400 X104.073 Y99.096 E341.43075\n"
		"G1 X104.175 Y99.634 E341.44441\n"
		"G1 X104.2 Y99.997 E341.45349\n"
		"G1 X104.182 Y100.466 E341.4652\n"
		"G1 X104.121 Y100.917 E341.47655\n"
		"G1 X104.024 Y101.307 E341.48657\n"
		"G1 X104.013 Y101.337 E341.48737\n"
		"G0 F3000 X96.012 Y101.412\n"
		"G1 F2400 X95.958 Y101.25 E341.49163\n"
		"G1 X95.863 Y100.841 E341.5021\n"
		"G1 X95.808 Y100.298 E341.51572\n"
		"G1 X95.804 Y99.909 E341.52542\n"
		"G1 X95.828 Y99.538 E341.5347\n"
		"G1 X95.922 Y99.109 E341.54565\n"
		"G1 X96.012 Y98.807 E341.55351\n"
		"G1 X96.012 Y96.802 E341.60353\n"
		"G1 X97.411 Y96.802 E341.63843\n"
		"G1 X97.211 Y96.963 E341.64483\n"
		"G1 X96.917 Y97.248 E341.65505\n"
		"G1 X96.669 Y97.542 E341.66464\n"
		"G1 X96.46 Y97.841 E341.67374\n"
		"G1 X96.22 Y98.265 E341.68589\n"
		"G1 X96.06 Y98.645 E341.69618\n"
		"G1 X96.012 Y98.807 E341.70039\n"
		"G0 F3000 X105.201 Y96.99\n"
		"G0 X109.347 Y96.109\n"
		"G1 F2400 X110.777 Y96.109 E341.73607\n"
		"G1 X111.119 Y95.902 E341.74604\n"
		"G1 X112.014 Y95.902 E341.76836\n"
		"G1 X112.014 Y93.902 E341.81825\n"
		"G1 X112.384 Y93.902 E341.82748\n"
		"G1 X112.5 Y94.018 E341.83158\n"
		"G1 X112.5 Y95.786 E341.87568\n"
		"G1 X112.384 Y95.902 E341.87977\n"
		"G1 X112.014 Y95.902 E341.889\n"
		"G0 F3000 X109.347 Y96.109\n"
		"G1 F2400 X108.1 Y96.109 E341.92011\n"
		"G1 X108.1 Y93.695 E341.98032\n"
		"G1 X109.347 Y93.695 E342.01143\n"
		"G1 X109.347 Y96.109 E342.07165\n"
		";MESH:y_axis_bearing_upper.stl\n"
		"G0 F3000 X107.865 Y95.288\n"
		"G0 X106.586 Y95.288\n"
		"G0 X106.53 Y95.232\n"
		"G0 X106.6 Y95.302\n"
		";TYPE:WALL-INNER\n"
		"G1 F2400 X93.4 Y95.302 E342.40092\n"
		"G1 X93.4 Y94.502 E342.42088\n"
		"G1 X106.6 Y94.502 E342.75016\n"
		"G1 X106.6 Y95.302 E342.77011\n"
		"G0 F3000 X107 Y95.702\n"
		";TYPE:WALL-OUTER\n"
		"G1 F1200 X93 Y95.702 E343.11934\n"
		"G1 X93 Y94.102 E343.15925\n"
		"G1 X107 Y94.102 E343.50849\n"
		"G1 X107 Y95.702 E343.5484\n"
		"G0 F3000 X106.8 Y95.702\n"
		"G0 X106.21 Y94.912\n"
		";TYPE:SKIN\n"
		"G1 F1200 X93.79 Y94.912 E343.85822\n"
		"G1 X93.79 Y94.892 E343.85872\n"
		"G1 X106.21 Y94.892 E344.16853\n"
		"G1 X106.21 Y94.912 E344.16903\n"
		"G0 F3000 X106.2 Y94.902\n"
		";MESH:NONMESH\n"
		"G0 X93.414 Y95.288\n"
		"G0 X92.135 Y95.288\n"
		"G0 X88.011 Y95.902\n"
		";TIME_ELAPSED:662.413057\n"
		";LAYER:51\n"
		"G0 X88.011 Y95.902 Z7.95\n"
		";TYPE:SUPPORT\n"
		"G1 F2400 X89.048 Y95.902 E344.1949\n"
		"G1 X89.39 Y96.109 E344.20487\n"
		"G1 X90.678 Y96.109 E344.237\n"
		"G1 X90.678 Y93.695 E344.29722\n"
		"G1 X91.9 Y93.695 E344.3277\n"
		"G1 X91.9 Y96.109 E344.38792\n"
		"G1 X90.678 Y96.109 E344.4184\n"
		"G0 F3000 X88.011 Y95.902\n"
		"G1 F2400 X87.616 Y95.902 E344.42826\n"
		"G1 X87.5 Y95.786 E344.43235\n"
		"G1 X87.5 Y94.018 E344.47645\n"
		"G1 X87.616 Y93.902 E344.48054\n"
		"G1 X88.011 Y93.902 E344.4904\n"
		"G1 X88.011 Y95.902 E344.54029\n"
		"G0 F3000 X92.179 Y96.496\n"
		"G0 X96.012 Y96.802\n"
		"G1 F2400 X94.633 Y96.802 E344.57469\n"
		"G1 X94.102 Y99.003 E344.63117\n"
		"G1 X94.035 Y99.485 E344.6433\n"
		"G1 X94.002 Y100.178 E344.66061\n"
		"G1 X94.01 Y100.487 E344.66832\n"
		"G1 X94.055 Y100.822 E344.67675\n"
		"G1 X94.082 Y101.089 E344.68345\n"
		"G1 X94.169 Y101.52 E344.69442\n"
		"G1 X94.337 Y102.088 E344.70919\n"
		"G1 X94.494 Y102.484 E344.71982\n"
		"G1 X94.753 Y103.012 E344.73449\n"
		"G1 X94.964 Y103.351 E344.74445\n"
		"G1 X95.314 Y103.857 E344.7598\n"
		"G1 X95.656 Y104.245 E344.7727\n"
		"G1 X96.012 Y104.59 E344.78506\n"
		"G1 X96.012 Y101.414 E344.86429\n"
		"G1 X96.059 Y101.554 E344.86797\n"
		"G1 X96.25 Y102.001 E344.8801\n"
		"G1 X96.401 Y102.28 E344.88801\n"
		"G1 X96.67 Y102.678 E344.9\n"
		"G1 X97.015 Y103.064 E344.91291\n"
		"G1 X97.339 Y103.346 E344.92363\n"
		"G1 X97.694 Y103.613 E344.93471\n"
		"G1 X98.109 Y103.857 E344.94672\n"
		"G1 X98.464 Y104.014 E344.9564\n"
		"G1 X98.679 Y104.082 E344.96202\n"
		"G1 X98.679 Y105.952 E345.00867\n"
		"G1 X98.717 Y105.963 E345.00966\n"
		"G1 X99.221 Y106.051 E345.02242\n"
		"G1 X99.7 Y106.096 E345.03442\n"
		"G1 X100.145 Y106.098 E345.04552\n"
		"G1 X100.819 Y106.046 E345.06238\n"
		"G1 X101.16 Y105.988 E345.07101\n"
		"G1 X101.346 Y105.94 E345.07581\n"
		"G1 X101.346 Y104.078 E345.12225\n"
		"G1 X101.379 Y104.068 E345.12311\n"
		"G1 X101.852 Y103.869 E345.13591\n"
		"G1 X102.312 Y103.6 E345.14921\n"
		"G1 X102.504 Y103.471 E345.15498\n"
		"G1 X102.875 Y103.173 E345.16685\n"
		"G1 X103.211 Y102.815 E345.17909\n"
		"G1 X103.486 Y102.451 E345.19047\n"
		"G1 X103.708 Y102.078 E345.2013\n"
		"G1 X103.889 Y101.684 E345.21212\n"
		"G1 X104.013 Y101.337 E345.22131\n"
		"G1 X104.013 Y104.564 E345.30181\n"
		"G1 X104.328 Y104.261 E345.31271\n"
		"G1 X104.649 Y103.897 E345.32482\n"
		"G1 X104.986 Y103.436 E345.33906\n"
		"G1 X105.249 Y103.008 E345.35159\n"
		"G1 X105.456 Y102.596 E345.36309\n"
		"G1 X105.662 Y102.09 E345.37672\n"
		"G1 X105.796 Y101.662 E345.38791\n"
		"G1 X105.918 Y101.081 E345.40272\n"
		"G1 X105.984 Y100.499 E345.41733\n"
		"G1 X106.001 Y100.095 E345.42742\n"
		"G1 X105.969 Y99.509 E345.44206\n"
		"G1 X105.885 Y98.925 E345.45678\n"
		"G1 X105.37 Y96.802 E345.51127\n"
		"G1 X104.013 Y96.802 E345.54512\n"
		"G1 X104.013 Y98.871 E345.59673\n"
		"G1 X103.97 Y98.71 E345.60089\n"
		"G1 X103.762 Y98.249 E345.6135\n"
		"G1 X103.532 Y97.829 E345.62545\n"
		"G1 X103.31 Y97.52 E345.63494\n"
		"G1 X102.966 Y97.125 E345.64801\n"
		"G1 X102.601 Y96.802 E345.66016\n"
		"G1 X104.013 Y96.802 E345.69539\n"
		"G0 F3000 X104.013 Y98.871\n"
		"G1 F2400 X104.075 Y99.104 E345.7014\n"
		"G1 X104.175 Y99.633 E345.71483\n"
		"G1 X104.2 Y99.991 E345.72378\n"
		"G1 X104.181 Y100.476 E345.73589\n"
		"G1 X104.12 Y100.92 E345.74707\n"
		"G1 X104.025 Y101.304 E345.75694\n"
		"G1 X104.013 Y101.337 E345.75781\n"
		"G0 F3000 X96.012 Y101.414\n"
		"G1 F2400 X95.956 Y101.247 E345.76221\n"
		"G1 X95.864 Y100.839 E345.77264\n"
		"G1 X95.808 Y100.294 E345.78631\n"
		"G1 X95.804 Y99.903 E345.79606\n"
		"G1 X95.828 Y99.538 E345.80519\n"
		"G1 X95.921 Y99.11 E345.81611\n"
		"G1 X96.012 Y98.805 E345.82405\n"
		"G1 X96.012 Y96.802 E345.87402\n"
		"G1 X97.412 Y96.802 E345.90894\n"
		"G1 X97.209 Y96.966 E345.91545\n"

};


void gLineSendTest()
{

	printLine("STARTSYSTEM");
	char *dataPntr=testGlineData;

	pars(dataPntr);
	taskPrepare();
	accelerationCorrect();
	while(1)
	{
		while(*dataPntr!='\n')dataPntr++;
		dataPntr++;
		while(parser.bufferStatus==BUFFER_FULL)
		{
			tempControl();
		}

		if((dataPntr-testGlineData)>=(sizeof(testGlineData)-1))
		{
			if(acceControl.acceControlledNofData<MOVEMENT_TABLE_PARAMETER_SIZE)
			{
				parser.workableHead=acceControl.acceControlledNofData;
				parser.workableTailHeadDiff=acceControl.acceControlledNofData;
			}
			parser.workableHead=addSubtractIndex(parser.workableHead,PARSER_PARAMETER_SIZE,MOVEMENT_TABLE_PARAMETER_SIZE);
			parser.workableTailHeadDiff+=MOVEMENT_TABLE_PARAMETER_SIZE;

			return;
		}
		fatfsControl.lineCntr++;
		pars(dataPntr);
		taskPrepare();
		accelerationCorrect();
	}
}



void movementTestHandler(uint8_t coordinate, uint8_t dir)
{
	static uint8_t cntrx=0;
	static uint8_t cntry=0;
	static uint8_t cntrz=0;
	char sendData=0;

	switch (coordinate)
	{
	case COORDINATE_X:
		if(((++cntrx)%2)!=0)return;
		if(dir)movementTest.stepX++;
		else
			movementTest.stepX--;

		movementTest.dirX=dir;
		sendData=(dir<<2);
		putChar(sendData);
		break;
	case COORDINATE_Y:
		if(((++cntry)%2)!=0)return;
		if(dir)movementTest.stepY++;
		else
			movementTest.stepY--;

		movementTest.dirY=dir;
		sendData=((dir<<2)|0x01);
		putChar(sendData);
		break;
	case COORDINATE_Z:
		if(((++cntrz)%2)!=0)return;
		if(dir)movementTest.stepZ++;
		else
			movementTest.stepZ--;

		movementTest.dirZ=dir;
		sendData=((dir<<2)|0x02);
		putChar(sendData);
		break;
	}
	//	printLine("START");
	//
	//	movementTest.sendBuffer[0]=movementTest.stepX;
	//	movementTest.sendBuffer[1]=movementTest.stepX>>8;
	//	movementTest.sendBuffer[2]=movementTest.stepX>>16;
	//	movementTest.sendBuffer[3]=movementTest.stepX>>24;
	//	movementTest.sendBuffer[4]=movementTest.stepY;
	//	movementTest.sendBuffer[5]=movementTest.stepY>>8;
	//	movementTest.sendBuffer[6]=movementTest.stepY>>16;
	//	movementTest.sendBuffer[7]=movementTest.stepY>>24;
	//	movementTest.sendBuffer[8]=movementTest.stepZ;
	//	movementTest.sendBuffer[9]=movementTest.stepZ>>8;
	//	movementTest.sendBuffer[10]=movementTest.stepZ>>16;
	//	movementTest.sendBuffer[11]=movementTest.stepZ>>24;
	//	movementTest.sendBuffer[12]=movementTest.dirX;
	//	movementTest.sendBuffer[13]=movementTest.dirY;
	//	movementTest.sendBuffer[14]=movementTest.dirZ;
	//
	//	serialPrint((char*)&movementTest.sendBuffer,15);
	//	printLine("END");
}







void movementSerialTest()
{
	printLine("STARTSYSTEM");
	while(1)
	{
		HAL_Delay(50);
		movementTestHandler(COORDINATE_X, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Y, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Z, 1);
	}
}


void limitSwitchTest()
{
	/*
	uint8_t limitSwitchX=LIMIT_SWITCH_NOT_PRESSED;
	uint8_t limitSwitchY=LIMIT_SWITCH_NOT_PRESSED;
	uint8_t limitSwitchZ=LIMIT_SWITCH_NOT_PRESSED;
	while(1)
	{
		limitSwitchX=readLimitSwitchX();
		limitSwitchY=readLimitSwitchY();
		limitSwitchZ=readLimitSwitchZ();
		HAL_Delay(100);
	}*/
}


void moveXtest()
{
	uint32_t moveCntr=0;
	setDirX(1);
	HAL_GPIO_WritePin(PORT_X1,PIN_X1,GPIO_PIN_SET);
	while(moveCntr++<20000)
	{
		HAL_Delay(2);
		HAL_GPIO_TogglePin(PORT_X1,PIN_X1);
	}
}

void moveYtest()
{
	uint32_t moveCntr=0;
	setDirY(1);
	HAL_GPIO_WritePin(PORT_Y,PIN_Y,GPIO_PIN_SET);
	while(moveCntr++<20000)
	{
		HAL_Delay(2);
		HAL_GPIO_TogglePin(PORT_Y,PIN_Y);
	}
}

void moveZtest()
{
	uint32_t stepCntr=0;
	HAL_GPIO_WritePin(PORT_Z,PIN_Z,GPIO_PIN_SET);

	setDirZ(1);
	while(stepCntr<5000)
	{
		HAL_Delay(2);
		HAL_GPIO_TogglePin(PORT_Z,PIN_Z);
		stepCntr++;
	}

	setDirZ(0);
	stepCntr=0;
	while(stepCntr<5000)
	{
		HAL_Delay(2);
		HAL_GPIO_TogglePin(PORT_Z,PIN_Z);
		stepCntr++;
	}
}

void moveEtest()
{
	uint32_t moveCntr=0;
	setDirE(1);
	HAL_GPIO_WritePin(PORT_E,PIN_E,GPIO_PIN_SET);
	while(moveCntr++<20000)
	{
		HAL_Delay(2);
		HAL_GPIO_TogglePin(PORT_E,PIN_E);
	}
}

void readLimXTest()
{
	while(1)
	{
		if(readLimitSwitchX()==1)HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_RESET);
		else
		{
			HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_SET);
		}
		HAL_Delay(100);
	}
}

void readLimYTest()
{
	while(1)
	{
		if(readLimitSwitchY()==1)HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_RESET);
		else
		{
			HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_SET);
		}
		HAL_Delay(100);
	}
}


void readLimZTest()
{
	while(1)
	{
		if(readLimitSwitchZ()==1)HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_RESET);
		else
		{
			HAL_GPIO_WritePin(PORT_TEST_LED,PIN_TEST_LED, GPIO_PIN_SET);
		}
		HAL_Delay(100);
	}
}



void moveXYZbackwardTest()
{
	startStep(1,1,1,1, 100,100,100,100);
	while(1)
	{
		toggleX(0);
		toggleY(0);
		toggleZ(0);
		HAL_Delay(10);
	}
}


void moveExtruderTest()
{
	uint32_t cntrx=0;
	while(cntrx<10000)
	{
		toggleE(1);
		HAL_Delay(2);
		cntrx++;
	}
}

void readExtruderTempTest()
{
	/*
	volatile uint16_t temp;
	//	extruderHeaterOn();
	//	HAL_Delay(20000);
	//	extruderHeaterOff();
	while(1)
	{
		startADCconversions();
		HAL_Delay(50);
		temp=readExtruderTemp();
		HAL_Delay(200);

	}*/

}


void readHeatBedTempTest()
{
	/*
	volatile uint16_t temp;
	heatBedHeaterOn();
	HAL_Delay(30000);
	heatBedHeaterOff();
	while(1)
	{
		startADCconversions();
		HAL_Delay(50);
		temp=readBedTemp();
		HAL_Delay(200);

	}
	*/

}


uint8_t limxTest=2;
uint8_t limyTest=2;
uint8_t limzTest=2;
void IOtoggleTest()
{
	/*init pa0 pa1 as gpio for ıo test */
	GPIO_InitTypeDef  GPIO_InitStruct;
	GPIO_InitStruct.Pin = GPIO_PIN_0;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(GPIOA);
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);


	GPIO_InitStruct.Pin = GPIO_PIN_1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(GPIOA);
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);




	while(1)
	{
		HAL_GPIO_TogglePin(PORT_X1, PIN_X1);
		HAL_GPIO_TogglePin(PORT_Y, PIN_Y);
		HAL_GPIO_TogglePin(PORT_Z, PIN_Z);
		HAL_GPIO_TogglePin(PORT_E, PIN_E);

		HAL_GPIO_TogglePin(ENABLE_PORT_X1, ENABLE_PIN_X1);
		HAL_GPIO_TogglePin(ENABLE_PORT_Y, ENABLE_PIN_Y);
		HAL_GPIO_TogglePin(ENABLE_PORT_Z, ENABLE_PIN_Z);
		HAL_GPIO_TogglePin(ENABLE_PORT_E, ENABLE_PIN_E);

		HAL_GPIO_TogglePin(DIR_PORT_X1, DIR_PIN_X1);
		HAL_GPIO_TogglePin(DIR_PORT_Y, DIR_PIN_Y);
		HAL_GPIO_TogglePin(DIR_PORT_Z, DIR_PIN_Z);
		HAL_GPIO_TogglePin(DIR_PORT_E, DIR_PIN_E);

		HAL_GPIO_TogglePin(PORT_SLP_CLKX, PIN_SLP_CLKX);
		HAL_GPIO_TogglePin(PORT_SLP_CLKY, PIN_SLP_CLKY);
		HAL_GPIO_TogglePin(PORT_SLP_CLKZ, PIN_SLP_CLKZ);
		HAL_GPIO_TogglePin(PORT_SLP_CLKE, PIN_SLP_CLKE);

		HAL_GPIO_TogglePin(PORT_RST_PDNX, PIN_RST_PDNX);
		HAL_GPIO_TogglePin(PORT_RST_PDNY, PIN_RST_PDNY);
		HAL_GPIO_TogglePin(PORT_RST_PDNZ, PIN_RST_PDNZ);
		HAL_GPIO_TogglePin(PORT_RST_PDNE, PIN_RST_PDNE);

		HAL_GPIO_TogglePin(LIMIT_SWITCH_PORT_X, LIMIT_SWITCH_PIN_X);
		HAL_GPIO_TogglePin(LIMIT_SWITCH_PORT_Y, LIMIT_SWITCH_PIN_Y);
		HAL_GPIO_TogglePin(LIMIT_SWITCH_PORT_Z, LIMIT_SWITCH_PIN_Z);

		HAL_GPIO_TogglePin(PORTX_MS1, PORTX_PIN_MS1);
		HAL_GPIO_TogglePin(PORTX_MS2, PORTX_PIN_MS2);
		HAL_GPIO_TogglePin(PORTX_MS3, PORTX_PIN_MS3);

		HAL_GPIO_TogglePin(PORTY_MS1, PORTY_PIN_MS1);
		HAL_GPIO_TogglePin(PORTY_MS2, PORTY_PIN_MS2);
		HAL_GPIO_TogglePin(PORTY_MS3, PORTY_PIN_MS3);

		HAL_GPIO_TogglePin(PORTZ_MS1, PORTZ_PIN_MS1);
		HAL_GPIO_TogglePin(PORTZ_MS2, PORTZ_PIN_MS2);
		HAL_GPIO_TogglePin(PORTZ_MS3, PORTZ_PIN_MS3);

		HAL_GPIO_TogglePin(PORTE_MS1, PORTE_PIN_MS1);
		HAL_GPIO_TogglePin(PORTE_MS2, PORTE_PIN_MS2);
		HAL_GPIO_TogglePin(PORTE_MS3, PORTE_PIN_MS3);

		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_0);
		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_1);

//		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_15);
//		HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_9);
//		HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_11);

		limxTest=readLimitSwitchX();
		limyTest=readLimitSwitchY();
		limzTest=readLimitSwitchZ();



		HAL_Delay(1000);
	}
}


