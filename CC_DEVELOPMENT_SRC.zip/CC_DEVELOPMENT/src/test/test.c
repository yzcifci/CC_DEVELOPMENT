/*
 * test.c
 *
 *  Created on: 22 �ub 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct movementTest_ movementTest;

char dataTosend[256];
//char testGlineData[]={
//
//		"G1 X50 Y50 Z80\n"
//		"G0 X50 Y50 Z80\n"
//		"G1 X50 Y50 Z80\n"

//		"G0 X 50 Y 100\n"
//		"G1 X 100 Y 100 Z 10 F400\n"
//		"G1 X 100 Y 50 F800\n"
//		"G1 X 50 Y 50 F800\n"
//		"F400\n"
//};

char testGlineData[]={
";FLAVOR:Marlin\n"
";TIME:1337\n"
";Filament used: 1.20567m\n"
";Layer height: 0.15\n"
";Generated with Cura_SteamEngine 3.2.1\n"
"M190 S85\n"
"M104 S215\n"
"M109 S215\n"
"M82 ;absolute extrusion mode\n"
"G21 ;metric values\n"
"G90 ;absolute positioning\n"
"M82 ;set extruder to absolute mode\n"
"M107 ;start with the fan off\n"
"G28 X0 Y0 ;move X/Y to min endstops\n"
"G28 Z0 ;move Z to min endstops\n"
"G1 Z15.0 F9000 ;move the platform down 15mm\n"
"G92 E0 ;zero the extruded length\n"
"G1 F200 E3 ;extrude 3mm of feed stock\n"
"G92 E0 ;zero the extruded length again\n"
"G1 F9000\n"
";Put printing message on LCD screen\n"
"M117 Printing...\n"
";LAYER_COUNT:93\n"
";LAYER:0\n"
"M107\n"
"G0 F3600 X79.602 Y84.485 Z0.3\n"
";TYPE:SKIRT\n"
"G1 F1800 X80.188 Y83.955 E0.03942\n"
"G1 X80.824 Y83.488 E0.07878\n"
"G1 X81.504 Y83.087 E0.11817\n"
"G1 X82.222 Y82.757 E0.15759\n"
"G1 X82.969 Y82.502 E0.19697\n"
"G1 X83.738 Y82.323 E0.23636\n"
"G1 X84.522 Y82.223 E0.27579\n"
"G1 X85.117 Y82.2 E0.3055\n"

"G1 X114.883 Y82.2 E1.79053\n"
"G1 X115.672 Y82.24 E1.82995\n"
"G1 X116.452 Y82.359 E1.86931\n"
"G1 X117.217 Y82.557 E1.90874\n"
"G1 X117.957 Y82.831 E1.9481\n"
"G1 X118.666 Y83.179 E1.98751\n"
"G1 X119.337 Y83.597 E2.02695\n"
"G1 X119.961 Y84.08 E2.06632\n"
"G1 X120.398 Y84.485 E2.09604\n"
"G1 X120.515 Y84.602 E2.1043\n"
"G1 X121.045 Y85.188 E2.14372\n"
"G1 X121.512 Y85.824 E2.18308\n"
"G1 X121.913 Y86.504 E2.22247\n"
"G1 X122.243 Y87.222 E2.26189\n"
"G1 X122.498 Y87.969 E2.30127\n"
"G1 X122.677 Y88.738 E2.34066\n"
"G1 X122.777 Y89.522 E2.38009\n"

"G1 X122.8 Y90.117 E2.4098\n"
"G1 X122.8 Y109.883 E3.39593\n"
"G1 X122.76 Y110.672 E3.43534\n"
"G1 X122.641 Y111.452 E3.47471\n"
"G1 X122.443 Y112.217 E3.51413\n"
"G1 X122.169 Y112.957 E3.5535\n"
"G1 X121.821 Y113.666 E3.5929\n"
"G1 X121.403 Y114.337 E3.63234\n"
"G1 X120.92 Y114.961 E3.67171\n"
"G1 X120.515 Y115.398 E3.70143\n"
"G1 X120.398 Y115.515 E3.70969\n"
"G1 X119.812 Y116.045 E3.74911\n"
"G1 X119.176 Y116.512 E3.78847\n"
"G1 X118.496 Y116.913 E3.82786\n"
"G1 X117.778 Y117.243 E3.86728\n"
"G1 X117.031 Y117.498 E3.90666\n"
"G1 X116.262 Y117.677 E3.94605\n"
"G1 X115.478 Y117.777 E3.98548\n"
"G1 X114.883 Y117.8 E4.01519\n"
"G1 X85.117 Y117.8 E5.50022\n"
"G1 X84.328 Y117.76 E5.53964\n"
"G1 X83.548 Y117.641 E5.579\n"
"G1 X82.783 Y117.443 E5.61843\n"
"G1 X82.043 Y117.169 E5.65779\n"
"G1 X81.334 Y116.821 E5.6972\n"
"G1 X80.663 Y116.403 E5.73664\n"
"G1 X80.039 Y115.92 E5.77601\n"
"G1 X79.602 Y115.515 E5.80573\n"
"G1 X79.485 Y115.398 E5.81399\n"
"G1 X78.955 Y114.812 E5.85341\n"
"G1 X78.488 Y114.176 E5.89277\n"
"G1 X78.087 Y113.496 E5.93216\n"
"G1 X77.757 Y112.778 E5.97158\n"
"G1 X77.502 Y112.031 E6.01096\n"
"G1 X77.323 Y111.262 E6.05035\n"
"G1 X77.223 Y110.478 E6.08978\n"

};


void gLineSendTest()
{

	printLine("STARTSYSTEM");
	char *dataPntr=testGlineData;

	pars(dataPntr);

	while(1)
	{
		while(*dataPntr!='\n')dataPntr++;
		dataPntr++;
		while(parser.bufferStatus==BUFFER_FULL);

		if((*dataPntr=='G') && ((*(dataPntr+1))=='0'))
		{
			test.formerdata=246;
			test.formerbufferStatus=parser.bufferStatus;
		}

		if((dataPntr-testGlineData)>=(sizeof(testGlineData)-1))
		{
			return;
		}
		pars(dataPntr);

	}


}



void movementTestHandler(uint8_t coordinate, uint8_t dir)
{
	static uint8_t cntrx=0;
	static uint8_t cntry=0;
	static uint8_t cntrz=0;
	char sendData=0;

	switch (coordinate)
	{
	case COORDINATE_X:
		if(((++cntrx)%2)!=0)return;
		if(dir)movementTest.stepX++;
		else
			movementTest.stepX--;

		movementTest.dirX=dir;
		sendData=(dir<<2);
		putChar(sendData);
		break;
	case COORDINATE_Y:
		if(((++cntry)%2)!=0)return;
		if(dir)movementTest.stepY++;
		else
			movementTest.stepY--;

		movementTest.dirY=dir;
		sendData=((dir<<2)|0x01);
		putChar(sendData);
		break;
	case COORDINATE_Z:
		if(((++cntrz)%2)!=0)return;
		if(dir)movementTest.stepZ++;
		else
			movementTest.stepZ--;

		movementTest.dirZ=dir;
		sendData=((dir<<2)|0x02);
		putChar(sendData);
		break;
	}
	//	printLine("START");
	//
	//	movementTest.sendBuffer[0]=movementTest.stepX;
	//	movementTest.sendBuffer[1]=movementTest.stepX>>8;
	//	movementTest.sendBuffer[2]=movementTest.stepX>>16;
	//	movementTest.sendBuffer[3]=movementTest.stepX>>24;
	//	movementTest.sendBuffer[4]=movementTest.stepY;
	//	movementTest.sendBuffer[5]=movementTest.stepY>>8;
	//	movementTest.sendBuffer[6]=movementTest.stepY>>16;
	//	movementTest.sendBuffer[7]=movementTest.stepY>>24;
	//	movementTest.sendBuffer[8]=movementTest.stepZ;
	//	movementTest.sendBuffer[9]=movementTest.stepZ>>8;
	//	movementTest.sendBuffer[10]=movementTest.stepZ>>16;
	//	movementTest.sendBuffer[11]=movementTest.stepZ>>24;
	//	movementTest.sendBuffer[12]=movementTest.dirX;
	//	movementTest.sendBuffer[13]=movementTest.dirY;
	//	movementTest.sendBuffer[14]=movementTest.dirZ;
	//
	//	serialPrint((char*)&movementTest.sendBuffer,15);
	//	printLine("END");
}







void movementSerialTest()
{
	printLine("STARTSYSTEM");
	while(1)
	{
		HAL_Delay(50);
		movementTestHandler(COORDINATE_X, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Y, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Z, 1);
	}
}
