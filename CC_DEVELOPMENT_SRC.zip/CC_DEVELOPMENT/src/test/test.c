/*
 * test.c
 *
 *  Created on: 22 �ub 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct movementTest_ movementTest;


char testGlineData[]={

		"G0 X 243.431 Y 243.431\n"
//		"M3 M8\n"
//		"G0 Z   3.000\n"
//		"F150\n"
//		"G1 Z  -1.500\n"
		"F400\n"
};

void gLineSendTest()
{
	uint16_t cntr=0;
	while(cntr<sizeof(testGlineData))
	{
		serialLineParser(testGlineData[cntr]);
		cntr++;
	}
}



void movementTestHandler(uint8_t coordinate, uint8_t dir)
{
	static uint8_t cntrx=0;
	static uint8_t cntry=0;
	static uint8_t cntrz=0;

	switch (coordinate)
	{
	case COORDINATE_X:
		if(((++cntrx)%2)!=0)return;
		if(dir)movementTest.stepX++;
		else
			movementTest.stepX--;

		movementTest.dirX=dir;
		break;
	case COORDINATE_Y:
		if(((++cntry)%2)!=0)return;
		if(dir)movementTest.stepY++;
		else
			movementTest.stepY--;

		movementTest.dirY=dir;

		break;
	case COORDINATE_Z:
		if(((++cntrz)%2)!=0)return;
		if(dir)movementTest.stepZ++;
		else
			movementTest.stepZ--;

		movementTest.dirZ=dir;

		break;
	}
	printLine("START");

	movementTest.sendBuffer[0]=movementTest.stepX;
	movementTest.sendBuffer[1]=movementTest.stepX>>8;
	movementTest.sendBuffer[2]=movementTest.stepX>>16;
	movementTest.sendBuffer[3]=movementTest.stepX>>24;
	movementTest.sendBuffer[4]=movementTest.stepY;
	movementTest.sendBuffer[5]=movementTest.stepY>>8;
	movementTest.sendBuffer[6]=movementTest.stepY>>16;
	movementTest.sendBuffer[7]=movementTest.stepY>>24;
	movementTest.sendBuffer[8]=movementTest.stepZ;
	movementTest.sendBuffer[9]=movementTest.stepZ>>8;
	movementTest.sendBuffer[10]=movementTest.stepZ>>16;
	movementTest.sendBuffer[11]=movementTest.stepZ>>24;
	movementTest.sendBuffer[12]=movementTest.dirX;
	movementTest.sendBuffer[13]=movementTest.dirY;
	movementTest.sendBuffer[14]=movementTest.dirZ;

	serialPrint((char*)&movementTest.sendBuffer,15);
	printLine("END");
}







void movementSerialTest()
{
	movementTest.stepY=10;
	movementTest.stepZ=0;
	movementTest.dirX=1;
	movementTest.dirY=0;
	movementTest.dirZ=0;
	while(1)
	{
		movementTest.stepX++;
		movementTest.stepY++;
		printLine("START");
		movementTest.sendBuffer[0]=movementTest.stepX;
		movementTest.sendBuffer[1]=movementTest.stepX>>8;
		movementTest.sendBuffer[2]=movementTest.stepX>>16;
		movementTest.sendBuffer[3]=movementTest.stepX>>24;
		movementTest.sendBuffer[4]=movementTest.stepY;
		movementTest.sendBuffer[5]=movementTest.stepY>>8;
		movementTest.sendBuffer[6]=movementTest.stepY>>16;
		movementTest.sendBuffer[7]=movementTest.stepY>>24;
		movementTest.sendBuffer[8]=movementTest.stepZ;
		movementTest.sendBuffer[9]=movementTest.stepZ>>8;
		movementTest.sendBuffer[10]=movementTest.stepZ>>16;
		movementTest.sendBuffer[11]=movementTest.stepZ>>24;
		movementTest.sendBuffer[12]=movementTest.dirX;
		movementTest.sendBuffer[13]=movementTest.dirY;
		movementTest.sendBuffer[14]=movementTest.dirZ;

		serialPrint((char*)&movementTest.sendBuffer,15);
//				printLine("END");
		HAL_Delay(1);
	}
}
