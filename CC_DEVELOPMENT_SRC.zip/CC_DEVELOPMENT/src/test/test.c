/*
 * test.c
 *
 *  Created on: 22 �ub 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct movementTest_ movementTest;


//char testGlineData[]={
//
//		"G0 X 50 Y 50\n"
//		"G0 X 50 Y 100\n"
//		"G1 X 100 Y 100 Z 10 F400\n"
//		"G1 X 100 Y 50 F800\n"
//		"G1 X 50 Y 50 F800\n"
//		"F400\n"
//};

char testGlineData[]={
		";FLAVOR:Marlin\n"
		";TIME:1337\n"
		";Filament used: 1.20567m\n"
		";Layer height: 0.15\n"
		";Generated with Cura_SteamEngine 3.2.1\n"
		"M190 S85\n"
		"M104 S215\n"
		"M109 S215\n"
		"M82 ;absolute extrusion mode\n"
		"G21 ;metric values\n"
		"G90 ;absolute positioning\n"
		"M82 ;set extruder to absolute mode\n"
		"M107 ;start with the fan off\n"
		"G28 X0 Y0 ;move X/Y to min endstops\n"
		"G28 Z0 ;move Z to min endstops\n"
		"G1 Z15.0 F9000 ;move the platform down 15mm\n"
		"G92 E0 ;zero the extruded length\n"
		"G1 F200 E3 ;extrude 3mm of feed stock\n"
		"G92 E0 ;zero the extruded length again\n"
		"G1 F9000\n"
		";Put printing message on LCD screen\n"
		"M117 Printing...\n"
		";LAYER_COUNT:93\n"
		";LAYER:0\n"
		"M107\n"
		"G0 F3600 X79.602 Y84.485 Z0.3\n"
		";TYPE:SKIRT\n"
};


void gLineSendTest()
{
	uint16_t cntr=0;
	printLine("STARTSYSTEM");
//	while(cntr<sizeof(testGlineData))
//	{
//		serialLineParser(testGlineData[cntr]);
//		cntr++;
//	}


	while((operatorParserStateMachine.operatorParserState!=PARSER_BUFFER_FULL)&&
			cntr<sizeof(testGlineData))
	{
		serialLineParser(testGlineData[cntr]);
		cntr++;
	}
}



void movementTestHandler(uint8_t coordinate, uint8_t dir)
{
	static uint8_t cntrx=0;
	static uint8_t cntry=0;
	static uint8_t cntrz=0;
	char sendData=0;

	switch (coordinate)
	{
	case COORDINATE_X:
		if(((++cntrx)%2)!=0)return;
		if(dir)movementTest.stepX++;
		else
			movementTest.stepX--;

		movementTest.dirX=dir;
		sendData=(dir<<2);
		putChar(sendData);
		break;
	case COORDINATE_Y:
		if(((++cntry)%2)!=0)return;
		if(dir)movementTest.stepY++;
		else
			movementTest.stepY--;

		movementTest.dirY=dir;
		sendData=((dir<<2)|0x01);
		putChar(sendData);
		break;
	case COORDINATE_Z:
		if(((++cntrz)%2)!=0)return;
		if(dir)movementTest.stepZ++;
		else
			movementTest.stepZ--;

		movementTest.dirZ=dir;
		sendData=((dir<<2)|0x02);
		putChar(sendData);
		break;
	}
//	printLine("START");
//
//	movementTest.sendBuffer[0]=movementTest.stepX;
//	movementTest.sendBuffer[1]=movementTest.stepX>>8;
//	movementTest.sendBuffer[2]=movementTest.stepX>>16;
//	movementTest.sendBuffer[3]=movementTest.stepX>>24;
//	movementTest.sendBuffer[4]=movementTest.stepY;
//	movementTest.sendBuffer[5]=movementTest.stepY>>8;
//	movementTest.sendBuffer[6]=movementTest.stepY>>16;
//	movementTest.sendBuffer[7]=movementTest.stepY>>24;
//	movementTest.sendBuffer[8]=movementTest.stepZ;
//	movementTest.sendBuffer[9]=movementTest.stepZ>>8;
//	movementTest.sendBuffer[10]=movementTest.stepZ>>16;
//	movementTest.sendBuffer[11]=movementTest.stepZ>>24;
//	movementTest.sendBuffer[12]=movementTest.dirX;
//	movementTest.sendBuffer[13]=movementTest.dirY;
//	movementTest.sendBuffer[14]=movementTest.dirZ;
//
//	serialPrint((char*)&movementTest.sendBuffer,15);
//	printLine("END");
}







void movementSerialTest()
{
	printLine("STARTSYSTEM");
	while(1)
	{
		HAL_Delay(500);
		movementTestHandler(COORDINATE_X, 1);
		HAL_Delay(500);
		movementTestHandler(COORDINATE_Y, 1);
		HAL_Delay(500);
		movementTestHandler(COORDINATE_Z, 1);
	}
}
