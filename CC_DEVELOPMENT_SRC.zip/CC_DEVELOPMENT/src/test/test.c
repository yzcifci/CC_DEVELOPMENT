/*
 * test.c
 *
 *  Created on: 22 �ub 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"


//char testGlineData[]={"G00 X 33.333 Y44.444 Z1.34\n"
//		"G01 X 12.333 Y48.444 Z1.34 F 312.0\n"
//		};

char testGlineData[]={
//"G21 (Units in millimeters)\n"
//"G90 (Absolute programming)\n"
//"G64 (Default cutting) G17 (XY plane) G40 (Cancel radius comp.) G49 (Cancel length comp.)\n"
//"G0 Z  15.000 \n"
//"(*** LAYER: 0 ***)\n"
//"T1 M6\n"
//"S6000\n"

		"G0 X 243.431 Y 243.431\n"
		"M3 M8\n"
		"G0 Z   3.000\n"
		"F150\n"
		"G1 Z  -1.500\n"
		"F400\n"
};

void gLineSendTest()
{
	uint16_t cntr=0;
	while(cntr<sizeof(testGlineData))
	{
		serialLineParser(testGlineData[cntr]);
		cntr++;
	}
}


