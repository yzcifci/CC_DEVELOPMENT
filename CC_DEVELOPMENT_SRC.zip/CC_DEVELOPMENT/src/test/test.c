/*
 * test.c
 *
 *  Created on: 22 �ub 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct movementTest_ movementTest;

char dataTosend[256];
//char testGlineData[]={
//
//		"G1 X50 Y50 Z80\n"
//		"G0 X50 Y50 Z80\n"
//		"G1 X50 Y50 Z80\n"

//		"G0 X 50 Y 100\n"
//		"G1 X 100 Y 100 Z 10 F400\n"
//		"G1 X 100 Y 50 F800\n"
//		"G1 X 50 Y 50 F800\n"
//		"F400\n"
//};

char testGlineData[]={
"G0 F3600 X79.602 Y84.485 Z0.3\n"
"G1 F1800 X85.117 Y82.2 E0.3055\n"
"G1 X114.883 Y82.2 E1.79053\n"
};


void gLineSendTest()
{

	printLine("STARTSYSTEM");
	char *dataPntr=testGlineData;

	pars(dataPntr);

	while(1)
	{
		while(*dataPntr!='\n')dataPntr++;
		dataPntr++;
		while(parser.bufferStatus==BUFFER_FULL);

		if((*dataPntr=='G') && ((*(dataPntr+1))=='0'))
		{
			test.formerdata=246;
			test.formerbufferStatus=parser.bufferStatus;
		}

		if((dataPntr-testGlineData)>=(sizeof(testGlineData)-1))
		{
			return;
		}
		pars(dataPntr);

	}


}



void movementTestHandler(uint8_t coordinate, uint8_t dir)
{
	static uint8_t cntrx=0;
	static uint8_t cntry=0;
	static uint8_t cntrz=0;
	char sendData=0;

	switch (coordinate)
	{
	case COORDINATE_X:
		if(((++cntrx)%2)!=0)return;
		if(dir)movementTest.stepX++;
		else
			movementTest.stepX--;

		movementTest.dirX=dir;
		sendData=(dir<<2);
		putChar(sendData);
		break;
	case COORDINATE_Y:
		if(((++cntry)%2)!=0)return;
		if(dir)movementTest.stepY++;
		else
			movementTest.stepY--;

		movementTest.dirY=dir;
		sendData=((dir<<2)|0x01);
		putChar(sendData);
		break;
	case COORDINATE_Z:
		if(((++cntrz)%2)!=0)return;
		if(dir)movementTest.stepZ++;
		else
			movementTest.stepZ--;

		movementTest.dirZ=dir;
		sendData=((dir<<2)|0x02);
		putChar(sendData);
		break;
	}
	//	printLine("START");
	//
	//	movementTest.sendBuffer[0]=movementTest.stepX;
	//	movementTest.sendBuffer[1]=movementTest.stepX>>8;
	//	movementTest.sendBuffer[2]=movementTest.stepX>>16;
	//	movementTest.sendBuffer[3]=movementTest.stepX>>24;
	//	movementTest.sendBuffer[4]=movementTest.stepY;
	//	movementTest.sendBuffer[5]=movementTest.stepY>>8;
	//	movementTest.sendBuffer[6]=movementTest.stepY>>16;
	//	movementTest.sendBuffer[7]=movementTest.stepY>>24;
	//	movementTest.sendBuffer[8]=movementTest.stepZ;
	//	movementTest.sendBuffer[9]=movementTest.stepZ>>8;
	//	movementTest.sendBuffer[10]=movementTest.stepZ>>16;
	//	movementTest.sendBuffer[11]=movementTest.stepZ>>24;
	//	movementTest.sendBuffer[12]=movementTest.dirX;
	//	movementTest.sendBuffer[13]=movementTest.dirY;
	//	movementTest.sendBuffer[14]=movementTest.dirZ;
	//
	//	serialPrint((char*)&movementTest.sendBuffer,15);
	//	printLine("END");
}







void movementSerialTest()
{
	printLine("STARTSYSTEM");
	while(1)
	{
		HAL_Delay(50);
		movementTestHandler(COORDINATE_X, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Y, 1);
		HAL_Delay(50);
		movementTestHandler(COORDINATE_Z, 1);
	}
}
