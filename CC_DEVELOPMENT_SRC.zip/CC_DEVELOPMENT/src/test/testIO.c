/*
 * serialIO.c
 *
 *  Created on: 26 �ub 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"


void initTtestPorts()
{
GPIO_InitTypeDef  GPIO_InitStruct;
/* Configure the PORT X1 pin */

GPIO_InitStruct.Pin = X1_STEP_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(X1_STEP_PORT);
HAL_GPIO_Init(X1_STEP_PORT, &GPIO_InitStruct);

GPIO_InitStruct.Pin = X2_STEP_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(X2_STEP_PORT);
HAL_GPIO_Init(X2_STEP_PORT, &GPIO_InitStruct);

GPIO_InitStruct.Pin = Y_STEP_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(Y_STEP_PORT);
HAL_GPIO_Init(Y_STEP_PORT, &GPIO_InitStruct);

GPIO_InitStruct.Pin = Z_STEP_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(Z_STEP_PORT);
HAL_GPIO_Init(Z_STEP_PORT, &GPIO_InitStruct);

GPIO_InitStruct.Pin = X1_DIR_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(X1_DIR_PORT);
HAL_GPIO_Init(X1_DIR_PORT, &GPIO_InitStruct);

GPIO_InitStruct.Pin = X2_DIR_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(X2_DIR_PORT);
HAL_GPIO_Init(X2_DIR_PORT, &GPIO_InitStruct);

GPIO_InitStruct.Pin = Y_DIR_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(Y_DIR_PORT);
HAL_GPIO_Init(Y_DIR_PORT, &GPIO_InitStruct);

GPIO_InitStruct.Pin = Z_DIR_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(Z_DIR_PORT);
HAL_GPIO_Init(Z_DIR_PORT, &GPIO_InitStruct);

GPIO_InitStruct.Pin = X1_EN_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(X1_EN_PORT);
HAL_GPIO_Init(X1_EN_PORT, &GPIO_InitStruct);

GPIO_InitStruct.Pin = X2_EN_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(X2_EN_PORT);
HAL_GPIO_Init(X2_EN_PORT, &GPIO_InitStruct);

GPIO_InitStruct.Pin = Y_EN_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(Y_EN_PORT);
HAL_GPIO_Init(Y_EN_PORT, &GPIO_InitStruct);

GPIO_InitStruct.Pin = Z_EN_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT|GPIO_MODE_IT_RISING_FALLING;
GPIO_InitStruct.Pull = GPIO_PULLUP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
GPIO_CLOCK_ENABLE(Z_EN_PORT);
HAL_GPIO_Init(Z_EN_PORT, &GPIO_InitStruct);


}


void EXTI0_IRQHandler()
{

}



