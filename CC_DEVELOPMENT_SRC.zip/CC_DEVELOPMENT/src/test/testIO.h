/*
 * testIO.h
 *
 *  Created on: 26 �ub 2018
 *      Author: yzcifci
 */

#ifndef TEST_TESTIO_H_
#define TEST_TESTIO_H_

#define X1_STEP_PORT	GPIOA
#define X2_STEP_PORT	GPIOA
#define Y_STEP_PORT		GPIOA
#define Z_STEP_PORT		GPIOA

#define X1_STEP_PIN		GPIO_PIN_1
#define X2_STEP_PIN		GPIO_PIN_1
#define Y_STEP_PIN		GPIO_PIN_1
#define Z_STEP_PIN		GPIO_PIN_1

#define X1_DIR_PORT		GPIOA
#define X2_DIR_PORT		GPIOA
#define Y_DIR_PORT		GPIOA
#define Z_DIR_PORT		GPIOA

#define X1_DIR_PIN		GPIO_PIN_1
#define X2_DIR_PIN		GPIO_PIN_1
#define Y_DIR_PIN		GPIO_PIN_1
#define Z_DIR_PIN		GPIO_PIN_1


#define X1_EN_PORT		GPIOA
#define X2_EN_PORT		GPIOA
#define Y_EN_PORT		GPIOA
#define Z_EN_PORT		GPIOA

#define X1_EN_PIN		GPIO_PIN_1
#define X2_EN_PIN		GPIO_PIN_1
#define Y_EN_PIN		GPIO_PIN_1
#define Z_EN_PIN		GPIO_PIN_1


void initTtestPorts();

#endif /* TEST_TESTIO_H_ */
