/*
 * serialTest.h
 *
 *  Created on: 26 �ub 2018
 *      Author: yzcifci
 */

#ifndef TEST_SERIALTEST_H_
#define TEST_SERIALTEST_H_

void serialPrintTest(char *pData, uint16_t Size );
void printLineTest(char *data);
void putCharTest(char data);
void serialTesTest();
void initTestSerialCom();
HAL_StatusTypeDef HAL_UART_InitSerial(UART_HandleTypeDef *huart);
void HAL_UART_MspInitSerial(UART_HandleTypeDef* huart);
void UART_SetConfigTest(UART_HandleTypeDef *huart);

#endif /* TEST_SERIALTEST_H_ */
