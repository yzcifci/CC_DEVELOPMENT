/*
 * accelerationControl.h
 *
 *  Created on: 28 Oca 2019
 *      Author: yzcifci
 */

#ifndef ACCELERATIONCONTROL_H_
#define ACCELERATIONCONTROL_H_

#define MOVE_TABLE_SIZE	32

typedef struct
{
	float x;
	float y;
	float z;
	float e;
	float f;

	float stepX;
	float stepY;
	float stepZ;
	float stepE;

	float f1sx;
	float a1x;
	float p1x;
	float f1sy;
	float a1y;
	float p1y;

	float f2sx;
	float a2x;
	float p2x;
	float f2sy;
	float a2y;
	float p2y;

	float fz;

	float f1se;
	float a1e;
	float p1e;

	float f2se;
	float a2e;
	float p2e;


	uint8_t dirX;
	uint8_t dirY;
	uint8_t dirZ;
	uint8_t dirE;

}parserAssign;

extern struct acceControl_
{
	uint16_t index;
	//float accelerationVal;

	uint32_t acceControlledNofData;
	uint16_t startIndex;
//	stepPosXYZE stepPos;
//	positionXYZE pos;

	float traceFeed;
	struct
	{
		float angleReal;
		float angle;
		float feed;
		float startFeed;
		float endFeed;
		float xSub;
		float ySub;
		float eSub;
		float length;
		uint32_t add;
	}movTable[MOVEMENT_TABLE_PARAMETER_SIZE];
}acceControl;

typedef struct
{
	float a1;
	float p1;
	float a2;
	float p2;
	float startFeed;
}acceChar;







/*
 * accelerationControl.c
 *
 *  Created on: 28 Oca 2019
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct acceControl_ acceControl;

void initAccelerationControlUnit();
void accelerationCorrect();
void updateNonAcceleratedParserData(uint16_t index);
void forwardMovementAnalayze(float crossFeed);
void forwardMovementAccelerateAnalayze();
float accMoveTimeX(float startFeed,float t,float angle,float a,float p);
float accMoveTimeY(float startFeed,float t,float angle,float a,float p);
void updateParsedData(float a1, float a2, float p1, float p2, int16_t index );
void backwardMovementAnalayze();
void backwardAccelerationAnalayze();
acceChar getAccelerationCharacterisitics(float startFeed, float endFeed, float assignedFeed, float length,float acceleration);
float equationSolverGetRoot(float a, float b, float c);
float getStartFeed(float endFeed, float acceleration, float assginedFeed, float length);
float getMovementTimeLength(float startSpeed, float length, float acceleration );
void updateMoveTable(uint32_t address);
float measureCorssFeedRate();
void accelerationError(uint16_t);
float getFeedXaxis(float angle, float feed);
float getFeedYaxis(float angle, float feed);






#endif /* ACCELERATIONCONTROL_H_ */
