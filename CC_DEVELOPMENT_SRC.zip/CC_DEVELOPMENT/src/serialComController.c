/*
 * serialComController.c
 *
 *  Created on: 13 �ub 2018
 *      Author: yzcifci
 */

//#include "serialComController.h"
//#include "serialCom.h"
#include "task_operator_interface.h"
struct serialInterFace_ serialInterFace;

void initSerialCom()
{
	UartHandle.pRxBuffPtr=&serialInterFace.RxBuffer[0];
	uartInit();
	resetSerialInterfaceParameters();
}

void resetSerialInterfaceParameters()
{
	memset(&serialInterFace,0x0,sizeof(serialInterFace));
}


void serialLineParser(char receiveData)
{
	uint8_t parserStatus;
	uint8_t state;

	state=operatorParserStateControl();

	switch (state)
	{
	case PARSER_BUFFER_FULL:
		sendResponse(BUFFER_FULL);
			return;
	case OPERATOR_PARSER_BUFFER_NOT_FULL:
	case OPERATOR_BUFFER_FULL:
		serialInterFace.RxBuffer[serialInterFace.RxCounter++]=receiveData;
		if(receiveData=='\n')
		{
			serialInterFace.RxCounter=0;
			parserStatus=mainParser(serialInterFace.RxBuffer);
			sendResponse(parserStatus);
			serialInterFace.lineCntr++;
		}
		break;
	}

}

void serialReceiveCopy(char* destination, char *source)
{
	while(*source!='\n')
	{
		*destination++=*source++;
	}

}

void sendResponse(char status)
{
//	switch(status)
//	{
//	case BUFFER_NOT_FULL:
//		printLine("OK\n");
//		break;
//	case BUFFER_FULL:
//		printLine("BUFFER FULL\n");
//		break;
//
//	}

}
