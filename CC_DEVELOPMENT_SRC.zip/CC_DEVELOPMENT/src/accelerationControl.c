/*
 * accelerationControl.c
 *
 *  Created on: 28 Oca 2019
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct acceControl_ acceControl;

void initAccelerationControlUnit()
{
	memset(&acceControl,0x0,sizeof(acceControl));
	acceControl.accelerationVal=100;
	acceControl.traceFeed=0;
	acceControl.movTable[0].add=(uint32_t)&parser.parameters[PARSER_PARAMETER_SIZE-1].parameter[0];
	for(uint32_t i=0; i<MOVEMENT_TABLE_PARAMETER_SIZE;i++)
	{
		acceControl.movTable[i].length=0;
		acceControl.movTable[i].xSub=0;
		acceControl.movTable[i].ySub=0;
	}
}

void accelerationCorrect()
{
	static uint32_t oldParserHead=0;
	uint16_t headerIndex=getIndex(parser.head, -1, PARSER_PARAMETER_SIZE);
	if((parser.parameters[headerIndex].task==G00_RAPID_MOVEMENT)||(parser.parameters[headerIndex].task==G01_LINEAR_INTERPOLATION))
	{
		updateMoveTable((uint32_t)parser.parameters[headerIndex].parameter);
		if((acceControl.accelerationVal!=0)&&(acceControl.movTable[acceControl.index].length!=0))
		{
			float crossFeed=measureCorssFeedRate();
			forwardMovementAnalayze(crossFeed);
		}
		else
		{
			updateNonAcceleratedParserData(acceControl.index);
		}
	}
	if(oldParserHead!=parser.head)
	{
		acceControl.acceControlledNofData++;
		oldParserHead=parser.head;
	}

	if(acceControl.acceControlledNofData>=(MOVEMENT_TABLE_PARAMETER_SIZE))
	{
		parser.workableHead=plusIndex(parser.workableHead,PARSER_PARAMETER_SIZE);
		parser.workableTailHeadDiff=plusIndex(parser.workableTailHeadDiff,PARSER_PARAMETER_SIZE);
		if((parser.parameters[parser.workableHead].task==G00_RAPID_MOVEMENT) ||
				(parser.parameters[parser.workableHead].task==G01_LINEAR_INTERPOLATION))
		{
			acceControl.startIndex=plusIndex(acceControl.startIndex,MOVEMENT_TABLE_PARAMETER_SIZE);
		}
	}
}
void updateNonAcceleratedParserData(uint16_t index)
{
	parserAssign* data=(parserAssign*)acceControl.movTable[index].add;
	float assignedF=data->f;
	float xStarF=assignedF*cos(acceControl.movTable[index].angle);
	float yStarF=assignedF*sin(acceControl.movTable[index].angle);
	float t;
	float t1se;
	float stepE=data->stepE;

	if(stepE)
	{
		if(acceControl.movTable[index].length)
		{
			t=acceControl.movTable[index].length/(acceControl.movTable[index].feed/60);
			t1se=(t*TIME_DIVISION_PER_SEC)/stepE;
		}
		else
		{
			t1se=getPulsePeriodE(assignedF);
		}
	}
	else
	{
		t1se=0;
	}

	data->t1ax=0;
	data->p1x=0;
	data->t1ay=0;
	data->p1y=0;
	data->t2sx=0;

	data->t2ax=0;
	data->p2x=0;
	data->t2sy=0;
	data->t2ay=0;
	data->p2y=0;

	if(acceControl.movTable[index].xSub)data->t1sx=getPulsePeriodXFrac(xStarF);
	else
	{
		data->t1sx=0;
	}

	if(acceControl.movTable[index].ySub)data->t1sy=getPulsePeriodYFrac(yStarF);
	else
	{
		data->t1sy=0;
	}



	data->t1se=t1se;
	data->t1ae=0;
	data->p1e=0;

	data->t2se=0;
	data->t2ae=0;
	data->p2e=0;


}
void forwardMovementAnalayze(float crossFeed)
{

	uint16_t index=acceControl.index;
	uint16_t prevIndex=getIndex(acceControl.index, -1, MOVE_TABLE_SIZE);

	float endFeed=acceControl.movTable[prevIndex].endFeed;
	if(endFeed>crossFeed)
	{

		acceControl.movTable[prevIndex].endFeed=crossFeed;
		acceControl.movTable[index].startFeed=crossFeed;
		backwardMovementAnalayze(crossFeed);
	}
	else
	{


		if(acceControl.movTable[prevIndex].endFeed==0)
		{//başlangıç feedrate 0 olamaz sonsuza kadar beklememeli
			acceControl.movTable[index].startFeed=100;
			acceControl.movTable[prevIndex].endFeed=100;
		}
		else
		{
			acceControl.movTable[index].startFeed=acceControl.movTable[prevIndex].endFeed;
		}

	}

	forwardMovementAccelerateAnalayze();
}


void forwardMovementAccelerateAnalayze()
{

	uint16_t index=acceControl.index;
	parserAssign *data=(parserAssign*)acceControl.movTable[index].add;

	float a1,a2,p1;

	float startF		=acceControl.movTable[index].startFeed;
	float assignedF		=data->f;
	float startV		=startF/60;
	float assignedV		=assignedF/60;
	float l				=acceControl.movTable[index].length;

	float a				=(acceControl.accelerationVal)/2;
	float b				=startV;
	float c				=-l;
	float t				=equationSolverGetRoot(a,b,c);

	float acelerateTime	=t;

	if(startV==assignedV)
	{
		a1=0;
		a2=0;
		acceControl.movTable[index].endFeed=assignedF;
	}
	else if((startV+(t*acceControl.accelerationVal))>=assignedV)
	{// model 1
		acelerateTime=(assignedV-startV)/acceControl.accelerationVal;
		a1=acceControl.accelerationVal;
		p1=((acelerateTime*acelerateTime*acceControl.accelerationVal)/2)+(acelerateTime*startV) ;
		a2=0;
		acceControl.movTable[index].endFeed=assignedF;
	}
	else
	{ // model 2
		a1=acceControl.accelerationVal;
		p1=l;
		a2=0;
		acceControl.movTable[index].endFeed=(startV+(acelerateTime*acceControl.accelerationVal))*60;
	}
	updateParsedData(a1, a2, p1, 0,index );
}

void updateParsedData(float a1, float a2, float p1, float p2, int16_t index )
{
	float startFeed=acceControl.movTable[index].startFeed;
	float endFeed=acceControl.movTable[index].endFeed;
	float angle=acceControl.movTable[index].angle;
	float length=acceControl.movTable[index].length;
	float eDivRate=0;
	parserAssign *parserData=(parserAssign*)acceControl.movTable[index].add;

	float xSub=fabs(acceControl.movTable[index].xSub);
	float ySub=fabs(acceControl.movTable[index].ySub);
	float eSub=fabs(acceControl.movTable[index].eSub);
	if(eSub)eDivRate=length/eSub;


	if(a1)
	{
		float a=a1/2;
		float b=startFeed/60; //vstart
		float c=-p1;
		float t=equationSolverGetRoot(a,b,c);
		float startF,p1Feed,startT1,endT1,pStep,t1ax,t1ay;

		if(xSub)
		{
			startF						=(startFeed)*cos(angle);
			p1Feed						=startF+((a1*t)*cos(angle)*60);
			startT1						=getPulsePeriodXFrac(startF);
			endT1						=getPulsePeriodXFrac(p1Feed);
			pStep						=mmToStepX(p1*cos(angle));
			t1ax						=(startT1-endT1)/pStep;

			parserData->p1x				=pStep;
			parserData->t1ax			=t1ax;
			parserData->t1sx			=startT1;
		}
		else
		{
			parserData->p1x				=0;
			parserData->t1ax			=0;
			parserData->t1sx			=0;

		}


		if(ySub)
		{
			startF						=(startFeed)*sin(angle);
			p1Feed						=startF+((a1*t)*sin(angle)*60);
			startT1						=getPulsePeriodYFrac(startF);
			endT1						=getPulsePeriodYFrac(p1Feed);
			pStep						=mmToStepY(p1*sin(angle));
			t1ay						=(startT1-endT1)/pStep;

			parserData->p1y				=pStep;
			parserData->t1ay			=t1ay;
			parserData->t1sy			=startT1;
		}
		else
		{
			parserData->p1y				=0;
			parserData->t1ay			=0;
			parserData->t1sy			=0;
		}

		if(eSub)
		{
			float p1E					=(p1/length)*eSub;
			float a1e					=a1/eDivRate;
			startF						=startFeed/eDivRate;
			p1Feed						=startF+(a1e*t);
			startT1						=getPulsePeriodEFrac(startF);
			endT1						=getPulsePeriodEFrac(p1Feed);
			pStep						=mmToStepE(p1E);
			float t1ae					=(startT1-endT1)/pStep;
			float t1se					=getPulsePeriodEFrac(startF);

			parserData->p1e				=pStep;
			parserData->t1ae			=t1ae;
			parserData->t1se			=t1se;
		}
		else
		{
			parserData->p1e				=0;
			parserData->t1ae			=0;
			parserData->t1se			=0;
		}
	}
	else
	{
		float t1sx					=getPulsePeriodXFrac(startFeed*cos(angle));
		parserData->t1ax			=0;
		parserData->p1x				=0;
		parserData->t1sx			=t1sx;

		float t1sy					=getPulsePeriodYFrac(startFeed*sin(angle));
		parserData->t1ay			=0;
		parserData->p1y				=0;
		parserData->t1sy			=t1sy;

		float t1se					=getPulsePeriodEFrac(startFeed/eDivRate);
		parserData->p1e				=0;
		parserData->t1ae			=0;
		parserData->t1se			=t1se;

	}

	if(a2)
	{
		float a=a2/2;
		float b=endFeed/60; //vstart
		float c=-(length-p2);
		float t=equationSolverGetRoot(a,b,c);

		float endF,p2Feed,endT2,startT2,pStepSub,pStep,t2ax,t2ay;

		if(xSub)
		{
			endF						=(endFeed)*cos(angle);
			p2Feed						=endF+((a2*t)*cos(angle)*60);
			endT2						=getPulsePeriodXFrac(endF);
			startT2						=getPulsePeriodXFrac(p2Feed);
			pStepSub					=mmToStepX((length-p2)*cos(angle));
			pStep						=mmToStepX((p2)*cos(angle));
			t2ax						=(endT2-startT2)/pStepSub;

			parserData->p2x				=pStep;
			parserData->t2ax			=t2ax;
			parserData->t2sx			=startT2;
		}
		else
		{
			parserData->p2x				=0;
			parserData->t2ax			=0;
			parserData->t2sx			=0;
		}

		if(ySub)
		{
			endF						=(endFeed)*sin(angle);
			p2Feed						=endF+((a2*t)*sin(angle)*60);
			endT2						=getPulsePeriodYFrac(endF);
			startT2						=getPulsePeriodYFrac(p2Feed);
			pStepSub					=mmToStepY((length-p2)*sin(angle));
			pStep						=mmToStepY((p2)*sin(angle));
			t2ay						=(endT2-startT2)/pStepSub;

			parserData->p2y				=pStep;
			parserData->t2ay			=t2ay;
			parserData->t2sy			=startT2;
		}
		else
		{
			parserData->p2y				=0;
			parserData->t2ay			=0;
			parserData->t2sy			=0;
		}


		if(eSub)
		{
			float p2E					=(p2/length)*eSub;
			float a2e					=a2/eDivRate;
			endF						=endFeed/eDivRate;
			p2Feed						=endF+(a2e*t);
			endT2						=getPulsePeriodEFrac(endF);
			startT2						=getPulsePeriodEFrac(p2Feed);
			pStep						=mmToStepE(p2E);
			float t2ae					=(endT2-startT2)/pStep;
			float t2se					=getPulsePeriodEFrac(endF);

			parserData->p2e				=pStep;
			parserData->t2ae			=t2ae;
			parserData->t2se			=t2se;
		}
		else
		{
			parserData->p2e				=0;
			parserData->t2ae			=0;
			parserData->t2se			=0;
		}



	}
	else
	{
		parserData->t2ax			=0;
		parserData->p2x				=0;
		parserData->t2sx			=0;

		parserData->t2ay			=0;
		parserData->p2y				=0;
		parserData->t2sy			=0;

		parserData->p2e				=0;
		parserData->t2ae			=0;
		parserData->t2se			=0;
	}

}
void backwardMovementAnalayze()
{
	backwardAccelerationAnalayze();
}

void backwardAccelerationAnalayze()
{
	uint16_t prevIndex;
	uint16_t index=acceControl.index;
	acceChar acceData;

	float a1,a2,p1,p2;

	while(acceControl.startIndex!=prevIndex)
	{

		prevIndex=getIndex(index, -1, MOVE_TABLE_SIZE);

		acceControl.movTable[prevIndex].endFeed=acceControl.movTable[index].startFeed;
		float length=acceControl.movTable[prevIndex].length;
		float accelerate=acceControl.accelerationVal;

		acceData=getAccelerationCharacterisitics(acceControl.movTable[prevIndex].startFeed,
				acceControl.movTable[prevIndex].endFeed,
				acceControl.movTable[prevIndex].feed, length, accelerate);

		if(acceControl.movTable[prevIndex].startFeed!=acceData.startFeed)
		{//negative continue backward
			acceControl.movTable[prevIndex].startFeed=acceData.startFeed;

			a1=acceData.a1;
			p1=acceData.p1;
			a2=acceData.a2;
			p2=acceData.p2;
			updateParsedData(a1, a2, p1, p2,prevIndex );
		}
		else
		{//ok update parameters end finish
			a1=acceData.a1;
			p1=acceData.p1;
			a2=acceData.a2;
			p2=acceData.p2;
			updateParsedData(a1, a2, p1, p2,prevIndex);
			return;
		}

		index=getIndex(index, -1, MOVE_TABLE_SIZE);
	}
}

acceChar getAccelerationCharacterisitics(float startFeed, float endFeed, float assignedFeed, float length,float acceleration)
{
	acceChar chrst;
	float startV=startFeed/60;
	float endV=endFeed/60;
	float assignedV=assignedFeed/60;
	float t,t1,t2;
	t=(startV-endV)/acceleration;
	float l1=(endV*t) + ((acceleration*t*t)/2);

	if(l1<length)
	{//decide model 1-2-3-4-5 positive

		if((startFeed>(assignedFeed-5)) && (startFeed<(assignedFeed+5)))
		{//decide model 4-5
			t=((assignedV-endV)/acceleration);
			l1=(endV*t) + ((acceleration*t*t)/2);

			if(l1<length)
			{ //model5
				t2 =(assignedV-endV)/acceleration;
				chrst.p2=length-(((acceleration*t2*t2)/2) + (endV*t2));
				chrst.a2=acceleration;
				chrst.a1=0;
			}
			else
			{//model4
				chrst.p2=0;
				chrst.a2=acceleration;
				chrst.a1=0;

			}


		}
		else
		{//model 1-2-3
			t1=((assignedV-startV)/acceleration);
			t2=((assignedV-endV)/acceleration);
			l1=(startV*t1)+((acceleration*t1*t1)/2)+(endV*t2)+((acceleration*t2*t2)/2);

			if((l1>(length-0.1))&&(l1<(length+0.1)))
			{//model2
				chrst.p1=(startV*t1)+((acceleration*t1*t1)/2);
				chrst.a1=acceleration;
				chrst.p2=chrst.p1;
				chrst.a2=acceleration;

			}
			else if(length>l1)
			{//model3

				chrst.p1=(startV*t1)+((acceleration*t1*t1)/2);
				chrst.a1=acceleration;
				chrst.p2=length-((((acceleration*t2*t2)/2)+(endV*t2)));
				chrst.a2=acceleration;
			}
			else
			{ //model1

				float a=acceleration;
				float b=2*endV;
				float c=(((endV*endV)-(startV*startV))/(2*acceleration))-length;

				t2=equationSolverGetRoot(a,b,c);
				t1=((endV-startV)/(acceleration))+t2;

				chrst.p1=(startV*t1)+((acceleration*t1*t1)/2);
				chrst.a1=acceleration;
				chrst.p2=chrst.p1;
				chrst.a2=acceleration;

			}
		}
		chrst.startFeed=startFeed;

	}
	else
	{// model 6 na

		float a=(acceleration/2);
		float b=(endV);
		float c=-length;
		t2=equationSolverGetRoot(a,b,c);
		chrst.startFeed=(endV+(acceleration*t2))*60;
		chrst.a2=acceleration;
		chrst.a1=0;
		chrst.p1=0;
		chrst.p2=0;
	}

	return chrst;
}

float equationSolverGetRoot(float a, float b, float c)
{
	float delta=b*b-4*a*c;
	float root=(-b+sqrt(delta))/(2*a);
	return root;

}
float getStartFeed(float endFeed, float acceleration, float assginedFeed, float length)
{
	float startFeed;
	float accelelrationTime=(endFeed-assginedFeed)/acceleration;
	float accelerationLength=(acceleration*accelelrationTime*accelelrationTime)/2;
	if(accelerationLength>length)
	{

		accelelrationTime=sqrt((2*length)/acceleration);
		startFeed=(accelelrationTime*acceleration)+endFeed;
	}
	else
	{

		startFeed=assginedFeed;
	}
	return startFeed;

}



float getMovementTimeLength(float startSpeed, float length, float acceleration )
{
	float a=acceleration/2;
	float b=startSpeed;
	float c=length;
	float delta=(b*b-(4*a*c));
	float t=(-b+sqrt(delta))/(2*a);
	return t;

}

void updateMoveTable(uint32_t address)
{

	parserAssign *data=(parserAssign*)address;
	uint16_t prevIndex=acceControl.index;
	acceControl.index=getIndex(acceControl.index, +1, MOVE_TABLE_SIZE);
	memset(&acceControl.movTable[acceControl.index],0x0,sizeof(acceControl.movTable[acceControl.index]));
	parserAssign *prevData=(parserAssign*)acceControl.movTable[prevIndex].add;


	acceControl.movTable[acceControl.index].add=address;


	if(*(uint32_t*)(((uint32_t)&data->f))==0xffffffff)
	{
		data->f=acceControl.traceFeed;
		acceControl.movTable[acceControl.index].feed=acceControl.traceFeed;
	}
	else
	{
		acceControl.traceFeed=data->f;
		acceControl.movTable[acceControl.index].feed=data->f;
	}




	{// update steps

		positionXYZE* newPos=(positionXYZE*)(address);
		stepPosXYZE  newStepPos;
		parserAssign *movData=(parserAssign*)address;


		newStepPos=acceControl.stepPos;



		if(*(uint32_t*)(uint32_t)&newPos->X==0xffffffff)newPos->X=acceControl.pos.X;
		if(*(uint32_t*)(uint32_t)&newPos->Y==0xffffffff)newPos->Y=acceControl.pos.Y;
		if(*(uint32_t*)(uint32_t)&newPos->Z==0xffffffff)newPos->Z=acceControl.pos.Z;
		if(*(uint32_t*)(uint32_t)&newPos->E==0xffffffff)newPos->E=acceControl.pos.E;

		acceControl.pos.X=newPos->X;
		acceControl.pos.Y=newPos->Y;
		acceControl.pos.Z=newPos->Z;
		acceControl.pos.E=newPos->E;

		float x=newPos->X;
		float y=newPos->Y;
		float z=newPos->Z;
		float e=newPos->E;

		newStepPos.stepX=mmToStepX(x);
		newStepPos.stepY=mmToStepY(y);
		newStepPos.stepZ=mmToStepZ(z);
		newStepPos.stepE=mmToStepE(e);


		float subStepX=newStepPos.stepX-acceControl.stepPos.stepX;
		float subStepY=newStepPos.stepY-acceControl.stepPos.stepY;
		float subStepZ=newStepPos.stepZ-acceControl.stepPos.stepZ;
		float subStepE=newStepPos.stepE-acceControl.stepPos.stepE;

		acceControl.stepPos.stepX=newStepPos.stepX;
		acceControl.stepPos.stepY=newStepPos.stepY;
		acceControl.stepPos.stepZ=newStepPos.stepZ;
		acceControl.stepPos.stepE=newStepPos.stepE;


		if(subStepX>=0)movData->dirX=1;
		else
		{
			movData->dirX=0;
			subStepX=subStepX*(-1);
		}
		if(subStepY>=0)movData->dirY=1;
		else
		{
			movData->dirY=0;
			subStepY=subStepY*(-1);
		}
		if(subStepZ>=0)movData->dirZ=1;
		else
		{
			movData->dirZ=0;
			subStepZ=subStepZ*(-1);
		}
		if(subStepE>=0)movData->dirE=1;
		else
		{
			movData->dirE=0;
			subStepE=subStepE*(-1);
		}

		movData->stepX=subStepX;
		movData->stepY=subStepY;
		movData->stepZ=subStepZ;
		movData->stepE=subStepE;

		if(subStepZ!=0)
		{
			float feedZ=movData->f;
			if(feedZ!=0)
			{
				if(feedZ>MAXIMUM_START_STOP_FEED_RATE_Z)
				{
					feedZ=MAXIMUM_START_STOP_FEED_RATE_Z;
				}
			}
			else
			{
				feedZ=MAXIMUM_START_STOP_FEED_RATE_Z;
			}
			float Tz=getPulsePeriodZ(feedZ);
			movData->tz=Tz;
		}
		else
		{
			movData->tz=0;
		}


		float x1,x2,y1,y2,e1,e2,subX,subY,subE;

		x2=data->x;
		x1=prevData->x;
		y2=data->y;
		y1=prevData->y;
		e2=data->e;
		e1=prevData->e;
		subX=fabs(x2-x1);
		subY=fabs(y2-y1);
		subE=fabs(e2-e1);
		acceControl.movTable[acceControl.index].angle= arctanFloatInpRad0_90(x1, y1, x2, y2);

		acceControl.movTable[acceControl.index].eSub=subE;
		acceControl.movTable[acceControl.index].xSub=subX;//(data->x-prevData->x);
		acceControl.movTable[acceControl.index].ySub=subY;
		acceControl.movTable[acceControl.index].length=sqrt((acceControl.movTable[acceControl.index].xSub*acceControl.movTable[acceControl.index].xSub)+
				(acceControl.movTable[acceControl.index].ySub*acceControl.movTable[acceControl.index].ySub));


	}




}


uint16_t getIndex(uint16_t currentIndex, int16_t offset, uint16_t fullScale)
{
	uint8_t index=currentIndex;
	if(offset>0)
	{
		if((currentIndex+offset)>=fullScale)
		{
			index=offset-(fullScale-currentIndex);
		}
		else
		{
			index=currentIndex+offset;
		}
	}
	else if(offset<0)
	{
		if(currentIndex<(-offset))
		{
			index=fullScale+currentIndex+offset;
		}
		else
		{
			index=currentIndex+offset;
		}
	}
	return index;
}

float measureCorssFeedRate()
{
	float crossFeed=0;
	uint16_t currentIndex=acceControl.index;
	uint16_t prevIndex=getIndex(acceControl.index, -1, MOVE_TABLE_SIZE);

	float x1=acceControl.movTable[prevIndex].xSub;
	float y1=acceControl.movTable[prevIndex].ySub;
	float x2=acceControl.movTable[currentIndex].xSub;
	float y2=acceControl.movTable[currentIndex].ySub;
	if((x1*x2<0)||(y1*y2<0))
	{
		crossFeed=100;
	}
	else if((x1*y1==0)||(x2*y2==0))
	{
		crossFeed= 100;
	}
	else
	{

		float angle1=atan(y1/x1);
		float angle2=atan(y2/x2);

		float angleSub=(180*(fabs(angle2-angle1)))/PI;

		if(angleSub<1)crossFeed=18000;
		else if(angleSub<2)crossFeed=16000;
		else if(angleSub<3)crossFeed=14000;
		else if(angleSub<4)crossFeed=12000;
		else if(angleSub<5)crossFeed=10000;
		else if(angleSub<6)crossFeed=8000;
		else if(angleSub<7)crossFeed=4000;
		else if(angleSub<8)crossFeed=2000;
		else if(angleSub<9)crossFeed=1000;
		else
		{
			crossFeed=100;
		}
	}
	if(crossFeed>acceControl.movTable[currentIndex].feed)
	{
		crossFeed=acceControl.movTable[currentIndex].feed;
	}
	return crossFeed;
}


void accelerationError(uint16_t erroIndex)
{

	while(1);
}

