/*
 * accelerationControl.c
 *
 *  Created on: 28 Oca 2019
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct acceControl_ acceControl;

void initAccelerationControlUnit()
{
	memset(&acceControl,0x0,sizeof(acceControl));
	deviceControl.accelerationVal=10;
	acceControl.traceFeed=0;
	acceControl.movTable[0].add=(uint32_t)&parser.parameters[PARSER_PARAMETER_SIZE-1].parameter[0];
	for(uint32_t i=0; i<MOVEMENT_TABLE_PARAMETER_SIZE;i++)
	{
		acceControl.movTable[i].length=0;
		acceControl.movTable[i].xSub=0;
		acceControl.movTable[i].ySub=0;
	}
}

void accelerationCorrect()
{
	static int32_t oldParserHead=-1;
	if(oldParserHead==parser.head)return;
	oldParserHead=parser.head;

	uint16_t headerIndex=getIndex(parser.head, -1, PARSER_PARAMETER_SIZE);
	if((parser.parameters[headerIndex].task==G00_RAPID_MOVEMENT)||(parser.parameters[headerIndex].task==G01_LINEAR_INTERPOLATION))
	{
		updateMoveTable((uint32_t)parser.parameters[headerIndex].parameter);
		if((deviceControl.accelerationVal!=0)&&(acceControl.movTable[acceControl.index].length!=0))
		{
			float crossFeed=measureCorssFeedRate();
			forwardMovementAnalayze(crossFeed);
		}
		else
		{
			updateNonAcceleratedParserData(acceControl.index);
		}
	}

	acceControl.acceControlledNofData++;

	// test start
	if(acceControl.acceControlledNofData==51)
	{
		volatile uint8_t y=0;
		y++;
	}

	if(acceControl.acceControlledNofData>=(MOVEMENT_TABLE_PARAMETER_SIZE))
	{
		parser.workableHead=plusIndex(parser.workableHead,PARSER_PARAMETER_SIZE);
		parser.workableTailHeadDiff=plusIndex(parser.workableTailHeadDiff,PARSER_PARAMETER_SIZE);
		if((parser.parameters[parser.workableHead].task==G00_RAPID_MOVEMENT) ||
				(parser.parameters[parser.workableHead].task==G01_LINEAR_INTERPOLATION))
		{
			acceControl.startIndex=plusIndex(acceControl.startIndex,MOVEMENT_TABLE_PARAMETER_SIZE);
		}
	}
}
void updateNonAcceleratedParserData(uint16_t index)
{
	parserAssign* data=(parserAssign*)acceControl.movTable[index].add;
	float assignedF=data->f;

	float xStarF=getFeedXaxis(acceControl.movTable[index].angle,assignedF);
	float yStarF=getFeedYaxis(acceControl.movTable[index].angle,assignedF);

	float t;
	float t1se;
	float stepE=data->stepE;



	data->a1x=0;
	data->p1x=0;
	data->a1y=0;
	data->p1y=0;
	data->f2sx=0;

	data->a2x=0;
	data->p2x=0;
	data->f2sy=0;
	data->a2y=0;
	data->p2y=0;


	if(acceControl.movTable[index].xSub)data->f1sx=xStarF;
	else
	{
		data->f1sx=0;
	}


	if(acceControl.movTable[index].ySub)data->f1sy=yStarF;
	else
	{
		data->f1sy=0;
	}

	if(acceControl.movTable[index].eSub)data->f1se=assignedF;
	else
	{
		data->f1se=0;
	}


	data->a1e=0;
	data->p1e=0;

	data->f2se=0;
	data->a2e=0;
	data->p2e=0;


}
void forwardMovementAnalayze(float crossFeed)
{

	uint16_t index=acceControl.index;
	uint16_t prevIndex=getIndex(acceControl.index, -1, MOVE_TABLE_SIZE);

	float endFeed=acceControl.movTable[prevIndex].endFeed;
	if(endFeed>crossFeed)
	{

		acceControl.movTable[prevIndex].endFeed=crossFeed;
		acceControl.movTable[index].startFeed=crossFeed;
		backwardMovementAnalayze(crossFeed);
	}
	else
	{


		if(acceControl.movTable[prevIndex].endFeed==0)
		{//başlangıç feedrate 0 olamaz sonsuza kadar beklememeli
			acceControl.movTable[index].startFeed=100;
			acceControl.movTable[prevIndex].endFeed=100;
		}
		else
		{
			acceControl.movTable[index].startFeed=acceControl.movTable[prevIndex].endFeed;
		}

	}

	forwardMovementAccelerateAnalayze();
}


void forwardMovementAccelerateAnalayze()
{

	uint16_t index=acceControl.index;
	parserAssign *data=(parserAssign*)acceControl.movTable[index].add;

	float a1,a2,p1;

	float startF		=acceControl.movTable[index].startFeed;
	float assignedF		=data->f;
	float startV		=startF/60;
	float assignedV		=assignedF/60;
	float l				=acceControl.movTable[index].length;

	float a				=(deviceControl.accelerationVal)/2;
	float b				=startV;
	float c				=-l;
	float t				=equationSolverGetRoot(a,b,c);

	float acelerateTime	=t;

	if(startV==assignedV)
	{
		a1=0;
		a2=0;
		acceControl.movTable[index].endFeed=assignedF;
	}
	else if((startV+(t*deviceControl.accelerationVal))>=assignedV)
	{// model 1
		acelerateTime=(assignedV-startV)/deviceControl.accelerationVal;
		a1=deviceControl.accelerationVal;
		p1=((acelerateTime*acelerateTime*deviceControl.accelerationVal)/2)+(acelerateTime*startV) ;
		a2=0;
		acceControl.movTable[index].endFeed=assignedF;
	}
	else
	{ // model 2
		a1=deviceControl.accelerationVal;
		p1=l;
		a2=0;
		acceControl.movTable[index].endFeed=(startV+(acelerateTime*deviceControl.accelerationVal))*60;
	}
	updateParsedData(a1, a2, p1, 0,index );
}

float accMoveTimeX(float startFeed,float t,float angle,float a,float p)
{
	float startF,startT,endT,pStep,endF,ta,time;
	startF						=(startFeed)*cos(angle);
	endF						=startF+((a*t)*cos(angle)*60);
	startT						=getPulsePeriodTx(startF);
	endT						=getPulsePeriodTx(endF);
	pStep						=mmToStepX(fabs(p*cos(angle)));
	ta=(startT-endT)/pStep;

	time=0;
	for(uint32_t i=0;i<pStep;i++)
	{
		time+=startT;
		startT-=ta;
	}
	return time;
}

float accMoveTimeY(float startFeed,float t,float angle,float a,float p)
{
	float startF,startT,endT,pStep,endF,ta,time;;
	startF						=(startFeed)*sin(angle);
	endF						=startF+((a*t)*sin(angle)*60);
	startT						=getPulsePeriodTy(startF);
	endT						=getPulsePeriodTy(endF);
	pStep						=mmToStepY(fabs(p*sin(angle)));

	ta=(startT-endT)/pStep;

	time=0;
	for(uint32_t i=0;i<pStep;i++)
	{
		time+=startT;
		startT-=ta;
	}
	return time;
}
void updateParsedData(float a1, float a2, float p1, float p2, int16_t index )
{
	float startFeed=acceControl.movTable[index].startFeed;
	float endFeed=acceControl.movTable[index].endFeed;
	float angle=acceControl.movTable[index].angle;
	float length=acceControl.movTable[index].length;
	float eDivRate=0;
	parserAssign *parserData=(parserAssign*)acceControl.movTable[index].add;

	float xSub=fabs(acceControl.movTable[index].xSub);
	float ySub=fabs(acceControl.movTable[index].ySub);
	float eSub=fabs(acceControl.movTable[index].eSub);
	if(eSub)eDivRate=length/eSub;


	if(a1)
	{
		float a=a1/2;
		float b=startFeed/60; //vstart
		float c=-p1;
		float t=equationSolverGetRoot(a,b,c);
		float startF,p1Feed,startT1,endT1,pStep,t1ax,t1ay,stepTime,pStepSub,startT1R,stepTimeX,stepTimeY;

		stepTimeX=accMoveTimeX(startFeed,t,angle,a1, p1);;
		stepTimeY=accMoveTimeY(startFeed,t,angle,a1, p1);

		if(stepTimeX<stepTimeY)
		{
			stepTime=stepTimeX;

		}
		else
		{
			stepTime=stepTimeY;

		}

		stepTimeX=accMoveTimeX(startFeed,t,angle,a1, p1);
		stepTimeY=accMoveTimeY(startFeed,t,angle,a1, p1);

		if(xSub)
		{
			startF						=getFeedXaxis(angle,startFeed);
			p1Feed						=startF+((a1*t)*cos(angle)*60);
			startT1						=getPulsePeriodTx(startF);
			endT1						=getPulsePeriodTx(p1Feed);
			pStepSub					=mmToStepX(fabs(p1*cos(angle)));
			pStep						=pStepSub;
			t1ax						=(startT1-endT1)/pStepSub;
			startT1R					=startT1;//-((stepTimeX-stepTime)/pStepSub);

			parserData->p1x				=pStep;
			parserData->a1x				=a1*cos(angle);
			parserData->f1sx			=startF;

			if(startF<0)
			{
				volatile uint8_t x=0;
				x++;

			}
		}
		else
		{
			parserData->p1x				=0;
			parserData->a1x				=0;
			parserData->f1sx			=0;

		}


		if(ySub)
		{
			startF						=getFeedYaxis(angle,startFeed);
			p1Feed						=startF+((a1*t)*sin(angle)*60);
			startT1						=getPulsePeriodTy(startF);
			endT1						=getPulsePeriodTy(p1Feed);
			pStepSub					=mmToStepY(fabs(p1*sin(angle)));
			pStep						=pStepSub;
			t1ay						=(startT1-endT1)/pStepSub;
			startT1R					=startT1;//-((stepTimeY-stepTime)/pStepSub);

			parserData->p1y				=pStep;
			parserData->a1y				=a1*sin(angle);
			parserData->f1sy			=startF;
		}
		else
		{
			parserData->p1y				=0;
			parserData->a1y				=0;
			parserData->f1sy			=0;
		}

		if(eSub)
		{
			float p1E					=(p1/length)*eSub;
			float a1e					=a1/eDivRate;
			startF						=startFeed/eDivRate;
			p1Feed						=startF+(a1e*t*60);
			startT1						=getPulsePeriodTe(startF);
			endT1						=getPulsePeriodTe(p1Feed);
			pStepSub					=mmToStepE(p1E);
			pStep						=pStepSub-1;

			float f1se					=startF;

			parserData->p1e				=pStep;
			parserData->a1e				=a1e;
			parserData->f1se			=f1se;
		}
		else
		{
			parserData->p1e				=0;
			parserData->a1e				=0;
			parserData->f1se			=0;
		}
	}
	else
	{
		float f1sx						=getFeedXaxis(angle,startFeed);

		parserData->a1x				=0;
		parserData->p1x				=0;
		parserData->f1sx			=f1sx;




		float f1sy					=getFeedYaxis(angle,startFeed);
		parserData->a1y				=0;
		parserData->p1y				=0;
		parserData->f1sy			=f1sy;

		float f1se					=startFeed/eDivRate;
		parserData->p1e				=0;
		parserData->a1e				=0;
		parserData->f1se			=f1se;

	}

	if(a2)
	{
		float a=a2/2;
		float b=endFeed/60; //vstart
		float c=-(length-p2);
		float t=equationSolverGetRoot(a,b,c);

		float endF,p2Feed,endT2,startT2,pStepSub,pStep,t2ax,t2ay,stepTime,stepTimeX,stepTimeY,startT2R;

		if(xSub>ySub)
		{
			stepTime=accMoveTimeX(endFeed,t,angle,a2, (length-p2));
			stepTimeX=accMoveTimeX(endFeed,t,angle,a2, (length-p2));
		}
		else
		{
			stepTime=accMoveTimeY(endFeed,t,angle,a2, (length-p2));
			stepTimeY=accMoveTimeY(endFeed,t,angle,a2, (length-p2));
		}


		if(xSub)
		{
			endF						=getFeedXaxis(angle,endFeed);
			p2Feed						=endF+((a2*t)*cos(angle)*60);
			endT2						=getPulsePeriodTx(endF);
			startT2						=getPulsePeriodTx(p2Feed);
			pStepSub					=mmToStepX((length-p2)*cos(angle));
			pStep						=mmToStepX(fabs(p2*cos(angle)))+1;
			t2ax						=(endT2-startT2)/pStepSub;
			startT2R					=startT2;//-((stepTimeX-stepTime)/pStepSub);

			parserData->p2x				=pStep;
			parserData->a2x				=a2*cos(angle);
			parserData->f2sx			=p2Feed;
		}
		else
		{
			parserData->p2x				=0;
			parserData->a2x				=0;
			parserData->f2sx			=0;
		}

		if(ySub)
		{
			endF						=getFeedYaxis(angle,endFeed);
			p2Feed						=endF+((a2*t)*sin(angle)*60);
			endT2						=getPulsePeriodTy(endF);
			startT2						=getPulsePeriodTy(p2Feed);
			pStepSub					=mmToStepY((length-p2)*sin(angle));
			pStep						=mmToStepY(fabs(p2*sin(angle)))+1;
			t2ay						=(endT2-startT2)/pStepSub;
			startT2R					=startT2;//-((stepTimeY-stepTime)/pStepSub);
			float a2y					=a2*sin(angle);

			parserData->p2y				=pStep;
			parserData->a2y				=a2y;
			parserData->f2sy			=p2Feed;
		}
		else
		{
			parserData->p2y				=0;
			parserData->a2y				=0;
			parserData->f2sy			=0;
		}


		if(eSub)
		{
			float p2E					=(p2/length)*eSub;
			float a2e					=a2/eDivRate;
			endF						=endFeed/eDivRate;
			p2Feed						=endF+(a2e*t*60);
			endT2						=getPulsePeriodTe(endF);
			startT2						=getPulsePeriodTe(p2Feed);
			pStep						=mmToStepE(p2E);
			pStepSub					=mmToStepE(((length-p2)/length)*eSub)+1;
			float t2ae					=(((endT2*pStepSub)-stepTime)*2)/((pStepSub-1)*pStepSub);
			//			float t2ae					=(endT2-startT2)/pStepSub;
			float f2se					=p2Feed;

			parserData->p2e				=pStep;
			parserData->a2e				=a2e;
			parserData->f2se			=f2se;


		}
		else
		{
			parserData->p2e				=0;
			parserData->a2e				=0;
			parserData->f2se			=0;
		}



	}
	else
	{
		parserData->a2x				=0;
		parserData->p2x				=0;
		parserData->f2sx			=0;

		parserData->a2y				=0;
		parserData->p2y				=0;
		parserData->f2sy			=0;

		parserData->p2e				=0;
		parserData->a2e				=0;
		parserData->f2se			=0;
	}

}
void backwardMovementAnalayze()
{
	backwardAccelerationAnalayze();
}

void backwardAccelerationAnalayze()
{
	uint16_t prevIndex;
	uint16_t index=acceControl.index;
	acceChar acceData;

	float a1,a2,p1,p2;

	while(acceControl.startIndex!=prevIndex)
	{

		prevIndex=getIndex(index, -1, MOVE_TABLE_SIZE);

		acceControl.movTable[prevIndex].endFeed=acceControl.movTable[index].startFeed;
		float length=acceControl.movTable[prevIndex].length;
		float accelerate=deviceControl.accelerationVal;

		acceData=getAccelerationCharacterisitics(acceControl.movTable[prevIndex].startFeed,
				acceControl.movTable[prevIndex].endFeed,
				acceControl.movTable[prevIndex].feed, length, accelerate);

		if(acceControl.movTable[prevIndex].startFeed!=acceData.startFeed)
		{//negative continue backward
			acceControl.movTable[prevIndex].startFeed=acceData.startFeed;

			a1=acceData.a1;
			p1=acceData.p1;
			a2=acceData.a2;
			p2=acceData.p2;
			updateParsedData(a1, a2, p1, p2,prevIndex );
		}
		else
		{//ok update parameters end finish
			a1=acceData.a1;
			p1=acceData.p1;
			a2=acceData.a2;
			p2=acceData.p2;
			updateParsedData(a1, a2, p1, p2,prevIndex);
			return;
		}

		index=getIndex(index, -1, MOVE_TABLE_SIZE);
	}
}

acceChar getAccelerationCharacterisitics(float startFeed, float endFeed, float assignedFeed, float length,float acceleration)
{
	acceChar chrst;
	float startV=startFeed/60;
	float endV=endFeed/60;
	float assignedV=assignedFeed/60;
	float t,t1,t2;
	t=(startV-endV)/acceleration;
	float l1=(endV*t) + ((acceleration*t*t)/2);

	if(l1<length)
	{//decide model 1-2-3-4-5 positive

		if((startFeed>(assignedFeed-5)) && (startFeed<(assignedFeed+5)))
		{//decide model 4-5
			t=((assignedV-endV)/acceleration);
			l1=(endV*t) + ((acceleration*t*t)/2);

			if(l1<length)
			{ //model5
				t2 =(assignedV-endV)/acceleration;
				chrst.p2=length-(((acceleration*t2*t2)/2) + (endV*t2));
				chrst.a2=acceleration;
				chrst.a1=0;
			}
			else
			{//model4
				chrst.p2=0;
				chrst.a2=acceleration;
				chrst.a1=0;

			}


		}
		else
		{//model 1-2-3
			t1=((assignedV-startV)/acceleration);
			t2=((assignedV-endV)/acceleration);
			l1=(startV*t1)+((acceleration*t1*t1)/2)+(endV*t2)+((acceleration*t2*t2)/2);

			if((l1>(length-0.1))&&(l1<(length+0.1)))
			{//model2
				chrst.p1=(startV*t1)+((acceleration*t1*t1)/2);
				chrst.a1=acceleration;
				chrst.p2=chrst.p1;
				chrst.a2=acceleration;

			}
			else if(length>l1)
			{//model3

				chrst.p1=(startV*t1)+((acceleration*t1*t1)/2);
				chrst.a1=acceleration;
				chrst.p2=length-((((acceleration*t2*t2)/2)+(endV*t2)));
				chrst.a2=acceleration;
			}
			else
			{ //model1

				float a=acceleration;
				float b=2*endV;
				float c=(((endV*endV)-(startV*startV))/(2*acceleration))-length;

				t2=equationSolverGetRoot(a,b,c);
				t1=((endV-startV)/(acceleration))+t2;

				chrst.p1=(startV*t1)+((acceleration*t1*t1)/2);
				chrst.a1=acceleration;
				chrst.p2=chrst.p1;
				chrst.a2=acceleration;

			}
		}
		chrst.startFeed=startFeed;

	}
	else
	{// model 6 na

		float a=(acceleration/2);
		float b=(endV);
		float c=-length;
		t2=equationSolverGetRoot(a,b,c);
		chrst.startFeed=(endV+(acceleration*t2))*60;
		chrst.a2=acceleration;
		chrst.a1=0;
		chrst.p1=0;
		chrst.p2=0;
	}

	return chrst;
}

float equationSolverGetRoot(float a, float b, float c)
{
	float delta=b*b-4*a*c;
	float root=(-b+sqrt(delta))/(2*a);
	return root;

}
float getStartFeed(float endFeed, float acceleration, float assginedFeed, float length)
{
	float startFeed;
	float accelelrationTime=(endFeed-assginedFeed)/acceleration;
	float accelerationLength=(acceleration*accelelrationTime*accelelrationTime)/2;
	if(accelerationLength>length)
	{

		accelelrationTime=sqrt((2*length)/acceleration);
		startFeed=(accelelrationTime*acceleration)+endFeed;
	}
	else
	{

		startFeed=assginedFeed;
	}
	return startFeed;

}



float getMovementTimeLength(float startSpeed, float length, float acceleration )
{
	float a=acceleration/2;
	float b=startSpeed;
	float c=length;
	float delta=(b*b-(4*a*c));
	float t=(-b+sqrt(delta))/(2*a);
	return t;

}

void updateMoveTable(uint32_t address)
{

	parserAssign *data=(parserAssign*)address;
	uint16_t prevIndex=acceControl.index;
	acceControl.index=getIndex(acceControl.index, +1, MOVE_TABLE_SIZE);
	memset(&acceControl.movTable[acceControl.index],0x0,sizeof(acceControl.movTable[acceControl.index]));
	parserAssign *prevData=(parserAssign*)acceControl.movTable[prevIndex].add;
	acceControl.movTable[acceControl.index].add=address;


	if(*(uint32_t*)(((uint32_t)&data->f))==0xffffffff)
	{
		data->f=acceControl.traceFeed;
		acceControl.movTable[acceControl.index].feed=acceControl.traceFeed;
	}
	else
	{
		acceControl.traceFeed=data->f;
		acceControl.movTable[acceControl.index].feed=data->f;
	}

	{// update steps

		positionXYZE* newMmPosPntr=(positionXYZE*)(address);
		stepPosXYZE  newStepPos;
		parserAssign *movData=(parserAssign*)address;
		float x1,x2,y1,y2,e1,e2,subX,subY,subE,subStepX,subStepY,subStepZ,subStepE;

		if(*(uint32_t*)(uint32_t)&newMmPosPntr->X==0xffffffff)newMmPosPntr->X=deviceControl.mmPosition.X;
		if(*(uint32_t*)(uint32_t)&newMmPosPntr->Y==0xffffffff)newMmPosPntr->Y=deviceControl.mmPosition.Y;
		if(*(uint32_t*)(uint32_t)&newMmPosPntr->Z==0xffffffff)newMmPosPntr->Z=deviceControl.mmPosition.Z;
		if(*(uint32_t*)(uint32_t)&newMmPosPntr->E==0xffffffff)newMmPosPntr->E=deviceControl.mmPosition.E;
		x2=newMmPosPntr->X;
		x1=deviceControl.mmPosition.X;
		y2=newMmPosPntr->Y;
		y1=deviceControl.mmPosition.Y;
		e2=newMmPosPntr->E;
		e1=deviceControl.mmPosition.E;
		subX=x2-x1;
		subY=y2-y1;
		subE=e2-e1;
		deviceControl.mmPosition.X=newMmPosPntr->X;
		deviceControl.mmPosition.Y=newMmPosPntr->Y;
		deviceControl.mmPosition.Z=newMmPosPntr->Z;
		deviceControl.mmPosition.E=newMmPosPntr->E;
		float x=newMmPosPntr->X;
		float y=newMmPosPntr->Y;
		float z=newMmPosPntr->Z;
		float e=newMmPosPntr->E;
		newStepPos.stepX=mmToStepX(x);
		newStepPos.stepY=mmToStepY(y);
		newStepPos.stepZ=mmToStepZ(z);
		newStepPos.stepE=mmToStepE(e);
		subStepX=newStepPos.stepX-deviceControl.stepPosition.stepX;
		subStepY=newStepPos.stepY-deviceControl.stepPosition.stepY;
		subStepZ=newStepPos.stepZ-deviceControl.stepPosition.stepZ;
		subStepE=newStepPos.stepE-deviceControl.stepPosition.stepE;
		deviceControl.stepPosition.stepX=newStepPos.stepX;
		deviceControl.stepPosition.stepY=newStepPos.stepY;
		deviceControl.stepPosition.stepZ=newStepPos.stepZ;
		deviceControl.stepPosition.stepE=newStepPos.stepE;
		if(subStepX>=0)movData->dirX=1;
		else
		{
			movData->dirX=0;
			subStepX=subStepX*(-1);
		}
		if(subStepY>=0)movData->dirY=1;
		else
		{
			movData->dirY=0;
			subStepY=subStepY*(-1);
		}
		if(subStepZ>=0)movData->dirZ=1;
		else
		{
			movData->dirZ=0;
			subStepZ=subStepZ*(-1);
		}
		if(subStepE>=0)movData->dirE=1;
		else
		{
			movData->dirE=0;
			subStepE=subStepE*(-1);
		}

		movData->stepX=subStepX;
		movData->stepY=subStepY;
		movData->stepZ=subStepZ;
		movData->stepE=subStepE;

		if(subStepZ!=0)
		{
			float feedZ=movData->f;
			if(feedZ!=0)
			{
				if(feedZ>MAXIMUM_START_STOP_FEED_RATE_Z)
				{
					feedZ=MAXIMUM_START_STOP_FEED_RATE_Z;
				}
			}
			else
			{
				feedZ=MAXIMUM_START_STOP_FEED_RATE_Z;
			}
			movData->fz=feedZ;
		}
		else
		{
			movData->fz=0;
		}
		acceControl.movTable[acceControl.index].angleReal=getAngleFromMmPos(subX, subY);
		acceControl.movTable[acceControl.index].angle= arctanFloatInpRad0_90(x1, y1, x2, y2);
		acceControl.movTable[acceControl.index].eSub=subE;
		acceControl.movTable[acceControl.index].xSub=subX;//(data->x-prevData->x);
		acceControl.movTable[acceControl.index].ySub=subY;
		acceControl.movTable[acceControl.index].length=sqrt((acceControl.movTable[acceControl.index].xSub*acceControl.movTable[acceControl.index].xSub)+
				(acceControl.movTable[acceControl.index].ySub*acceControl.movTable[acceControl.index].ySub));
	}
}




float measureCorssFeedRate()
{
	float crossFeed=0;
	uint16_t currentIndex=acceControl.index;
	uint16_t prevIndex=getIndex(acceControl.index, -1, MOVE_TABLE_SIZE);
	float x1,x2,y1,y2,fx1,fx2,fy1,fy2,angle1,angle2,angleSub;
	angle1=acceControl.movTable[prevIndex].angleReal;
	angle2=acceControl.movTable[currentIndex].angleReal;

	if(((angle1<=(PI/2))&&(angle1>=0)) && ((angle2<=(2*PI))&&(angle2>=(3*(PI/2)))))
	{//4. bölge ise
		angle2=angle2-(2*PI);
	}


	if(((angle2<=(PI/2))&&(angle2>=0)) && ((angle1<=(2*PI))&&(angle1>=(3*(PI/2)))))
	{//4. bölge ise
		angle1=angle1-(2*PI);
	}







//	x1=acceControl.movTable[prevIndex].xSub;
//	y1=acceControl.movTable[prevIndex].ySub;
//	x2=acceControl.movTable[currentIndex].xSub;
//	y2=acceControl.movTable[currentIndex].ySub;

//	angle1=acceControl.movTable[prevIndex].angle;
//	angle2=acceControl.movTable[currentIndex].angle;


//	if((x1*x2<0)||(y1*y2<0))
//	{
//		crossFeed=100;
//	}
//	else if((x1*y1==0)||(x2*y2==0))
//	{
//		crossFeed= 100;
//	}
//	else
//	{

//		if((x1==0) && (y1<0))angle1=-90;
//		else if((x1==0) && (y1>0))angle1=90;
//		{
//			angle1=atan(y1/x1);
//		}
//
//		if((x2==0) && (y2<0))angle2=-90;
//		else if((x2==0) && (y2>0))angle2=90;
//		{
//			angle2=atan(y2/x2);
//		}


		angleSub=(180*(fabs(angle2-angle1)))/PI;

		if(angleSub<1)crossFeed=18000;
		else if(angleSub<2)crossFeed=16000;
		else if(angleSub<3)crossFeed=14000;
		else if(angleSub<4)crossFeed=12000;
		else if(angleSub<5)crossFeed=10000;
		else if(angleSub<6)crossFeed=8000;
		else if(angleSub<7)crossFeed=4000;
		else if(angleSub<8)crossFeed=2000;
		else if(angleSub<9)crossFeed=1000;
		else
		{
			crossFeed=100;
		}
//	}

	if(crossFeed>acceControl.movTable[currentIndex].feed)
	{
		crossFeed=acceControl.movTable[currentIndex].feed;
	}
	return crossFeed;
}


void accelerationError(uint16_t erroIndex)
{

	while(1);
}

float getFeedXaxis(float angle, float feed)
{
	float feedX=cos(angle)*feed;
	if(feedX<0.0001)feedX=0;
	return feedX;
}

float getFeedYaxis(float angle, float feed)
{
	float feedY=sin(angle)*feed;
	if(feedY<0.0001)feedY=0;
	return feedY;
}

