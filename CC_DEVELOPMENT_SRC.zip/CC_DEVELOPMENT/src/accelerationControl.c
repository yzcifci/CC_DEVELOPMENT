/*
 * accelerationControl.c
 *
 *  Created on: 28 Oca 2019
 *      Author: yzcifci
 */

#include "main.h"

struct acceControl_ acceControl;

void initAccelerationControlUnit()
{
	memset(&acceControl,0x0,sizeof(acceControl));
	deviceControl.accelerationVal=60;
	acceControl.traceFeed=0;
	acceControl.movTable[0].add=(uint32_t)&parser.parameters[PARSER_PARAMETER_SIZE-1].parameter[0];
	for(uint32_t i=0; i<MOVEMENT_TABLE_PARAMETER_SIZE;i++)
	{
		acceControl.movTable[i].length=0;
		acceControl.movTable[i].xSub=0;
		acceControl.movTable[i].ySub=0;
	}
}

/*
 * Each Data parsed to parser.parameters[x] is analyzed at this layer. If task is movement task type then it is taken for the movement data analyze
 * acceControl.movTable[y] holds the movement tasks and MOVEMENT_TABLE_PARAMETER_SIZE size movement data task kept and analyzed at this layer.
 * ex:
 * parser.parameters[0].task = G00_RAPID_MOVEMENT				acceControl.movTable[0] = parser.parameters[0].parameter
 * parser.parameters[1].task = G01_LINEAR_INTERPOLATION			acceControl.movTable[1] = parser.parameters[1].parameter
 * parser.parameters[2].task = M109_SET_WAIT_EXTRUDER_TEMP		none
 * parser.parameters[3].task = G01_LINEAR_INTERPOLATION			acceControl.movTable[2] = parser.parameters[3].parameter
 * parser.parameters[4].task = M82_SET_EXTRUDER_ABSOLUTE_MODE	none
 * parser.parameters[5].task = G00_RAPID_MOVEMENT				acceControl.movTable[3] = parser.parameters[5].parameter
 *
 *
 */
void accelerationCorrect()
{
	static int32_t oldParserHead=-1;
	if(oldParserHead==parser.head)return;
	oldParserHead=parser.head;


	if((parser.parameters[parser.head].task==G00_RAPID_MOVEMENT)||(parser.parameters[parser.head].task==G01_LINEAR_INTERPOLATION))
	{
		movementHeadTailIterate();
		updateMoveTable((uint32_t)parser.parameters[parser.head].parameter);
		if((deviceControl.accelerationVal!=0))
		{
			float crossFeed=measureCorssFeedRate();
			forwardMovementAnalayze(crossFeed);
		}
		else
		{
			updateNonAcceleratedParserData(acceControl.head);
		}
	}
}
void updateNonAcceleratedParserData(uint16_t index)
{
	parserAssign* data=(parserAssign*)acceControl.movTable[index].add;
	float assignedF=data->f;
	float xStartF=0;
	float yStartF=0;

	xStartF=getFeedXaxis(acceControl.movTable[index].angle,assignedF);
	yStartF=getFeedYaxis(acceControl.movTable[index].angle,assignedF);
	data->a1x=0;
	data->p1x=0;
	data->a1y=0;
	data->p1y=0;
	data->f2sx=0;
	data->a2x=0;
	data->p2x=0;
	data->f2sy=0;
	data->a2y=0;
	data->p2y=0;

	if(acceControl.movTable[index].subStepX)data->f1sx=xStartF;
	else
	{
		data->f1sx=0;
	}

	if(acceControl.movTable[index].subStepY)data->f1sy=yStartF;
	else
	{
		data->f1sy=0;
	}

	if(acceControl.movTable[index].subStepE)data->f1se=assignedF;
	else
	{
		data->f1se=0;
	}

	data->a1e=0;
	data->p1e=0;
	data->f2se=0;
	data->a2e=0;
	data->p2e=0;
}
void forwardMovementAnalayze(float crossFeed)
{

	uint16_t index=acceControl.head;
	uint16_t prevIndex=getIndex(acceControl.head, -1, MOVE_TABLE_SIZE);

	float endFeed=acceControl.movTable[prevIndex].endFeed;
	if(endFeed>crossFeed)
	{
		acceControl.movTable[prevIndex].endFeed=crossFeed;
		acceControl.movTable[index].startFeed=crossFeed;
		backwardAccelerationAnalayze();
	}
	else
	{
		if(acceControl.movTable[prevIndex].endFeed==0)
		{//başlangıç feedrate 0 olamaz sonsuza kadar beklememeli
			acceControl.movTable[index].startFeed=MIN_START_FEED;
			acceControl.movTable[prevIndex].endFeed=MIN_START_FEED;
		}
		else
		{
			acceControl.movTable[index].startFeed=acceControl.movTable[prevIndex].endFeed;
		}

	}

	if(acceControl.movTable[acceControl.head].moveXYexists==0)updateNonAcceleratedParserData(index);
	else
	{
		forwardMovementAccelerateAnalayze();
	}

}


void forwardMovementAccelerateAnalayze()
{

	uint16_t index=acceControl.head;
	parserAssign *data=(parserAssign*)acceControl.movTable[index].add;

	float a1=0;
	float a2=0;
	float p1=0;

	float startF		=acceControl.movTable[index].startFeed;
	float assignedF		=data->f;
	float startV		=startF/60;
	float assignedV		=assignedF/60;
	float l				=acceControl.movTable[index].length;

	float a				=(acceControl.movTable[index].accelerationVal)/2;
	float b				=startV;
	float c				=-l;
	float t				=equationSolverGetRoot(a,b,c);

	float acelerateTime	=t;

	if(startV==assignedV)
	{
		a1=0;
		a2=0;
		acceControl.movTable[index].endFeed=assignedF;
	}
	else if((startV+(t*acceControl.movTable[index].accelerationVal))>=assignedV)
	{// model 1
		acelerateTime=(assignedV-startV)/acceControl.movTable[index].accelerationVal;
		a1=acceControl.movTable[index].accelerationVal;
		p1=((acelerateTime*acelerateTime*acceControl.movTable[index].accelerationVal)/2)+(acelerateTime*startV) ;
		a2=0;
		acceControl.movTable[index].endFeed=assignedF;
	}
	else
	{ // model 2
		a1=acceControl.movTable[index].accelerationVal;
		p1=l;
		a2=0;
		acceControl.movTable[index].endFeed=(startV+(acelerateTime*acceControl.movTable[index].accelerationVal))*60;
	}
	updateParsedData(a1, a2, p1, 0,index );
}

float accMoveTimeX(float startFeed,float t,float angle,float a,float p)
{
	float startF,startT,endT,pStep,endF,ta,time;
	startF						=(startFeed)*cos(angle);
	endF						=startF+((a*t)*cos(angle)*60);
	startT						=getPulsePeriodTx(startF);
	endT						=getPulsePeriodTx(endF);
	pStep						=mmToStepX(fabs(p*cos(angle)));
	ta=(startT-endT)/pStep;

	time=0;
	for(uint32_t i=0;i<pStep;i++)
	{
		time+=startT;
		startT-=ta;
	}
	return time;
}

float accMoveTimeY(float startFeed,float t,float angle,float a,float p)
{
	float startF,startT,endT,pStep,endF,ta,time;;
	startF						=(startFeed)*sin(angle);
	endF						=startF+((a*t)*sin(angle)*60);
	startT						=getPulsePeriodTy(startF);
	endT						=getPulsePeriodTy(endF);
	pStep						=mmToStepY(fabs(p*sin(angle)));

	ta=(startT-endT)/pStep;

	time=0;
	for(uint32_t i=0;i<pStep;i++)
	{
		time+=startT;
		startT-=ta;
	}
	return time;
}
void updateParsedData(float a1, float a2, float p1, float p2, int16_t index )
{
	float startFeed=acceControl.movTable[index].startFeed;
	float endFeed=acceControl.movTable[index].endFeed;
	float angle=acceControl.movTable[index].angle;
	float length=acceControl.movTable[index].length;
	float eDivRate=0;
	parserAssign *parserData=(parserAssign*)acceControl.movTable[index].add;
	int32_t stepX=parserData->stepX;
	int32_t stepY=parserData->stepY;
	int32_t stepE=parserData->stepE;

	float xSub=fabs(acceControl.movTable[index].xSub);
	float ySub=fabs(acceControl.movTable[index].ySub);
	float eSub=fabs(acceControl.movTable[index].eSub);
	if(eSub)eDivRate=length/eSub;


	if(a1)
	{

		float startF,pStep,pStepSub;


		if(stepX)
		{
			startF						=getFeedXaxis(angle,startFeed);
			pStepSub					=mmToStepX(fabs(p1*cos(angle)));
			pStep						=pStepSub;

			parserData->p1x				=pStep;
			parserData->a1x				=a1*cos(angle);
			parserData->f1sx			=startF;

		}
		else
		{
			parserData->p1x				=0;
			parserData->a1x				=0;
			parserData->f1sx			=0;

		}


		if(stepY)
		{
			startF						=getFeedYaxis(angle,startFeed);
			pStepSub					=mmToStepY(fabs(p1*sin(angle)));
			pStep						=pStepSub;

			parserData->p1y				=pStep;
			parserData->a1y				=a1*sin(angle);
			parserData->f1sy			=startF;
		}
		else
		{
			parserData->p1y				=0;
			parserData->a1y				=0;
			parserData->f1sy			=0;
		}

		if(stepE)
		{
			float p1E					=(p1/length)*eSub;
			float a1e					=a1;
			startF						=startFeed/eDivRate;
			pStepSub					=mmToStepE(p1E);
			pStep						=pStepSub-1;

			float f1se					=startF;

			parserData->p1e				=pStep;
			parserData->a1e				=a1e;
			parserData->f1se			=f1se;
		}
		else
		{
			parserData->p1e				=0;
			parserData->a1e				=0;
			parserData->f1se			=0;
		}
	}
	else
	{
		parserData->a1x				=0;
		parserData->p1x				=0;
		parserData->a1y				=0;
		parserData->p1y				=0;
		parserData->p1e				=0;
		parserData->a1e				=0;
		parserData->f1sx			=0;
		parserData->f1sy			=0;
		parserData->f1se			=0;

		if(stepX)
		{
			float f1sx					=getFeedXaxis(angle,startFeed);
			parserData->f1sx			=f1sx;
		}
		if(stepY)
		{
			float f1sy					=getFeedYaxis(angle,startFeed);
			parserData->f1sy			=f1sy;
		}
		if(stepE)
		{
			float f1se=0;
			if(eDivRate)f1se			=startFeed/eDivRate;
			parserData->f1se			=f1se;
		}

	}

	if(a2)
	{
		float pStep;

		if(stepX)
		{
			pStep						=mmToStepX(fabs(p2*cos(angle)))+1;

			parserData->p2x				=pStep;
			parserData->a2x				=a2*cos(angle);
			parserData->f2sx			=0; //not used at stepper side
		}
		else
		{
			parserData->p2x				=0;
			parserData->a2x				=0;
			parserData->f2sx			=0;
		}

		if(stepY)
		{
			pStep						=mmToStepY(fabs(p2*sin(angle)))+1;
			float a2y					=a2*sin(angle);

			parserData->p2y				=pStep;
			parserData->a2y				=a2y;
			parserData->f2sy			=0; //not used at stepper side
		}
		else
		{
			parserData->p2y				=0;
			parserData->a2y				=0;
			parserData->f2sy			=0;
		}


		if(stepE)
		{
			float p2E					=(p2/length)*eSub;
			float a2e					=a2;
			pStep						=mmToStepE(p2E);

			parserData->p2e				=pStep;
			parserData->a2e				=a2e;
			parserData->f2se			=0; //not used
		}
		else
		{
			parserData->p2e				=0;
			parserData->a2e				=0;
			parserData->f2se			=0;
		}



	}
	else
	{
		parserData->a2x				=0;
		parserData->p2x				=0;
		parserData->f2sx			=0;

		parserData->a2y				=0;
		parserData->p2y				=0;
		parserData->f2sy			=0;

		parserData->p2e				=0;
		parserData->a2e				=0;
		parserData->f2se			=0;
	}

	//error check
	float a1x=parserData->a1x;
	float a1y=parserData->a1y;
	float a1e=parserData->a1e;
	float a2x=parserData->a2x;
	float a2y=parserData->a2y;
	float a2e=parserData->a2e;

	if((a1x>deviceControl.accelerationVal)||
			(a1y>deviceControl.accelerationVal)||
			(a1e>deviceControl.accelerationVal)||
			(a2x>deviceControl.accelerationVal)||
			(a2y>deviceControl.accelerationVal)||
			(a2e>deviceControl.accelerationVal))
	{
		errorLog(ACCELERATION_ANALAYZER_ACCELERATION_EXCEEDING_ERROR);
	}

	float f1sx=parserData->f1sx;
	float f1sy=parserData->f1sy;
	float f1se=parserData->f1se;
	float f2sx=parserData->f2sx;
	float f2sy=parserData->f2sy;
	float f2se=parserData->f2se;

	if((f1sx>MAXIMUM_FEED_RATE)||
			(f1sy>MAXIMUM_FEED_RATE)||
			(f1se>MAXIMUM_FEED_RATE)||
			(f2sx>MAXIMUM_FEED_RATE)||
			(f2sy>MAXIMUM_FEED_RATE)||
			(f2se>MAXIMUM_FEED_RATE))
	{
		errorLog(MOVEMENT_ANALAYZER_FEEDRATE_EXCEEDING_ERROR);
	}

}


void backwardAccelerationAnalayze()
{
	uint16_t prevIndex;
	uint16_t index=acceControl.head;
	acceChar acceData;

	float a1,a2,p1,p2;

	prevIndex=getIndex(index, -1, MOVE_TABLE_SIZE);

	while(acceControl.tail!=prevIndex)
	{

		acceControl.movTable[prevIndex].endFeed=acceControl.movTable[index].startFeed;
		float length=acceControl.movTable[prevIndex].length;
		float accelerate=acceControl.movTable[prevIndex].accelerationVal;

		acceData=getAccelerationCharacterisitics(acceControl.movTable[prevIndex].startFeed,
				acceControl.movTable[prevIndex].endFeed,
				acceControl.movTable[prevIndex].feed, length, accelerate);

		if(acceControl.movTable[prevIndex].startFeed!=acceData.startFeed)
		{//negative continue backward
			acceControl.movTable[prevIndex].startFeed=acceData.startFeed;

			a1=acceData.a1;
			p1=acceData.p1;
			a2=acceData.a2;
			p2=acceData.p2;
			updateParsedData(a1, a2, p1, p2,prevIndex );
		}
		else
		{//ok update parameters end finish
			a1=acceData.a1;
			p1=acceData.p1;
			a2=acceData.a2;
			p2=acceData.p2;
			updateParsedData(a1, a2, p1, p2,prevIndex);
			return;
		}

		index=getIndex(index, -1, MOVE_TABLE_SIZE);
		prevIndex=getIndex(index, -1, MOVE_TABLE_SIZE);
	}
}

acceChar getAccelerationCharacterisitics(float startFeed, float endFeed, float assignedFeed, float length,float acceleration)
{
	acceChar chrst;
	float startV=startFeed/60;
	float endV=endFeed/60;
	float assignedV=assignedFeed/60;
	float t,t1,t2;
	t=(startV-endV)/acceleration;
	float l1=(endV*t) + ((acceleration*t*t)/2);

	if(l1<length)
	{//decide model 1-2-3-4-5 positive

		if((startFeed>(assignedFeed-5)) && (startFeed<(assignedFeed+5)))
		{//decide model 4-5
			t=((assignedV-endV)/acceleration);
			l1=(endV*t) + ((acceleration*t*t)/2);

			if(l1<length)
			{ //model5
				t2 =(assignedV-endV)/acceleration;
				chrst.p2=length-(((acceleration*t2*t2)/2) + (endV*t2));
				chrst.a2=acceleration;
				chrst.a1=0;
			}
			else
			{//model4
				chrst.p2=0;
				chrst.a2=acceleration;
				chrst.a1=0;

			}


		}
		else
		{//model 1-2-3
			t1=((assignedV-startV)/acceleration);
			t2=((assignedV-endV)/acceleration);
			l1=(startV*t1)+((acceleration*t1*t1)/2)+(endV*t2)+((acceleration*t2*t2)/2);

			if((l1>(length-0.01))&&(l1<(length+0.01)))
			{//model2
				chrst.p1=(startV*t1)+((acceleration*t1*t1)/2);
				chrst.a1=acceleration;
				chrst.p2=chrst.p1;
				chrst.a2=acceleration;

			}
			else if(length>l1)
			{//model3

				chrst.p1=(startV*t1)+((acceleration*t1*t1)/2);
				chrst.a1=acceleration;
				chrst.p2=length-((((acceleration*t2*t2)/2)+(endV*t2)));
				chrst.a2=acceleration;
			}
			else
			{ //model1

				float a=acceleration;
				float b=2*endV;
				float c=(((endV*endV)-(startV*startV))/(2*acceleration))-length;

				t2=equationSolverGetRoot(a,b,c);
				t1=((endV-startV)/(acceleration))+t2;

				chrst.p1=(startV*t1)+((acceleration*t1*t1)/2);
				chrst.a1=acceleration;
				chrst.p2=chrst.p1;
				chrst.a2=acceleration;

			}
		}
		chrst.startFeed=startFeed;
	}
	else
	{// model 6 na

		float a=(acceleration/2);
		float b=(endV);
		float c=-length;
		t2=equationSolverGetRoot(a,b,c);
		chrst.startFeed=(endV+(acceleration*t2))*60;
		chrst.a2=acceleration;
		chrst.a1=0;
		chrst.p1=0;
		chrst.p2=0;
	}
	return chrst;
}

float equationSolverGetRoot(float a, float b, float c)
{
	float delta=(b*b)-(4*a*c);
	if(delta<0)errorLog(EQUATION_SOLVER_MINUS_DELTA_ERROR);

	float root1=(-b+sqrt(delta))/(2*a);
	float root2=(-b-sqrt(delta))/(2*a);
	if(root1>0 && root2>0)errorLog(EQUATION_SOLVER_TWO_ROOT_RESULT_ERROR);
	else if(root1>0)return root1;
	else if(root2>0)return root2;
	else
	{
		errorLog(EQUATION_SOLVER_NO_ROOT_FOUND_ERROR);
	}

	return 0;

}
float getStartFeed(float endFeed, float acceleration, float assginedFeed, float length)
{
	float startFeed;
	float accelelrationTime=(endFeed-assginedFeed)/acceleration;
	float accelerationLength=(acceleration*accelelrationTime*accelelrationTime)/2;
	if(accelerationLength>length)
	{

		accelelrationTime=sqrt((2*length)/acceleration);
		startFeed=(accelelrationTime*acceleration)+endFeed;
	}
	else
	{

		startFeed=assginedFeed;
	}
	return startFeed;

}



float getMovementTimeLength(float startSpeed, float length, float acceleration )
{
	float a=acceleration/2;
	float b=startSpeed;
	float c=length;
	float delta=(b*b-(4*a*c));
	float t=(-b+sqrt(delta))/(2*a);
	return t;

}

void updateMoveTable(uint32_t address)
{

	parserAssign *data=(parserAssign*)address;
	memset(&acceControl.movTable[acceControl.head],0x0,sizeof(acceControl.movTable[acceControl.head]));
	acceControl.movTable[acceControl.head].add=address;
	acceControl.movTable[acceControl.head].accelerationVal=deviceControl.accelerationVal;


	if(*(uint32_t*)(((uint32_t)&data->f))==0xffffffff)
	{
		data->f=acceControl.traceFeed;
		acceControl.movTable[acceControl.head].feed=acceControl.traceFeed;
	}
	else
	{
		acceControl.traceFeed=data->f;
		acceControl.movTable[acceControl.head].feed=data->f;
	}

	{// update steps

		positionXYZE* newMmPosPntr=(positionXYZE*)(address);
		stepPosXYZE  newStepPos;
		parserAssign *movData=(parserAssign*)address;
		float x1,x2,y1,y2,e1,e2,subX,subY,subE,angleReal;
		int32_t subStepX,subStepY,subStepZ,subStepE;

		if(*(uint32_t*)(uint32_t)&newMmPosPntr->X==0xffffffff)newMmPosPntr->X=deviceControl.mmPosition.X;
		if(*(uint32_t*)(uint32_t)&newMmPosPntr->Y==0xffffffff)newMmPosPntr->Y=deviceControl.mmPosition.Y;
		if(*(uint32_t*)(uint32_t)&newMmPosPntr->Z==0xffffffff)newMmPosPntr->Z=deviceControl.mmPosition.Z;
		if(*(uint32_t*)(uint32_t)&newMmPosPntr->E==0xffffffff)newMmPosPntr->E=deviceControl.mmPosition.E;
		x2=newMmPosPntr->X;
		x1=deviceControl.mmPosition.X;
		y2=newMmPosPntr->Y;
		y1=deviceControl.mmPosition.Y;
		e2=newMmPosPntr->E;
		e1=deviceControl.mmPosition.E;
		subX=x2-x1;
		subY=y2-y1;
		subE=e2-e1;
		deviceControl.mmPosition.X=newMmPosPntr->X;
		deviceControl.mmPosition.Y=newMmPosPntr->Y;
		deviceControl.mmPosition.Z=newMmPosPntr->Z;
		deviceControl.mmPosition.E=newMmPosPntr->E;
		float x=newMmPosPntr->X;
		float y=newMmPosPntr->Y;
		float z=newMmPosPntr->Z;
		float e=newMmPosPntr->E;
		newStepPos.stepX=mmToStepX(x);
		newStepPos.stepY=mmToStepY(y);
		newStepPos.stepZ=mmToStepZ(z);
		newStepPos.stepE=mmToStepE(e);
		subStepX=newStepPos.stepX-deviceControl.stepPosition.stepX;
		subStepY=newStepPos.stepY-deviceControl.stepPosition.stepY;
		subStepZ=newStepPos.stepZ-deviceControl.stepPosition.stepZ;
		subStepE=newStepPos.stepE-deviceControl.stepPosition.stepE;
		deviceControl.stepPosition.stepX=newStepPos.stepX;
		deviceControl.stepPosition.stepY=newStepPos.stepY;
		deviceControl.stepPosition.stepZ=newStepPos.stepZ;
		deviceControl.stepPosition.stepE=newStepPos.stepE;
		angleReal=getAngleFromStepPos(subStepX, subStepY);
		if(subStepX>=0)movData->dirX=1;
		else
		{
			movData->dirX=0;
			subStepX=subStepX*(-1);
		}
		if(subStepY>=0)movData->dirY=1;
		else
		{
			movData->dirY=0;
			subStepY=subStepY*(-1);
		}
		if(subStepZ>=0)movData->dirZ=1;
		else
		{
			movData->dirZ=0;
			subStepZ=subStepZ*(-1);
		}
		if(subStepE>=0)movData->dirE=1;
		else
		{
			movData->dirE=0;
			subStepE=subStepE*(-1);
		}

		movData->stepX=subStepX;
		movData->stepY=subStepY;
		movData->stepZ=subStepZ;
		movData->stepE=subStepE;

		acceControl.movTable[acceControl.head].subStepX=subStepX;
		acceControl.movTable[acceControl.head].subStepY=subStepY;
		acceControl.movTable[acceControl.head].subStepZ=subStepZ;
		acceControl.movTable[acceControl.head].subStepE=subStepE;

		if((subStepX!=0)||(subStepY!=0))
		{
			acceControl.movTable[acceControl.head].moveXYexists=1;
		}
		else
		{
			acceControl.movTable[acceControl.head].moveXYexists=0;
		}

		if(subStepZ!=0)
		{
			float feedZ=movData->f;
			if(feedZ!=0)
			{
				if(feedZ>MAXIMUM_START_STOP_FEED_RATE_Z)
				{
					feedZ=MAXIMUM_START_STOP_FEED_RATE_Z;
				}
			}
			else
			{
				feedZ=MAXIMUM_START_STOP_FEED_RATE_Z;
			}
			movData->fz=feedZ;
		}
		else
		{
			movData->fz=0;
		}
		acceControl.movTable[acceControl.head].angleReal=angleReal;
		acceControl.movTable[acceControl.head].angle= arctanFloatInpRad0_90(x1, y1, x2, y2);
		acceControl.movTable[acceControl.head].eSub=subE;
		acceControl.movTable[acceControl.head].xSub=subX;//(data->x-prevData->x);
		acceControl.movTable[acceControl.head].ySub=subY;
		acceControl.movTable[acceControl.head].length=sqrt((subStepX*subStepX) + (subStepY*subStepY))*0.01;
	}
}




float measureCorssFeedRate()
{
	float crossFeed=MIN_START_FEED;
	if(acceControl.movTable[acceControl.head].length==0) return crossFeed;
	uint16_t currentIndex=acceControl.head;
	uint16_t prevIndex=getIndex(acceControl.head, -1, MOVE_TABLE_SIZE);
	float angle1,angle2,angleSub;
	angle1=acceControl.movTable[prevIndex].angleReal;
	angle2=acceControl.movTable[currentIndex].angleReal;

	if(((angle1<=(PI/2))&&(angle1>=0)) && ((angle2<=(2*PI))&&(angle2>=(3*(PI/2)))))
	{//4. bölge ise
		angle2=angle2-(2*PI);
	}

	if(((angle2<=(PI/2))&&(angle2>=0)) && ((angle1<=(2*PI))&&(angle1>=(3*(PI/2)))))
	{//4. bölge ise
		angle1=angle1-(2*PI);
	}


	angleSub=(180*(fabs(angle2-angle1)))/PI;

	if(angleSub<1)crossFeed=18000;
	else if(angleSub<2)crossFeed=16000;
	else if(angleSub<3)crossFeed=14000;
	else if(angleSub<4)crossFeed=12000;
	else if(angleSub<5)crossFeed=10000;
	else if(angleSub<6)crossFeed=8000;
	else if(angleSub<7)crossFeed=4000;
	else if(angleSub<8)crossFeed=2000;
	else if(angleSub<9)crossFeed=1000;
	else
	{
		crossFeed=MIN_START_FEED;
	}

	if(crossFeed>acceControl.movTable[currentIndex].feed)
	{
		crossFeed=acceControl.movTable[currentIndex].feed;
	}
	return crossFeed;
}


void accelerationError(uint16_t erroIndex)
{

	while(1);
}

float getFeedXaxis(float angle, float feed)
{
	float feedX=cos(angle)*feed;
	if(feedX<0.0001)feedX=0;
	return feedX;
}

float getFeedYaxis(float angle, float feed)
{
	float feedY=sin(angle)*feed;
	if(feedY<0.0001)feedY=0;
	return feedY;
}

/*
 * acceControl.head indicates the data head index that pushed to buffer.acceControl.tail remains 0 until
 * MOVEMENT_TABLE_PARAMETER_SIZE data parse to the buffer. When buffer filled the acceControl.tail iterates with the head
 * ex: MOVEMENT_TABLE_PARAMETER_SIZE set to 32
 * start:
 * acceControl.head : 0			 acceControl.tail : 0
 * acceControl.head : 1			 acceControl.tail : 0
 * acceControl.head : 2			 acceControl.tail : 0
 * acceControl.head : 3			 acceControl.tail : 0
 * ...
 * acceControl.head : 31	     acceControl.tail : 0
 * acceControl.head : 0	     	 acceControl.tail : 1
 * acceControl.head : 1	     	 acceControl.tail : 2
 * acceControl.head : 2	     	 acceControl.tail : 3
 *
 */
void movementHeadTailIterate()
{
	static uint32_t cntr=0;
	acceControl.head++;
	if(acceControl.head>=MOVEMENT_TABLE_PARAMETER_SIZE)acceControl.head=0;
	if(++cntr>=MOVEMENT_TABLE_PARAMETER_SIZE)
	{
		acceControl.tail++;
		if(acceControl.tail>=MOVEMENT_TABLE_PARAMETER_SIZE)acceControl.tail=0;
	}
}

