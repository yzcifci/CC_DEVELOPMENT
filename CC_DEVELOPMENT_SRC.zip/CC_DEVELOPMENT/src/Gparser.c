/*
 * Gparser.c
 *
 *  Created on: 10 Oca 2018
 *      Author: yzcifci
 */

#include "Gparser.h"
#include "parameters.h"
#include "stdlib.h"
#include "string.h"
#include "stdio.h"

struct Gparser_ Gparser;

void initializeParser()
{
	memset(&Gparser, 0x0, sizeof(Gparser));
}

uint8_t mainParser(uint8_t *Gline)
{
	Gparser.lineController.wordCount=0;
	prepareParserLine(Gline);
	while(Gparser.lineController.wordCount<Gparser.lineController.wordCounter)
	{
		taskParameterParser((char*)&Gparser.lineController.subLineData[Gparser.lineController.wordCount][0]);
		Gparser.lineController.wordCount++;
	}
	Gparser.parserControl.taskParsestatus[Gparser.parserControl.taskIndex]=TASK_PARSE_COMPLETED;
	return BUFFER_NOT_FULL;

}

void prepareParserLine(uint8_t *Gline)
{
	memset(&Gparser.lineController, 0x0, sizeof(Gparser.lineController));
	isTaskLineUsed(Gline);
	lineSplit(Gline);
}

void taskParameterParser(char *taskData)
{
	uint8_t taskParameter;
	uint16_t number=0;
	float point;


	switch(taskData[0])
	{
	case 'N':
	case '\r':
	case '\n':
		lineIndexer(&taskData[1]);
		break;
	case 'G':
		taskParameter=(uint8_t)getTask(taskData);
		taskIndexer(taskParameter);
		break;
	case 'X':
		point=atof(&taskData[1]);
		assignXaxis(point);
		break;
	case 'Y':
		point=atof(&taskData[1]);
		assignYaxis(point);
		break;
	case 'Z':
		point=atof(&taskData[1]);
		assignZaxis(point);
		break;

	case 'E':
		point=atof(&taskData[1]);
		assignExtruder(point);
		break;

	case 'I':
		assignCircularInterPolationParameterType(taskData[0]);
		point=atof(&taskData[1]);
		assignIparameter(point);
		break;
	case 'J':
		assignCircularInterPolationParameterType(taskData[0]);
		point=atof(&taskData[1]);
		assignJparameter(point);
		break;
	case 'F':
		point=atof(&taskData[1]);
		assignFeedRateParameter(point);
		break;
	case 'S':
		point=atof(&taskData[1]);
		setSparameter(point);
		break;
	case 'M':
		taskParameter=(uint8_t)getTask(taskData);
		taskIndexer(taskParameter);
		break;
	case 'R':
		assignCircularInterPolationParameterType(taskData[0]);
		point=atof(&taskData[1]);
		assignRadiusParameter(point);
		break;
	case 'T':
		taskParameter=(uint8_t)getTask(taskData);
		taskIndexer(taskParameter);
		number=atoi(&taskData[1]);
		setToolParameter((uint8_t)number);
		break;
	}
}

void lineIndexer(char *data)
{
	uint16_t number;
	switch (Gparser.lineController.lineNumberUsed)
	{
	case LINE_NUMBER_ACTIVE:
		number=atoi(&data[1]);
		Gparser.lineNumber[++Gparser.indexer.lineNumber]=number;
		break;

	case LINE_NUMBER_INACTIVE:
		number=Gparser.indexer.lineNumber+1;
		Gparser.lineNumber[++Gparser.indexer.lineNumber]=number;
		break;
	default:
		break;
	}
}
void modalTaskPostParser(char taskParameter, char task, uint16_t number)
{
	switch(taskParameter)
	{
	case G00_RAPID_MOVEMENT:
	case G01_LINEAR_INTERPOLATION:
	case G02_CIRCULAR_CW_INTERPOLATION:
	case G03_CIRCULAR_CCW_INTERPOLATION:
		Gparser.modalTaskControl.task=taskParameter;
		break;
	}
	switch(task)
	{
	case 'X':
		Gparser.modalTaskControl.X=number;
		break;
	case 'Y':
		Gparser.modalTaskControl.Y=number;
		break;
	case 'Z':
		Gparser.modalTaskControl.Z=number;
		break;
	case 'I':
		Gparser.modalTaskControl.I=number;
		break;
	case 'J':
		Gparser.modalTaskControl.J=number;
		break;
	case 'R':
		Gparser.modalTaskControl.R=number;
		break;
	case 'F':
		Gparser.modalTaskControl.F=number;
		break;

	}

}
void modalTaskPreParser(char character)
{
	if(Gparser.modalTaskControl.lineNumber!=Gparser.lineNumber[Gparser.indexer.lineNumber])
	{
		switch(character)
		{
		case 'X':
		case 'Y':
		case 'Z':
		case 'I':
		case 'J':
		case 'R':
		case 'F':
		{
			taskIndexer(Gparser.modalTaskControl.task);
			switch(Gparser.modalTaskControl.task)
			{
			case G00_RAPID_MOVEMENT:
				Gparser.G00_RAPID_MOVEMENT[Gparser.indexer.G00_RAPID_MOVEMENT].X=Gparser.modalTaskControl.X;
				Gparser.G00_RAPID_MOVEMENT[Gparser.indexer.G00_RAPID_MOVEMENT].Y=Gparser.modalTaskControl.Y;
				Gparser.G00_RAPID_MOVEMENT[Gparser.indexer.G00_RAPID_MOVEMENT].Z=Gparser.modalTaskControl.Z;
				break;
			case G01_LINEAR_INTERPOLATION:
				Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].X=Gparser.modalTaskControl.X;
				Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].Y=Gparser.modalTaskControl.Y;
				Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].Z=Gparser.modalTaskControl.Z;
				Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].feedRate=Gparser.modalTaskControl.F;
				break;
			case G02_CIRCULAR_CW_INTERPOLATION:
			case G03_CIRCULAR_CCW_INTERPOLATION:
				Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].X=Gparser.modalTaskControl.X;
				Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].Y=Gparser.modalTaskControl.Y;
				Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].I=Gparser.modalTaskControl.I;
				Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].J=Gparser.modalTaskControl.J;
				Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].radius=Gparser.modalTaskControl.R;
				Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].feedRate=Gparser.modalTaskControl.F;
				break;
			}
			Gparser.modalTaskControl.lineNumber=Gparser.lineNumber[Gparser.indexer.lineNumber];
		}
		break;
		}



	}
}

/*
 * S parametresi 3d printer i�in M fonksiyonlar� ile birlikte kullan�ld��� i�in
 * setSparameter fonksiyonu ile set edilmi�tir.
 */
void setSpeed(float speed)
{
	Gparser.SPEED[Gparser.indexer.SPEED]=SPEED;
}

void setSparameter(uint16_t value)
{
	switch(Gparser.parserControl.activeMovementTask)
	{
	case M190_SET_WAIT_BED_TEMP:
		Gparser.M190_SET_WAIT_BED_TEMP[Gparser.indexer.M190_SET_WAIT_BED_TEMP]=value;
		break;
	case M104_SET_EXTRUDER_TEMP:
		Gparser.M104_SET_EXTRUDER_TEMP[Gparser.indexer.M104_SET_EXTRUDER_TEMP]=value;
		break;
	case M109_SET_WAIT_EXTRUDER_TEMP:
		Gparser.M109_SET_WAIT_EXTRUDER_TEMP[Gparser.indexer.M109_SET_WAIT_EXTRUDER_TEMP]=value;
		break;

	case M107_FAN_OFF:
		Gparser.M107_FAN_OFF[Gparser.indexer.M107_FAN_OFF]=value;
		break;







	}
}
void setToolParameter(uint8_t tool)
{
	Gparser.TOOL=tool;
}


void assignXaxis(float val)
{

	getPrePositionParameters(COORDINATE_X, val);
	switch(Gparser.parserControl.activeMovementTask)
	{
	case G00_RAPID_MOVEMENT:
		Gparser.G00_RAPID_MOVEMENT[Gparser.indexer.G00_RAPID_MOVEMENT].X=Gparser.parserControl.position.mmPosition.X;
		break;
	case G01_LINEAR_INTERPOLATION:
		Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].X=Gparser.parserControl.position.mmPosition.X;
		break;
	case G02_CIRCULAR_CW_INTERPOLATION:
		Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].X=
				Gparser.parserControl.position.mmPosition.X;
		break;
	case G03_CIRCULAR_CCW_INTERPOLATION:
		Gparser.G03_CIRCULAR_CCW_INTERPOLATION[Gparser.indexer.G03_CIRCULAR_CCW_INTERPOLATION].X=
				Gparser.parserControl.position.mmPosition.X;
		break;

	case G28_MOVE_TO_ORIGIN:
		Gparser.G28_MOVE_TO_ORIGIN[Gparser.indexer.G28_MOVE_TO_ORIGIN].X=
				Gparser.parserControl.position.mmPosition.X;
		break;

	case G92_SET_POSITION:
		Gparser.G92_SET_POSITION[Gparser.indexer.G92_SET_POSITION].X=
				Gparser.parserControl.position.mmPosition.X;
		break;



	}
}



void assignYaxis(float val)
{
	getPrePositionParameters(COORDINATE_Y, val);
	switch(Gparser.parserControl.activeMovementTask)
	{
	case G00_RAPID_MOVEMENT:
		Gparser.G00_RAPID_MOVEMENT[Gparser.indexer.G00_RAPID_MOVEMENT].Y=Gparser.parserControl.position.mmPosition.Y;
		break;
	case G01_LINEAR_INTERPOLATION:
		Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].Y=
				Gparser.parserControl.position.mmPosition.Y;
		break;
	case G02_CIRCULAR_CW_INTERPOLATION:
		Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].Y=
				Gparser.parserControl.position.mmPosition.Y;
		break;
	case G03_CIRCULAR_CCW_INTERPOLATION:
		Gparser.G03_CIRCULAR_CCW_INTERPOLATION[Gparser.indexer.G03_CIRCULAR_CCW_INTERPOLATION].Y=
				Gparser.parserControl.position.mmPosition.Y;
		break;

	case G28_MOVE_TO_ORIGIN:
		Gparser.G28_MOVE_TO_ORIGIN[Gparser.indexer.G28_MOVE_TO_ORIGIN].Y=
				Gparser.parserControl.position.mmPosition.Y;
		break;
	case G92_SET_POSITION:
		Gparser.G92_SET_POSITION[Gparser.indexer.G92_SET_POSITION].Y=
				Gparser.parserControl.position.mmPosition.Y;
		break;
	}
}


void assignZaxis(float val)
{
	getPrePositionParameters(COORDINATE_Z, val);
	switch(Gparser.parserControl.activeMovementTask)
	{
	case G00_RAPID_MOVEMENT:
		Gparser.G00_RAPID_MOVEMENT[Gparser.indexer.G00_RAPID_MOVEMENT].Z=Gparser.parserControl.position.mmPosition.Z;
		break;
	case G01_LINEAR_INTERPOLATION:
		Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].Z=Gparser.parserControl.position.mmPosition.Z;
		break;
	case G28_MOVE_TO_ORIGIN:
		Gparser.G28_MOVE_TO_ORIGIN[Gparser.indexer.G28_MOVE_TO_ORIGIN].Z=
				Gparser.parserControl.position.mmPosition.Z;
		break;

	case G92_SET_POSITION:
		Gparser.G92_SET_POSITION[Gparser.indexer.G92_SET_POSITION].Z=
				Gparser.parserControl.position.mmPosition.Z;
		break;
		break;

	}
}

void assignExtruder(float val)
{
	getPrePositionParameters(EXTRUDER, val);
	switch(Gparser.parserControl.activeMovementTask)
	{
	case G00_RAPID_MOVEMENT:
		Gparser.G00_RAPID_MOVEMENT[Gparser.indexer.G00_RAPID_MOVEMENT].E=Gparser.parserControl.position.mmPosition.E;
		break;
	case G01_LINEAR_INTERPOLATION:
		Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].E=Gparser.parserControl.position.mmPosition.E;
		break;

	case G92_SET_POSITION:
		Gparser.G92_SET_POSITION[Gparser.indexer.G92_SET_POSITION].E=
				Gparser.parserControl.position.mmPosition.E;
		break;

	}
}

void getPrePositionParameters(char coordinate, float val)
{
	switch(coordinate)
	{
	case COORDINATE_X:
		if(Gparser.parserControl.lengthMode==INCHES_MODE)val*=INCHES_TO_MM;

		if(Gparser.parserControl.incAbsoluteSelect==INCREMENTAL_MODE)
		{
			Gparser.parserControl.position.mmPosition.X+=val;
			//TODO incremental mode offset control will be added here
		}
		else
		{
			Gparser.parserControl.position.mmPosition.X=val+ZERO_POINT_LENGTH_X;
		}
		break;
	case COORDINATE_Y:
		if(Gparser.parserControl.lengthMode==INCHES_MODE)val*=INCHES_TO_MM;

		if(Gparser.parserControl.incAbsoluteSelect==INCREMENTAL_MODE)
		{
			Gparser.parserControl.position.mmPosition.Y+=val;
		}
		else
		{
			Gparser.parserControl.position.mmPosition.Y=val+ZERO_POINT_LENGTH_Y;
		}
		break;
	case COORDINATE_Z:
		if(Gparser.parserControl.lengthMode==INCHES_MODE)val*=INCHES_TO_MM;

		if(Gparser.parserControl.incAbsoluteSelect==INCREMENTAL_MODE)
		{
			Gparser.parserControl.position.mmPosition.Z+=val;
		}
		else
		{
			Gparser.parserControl.position.mmPosition.Z=val+ZERO_POINT_LENGTH_Z;
		}
		break;

	case EXTRUDER:
		if(Gparser.parserControl.lengthMode==INCHES_MODE)val*=INCHES_TO_MM;

		if(Gparser.parserControl.extruderIncAbsoluteSelect==INCREMENTAL_MODE)
		{
			Gparser.parserControl.position.mmPosition.E+=val;
		}
		else
		{
			Gparser.parserControl.position.mmPosition.E=val+ZERO_POINT_LENGTH_Z;
		}
		break;
	}
}

void assignCircularInterPolationParameterType(char task)
{
	CIRCULAR_INTERPOLATION_PARAMETER_TYPE parameterType;
	switch(task)
	{
	case 'I':
	case 'J':
		parameterType=CIRCULAR_INTERPOLATION_I_J_TYPE;
		break;
	case 'R':
		parameterType=CIRCULAR_INTERPOLATION_R_TYPE;
	}
	switch(Gparser.parserControl.activeMovementTask)
	{
	case G02_CIRCULAR_CW_INTERPOLATION:
		Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].paramaterType=parameterType;
		break;
	case G03_CIRCULAR_CCW_INTERPOLATION:
		Gparser.G03_CIRCULAR_CCW_INTERPOLATION[Gparser.indexer.G03_CIRCULAR_CCW_INTERPOLATION].paramaterType=parameterType;
		break;

	}
}

void assignIparameter(float val)
{
	if(Gparser.parserControl.lengthMode==INCHES_MODE)val*=INCHES_TO_MM;
	switch(Gparser.parserControl.activeMovementTask)
	{
	case G02_CIRCULAR_CW_INTERPOLATION:
		Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].I=val;

		break;
	case G03_CIRCULAR_CCW_INTERPOLATION:
		Gparser.G03_CIRCULAR_CCW_INTERPOLATION[Gparser.indexer.G03_CIRCULAR_CCW_INTERPOLATION].I=val;
		break;

	}
}

void assignJparameter(float val)
{
	if(Gparser.parserControl.lengthMode==INCHES_MODE)val*=INCHES_TO_MM;

	switch(Gparser.parserControl.activeMovementTask)
	{
	case G02_CIRCULAR_CW_INTERPOLATION:
		Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].J=val;
		break;
	case G03_CIRCULAR_CCW_INTERPOLATION:
		Gparser.G03_CIRCULAR_CCW_INTERPOLATION[Gparser.indexer.G03_CIRCULAR_CCW_INTERPOLATION].J=val;
		break;

	}
}

void assignRadiusParameter(float val)
{
	if(Gparser.parserControl.lengthMode==INCHES_MODE)val*=INCHES_TO_MM;
	switch(Gparser.parserControl.activeMovementTask)
	{
	case G02_CIRCULAR_CW_INTERPOLATION:
		Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].radius=val;
		break;
	case G03_CIRCULAR_CCW_INTERPOLATION:
		Gparser.G03_CIRCULAR_CCW_INTERPOLATION[Gparser.indexer.G03_CIRCULAR_CCW_INTERPOLATION].radius=val;
		break;

	}
}

void assignFeedRateParameter(float val)
{
	Gparser.parserControl.activeFeedRate=val;

}
void taskIndexer(uint8_t task)
{
	Gparser.parserControl.taskParsestatus[Gparser.parserControl.taskIndex]=TASK_PARSE_COMPLETED;

	switch(task)
	{
	case G00_RAPID_MOVEMENT:
		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=G00_RAPID_MOVEMENT;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=
				++Gparser.indexer.G00_RAPID_MOVEMENT;
		Gparser.parserControl.activeMovementTask=G00_RAPID_MOVEMENT;
		Gparser.G00_RAPID_MOVEMENT[Gparser.indexer.G00_RAPID_MOVEMENT].X=
				Gparser.parserControl.position.mmPosition.X;
		Gparser.G00_RAPID_MOVEMENT[Gparser.indexer.G00_RAPID_MOVEMENT].Y=
				Gparser.parserControl.position.mmPosition.Y;
		Gparser.G00_RAPID_MOVEMENT[Gparser.indexer.G00_RAPID_MOVEMENT].Z=
				Gparser.parserControl.position.mmPosition.Z;
		break;
	case G01_LINEAR_INTERPOLATION:
		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=G01_LINEAR_INTERPOLATION;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=
				++Gparser.indexer.G01_LINEAR_INTERPOLATION;
		Gparser.parserControl.activeMovementTask=G01_LINEAR_INTERPOLATION;
		Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].feedRate=
				Gparser.parserControl.activeFeedRate;
		Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].X=
				Gparser.parserControl.position.mmPosition.X;
		Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].Y=
				Gparser.parserControl.position.mmPosition.Y;
		Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].Z=
				Gparser.parserControl.position.mmPosition.Z;
		break;
	case G02_CIRCULAR_CW_INTERPOLATION:
		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=G02_CIRCULAR_CW_INTERPOLATION;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=
				++Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION;
		Gparser.parserControl.activeMovementTask=G02_CIRCULAR_CW_INTERPOLATION;
		Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].feedRate=
				Gparser.parserControl.activeFeedRate;

		Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].X=
				Gparser.parserControl.position.mmPosition.X;
		Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].Y=
				Gparser.parserControl.position.mmPosition.Y;
		break;
	case G03_CIRCULAR_CCW_INTERPOLATION:
		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=G03_CIRCULAR_CCW_INTERPOLATION;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=
				++Gparser.indexer.G03_CIRCULAR_CCW_INTERPOLATION;
		Gparser.parserControl.activeMovementTask=G03_CIRCULAR_CCW_INTERPOLATION;
		Gparser.G03_CIRCULAR_CCW_INTERPOLATION[Gparser.indexer.G03_CIRCULAR_CCW_INTERPOLATION].feedRate=
				Gparser.parserControl.activeFeedRate;
		Gparser.G03_CIRCULAR_CCW_INTERPOLATION[Gparser.indexer.G03_CIRCULAR_CCW_INTERPOLATION].X=
				Gparser.parserControl.position.mmPosition.X;
		Gparser.G03_CIRCULAR_CCW_INTERPOLATION[Gparser.indexer.G03_CIRCULAR_CCW_INTERPOLATION].Y=
				Gparser.parserControl.position.mmPosition.Y;
		break;
	case G17_XY_PLANE:
		break;
	case G20_INCHES_MODE:
		Gparser.parserControl.lengthMode=INCHES_MODE;
		break;
	case G21_METRIC_MODE:
		Gparser.parserControl.lengthMode=G21_METRIC_MODE;
		break;
	case G28_MOVE_TO_ORIGIN:
		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=G28_MOVE_TO_ORIGIN;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=
				++Gparser.indexer.G28_MOVE_TO_ORIGIN;
		Gparser.parserControl.activeMovementTask=G28_MOVE_TO_ORIGIN;
		Gparser.G28_MOVE_TO_ORIGIN[Gparser.indexer.G28_MOVE_TO_ORIGIN].X=0;
		Gparser.G28_MOVE_TO_ORIGIN[Gparser.indexer.G28_MOVE_TO_ORIGIN].Y=0;
		Gparser.G28_MOVE_TO_ORIGIN[Gparser.indexer.G28_MOVE_TO_ORIGIN].Z=0;
		break;

	case G40_CANCEL_RADIUS_COMPENSATION:
		break;
	case G49_CANCEL_LENGTH_COMPENSATION:
		break;
	case G64_CONSTANT_SPEED_MODE:
		break;
	case G90_ABSOLUTE_MODE_SELECT:
		Gparser.parserControl.incAbsoluteSelect=ABSOLUTE_MODE;
		break;
	case G91_INCREMENTAL_MODE_SELECT:
		Gparser.parserControl.incAbsoluteSelect=INCREMENTAL_MODE;
		break;

	case G92_SET_POSITION:
		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=G92_SET_POSITION;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=
				++Gparser.indexer.G92_SET_POSITION;
		Gparser.parserControl.activeMovementTask=G92_SET_POSITION;
		Gparser.G92_SET_POSITION[Gparser.indexer.G92_SET_POSITION].X=
				Gparser.parserControl.position.mmPosition.X;
		Gparser.G92_SET_POSITION[Gparser.indexer.G92_SET_POSITION].Y=
				Gparser.parserControl.position.mmPosition.Y;
		Gparser.G92_SET_POSITION[Gparser.indexer.G92_SET_POSITION].Z=
				Gparser.parserControl.position.mmPosition.Z;
		break;



	case M82_SET_EXTRUDER_ABSOLUTE_MODE:
		Gparser.parserControl.extruderIncAbsoluteSelect=ABSOLUTE_MODE;
		break;

	case M190_SET_WAIT_BED_TEMP:

		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=M190_SET_WAIT_BED_TEMP;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=
				++Gparser.indexer.M190_SET_WAIT_BED_TEMP;
		Gparser.parserControl.activeMovementTask=M190_SET_WAIT_BED_TEMP;

		break;

	case M104_SET_EXTRUDER_TEMP:

		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=M104_SET_EXTRUDER_TEMP;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=
				++Gparser.indexer.M104_SET_EXTRUDER_TEMP;
		Gparser.parserControl.activeMovementTask=M104_SET_EXTRUDER_TEMP;
		break;

	case M109_SET_WAIT_EXTRUDER_TEMP:

		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=M109_SET_WAIT_EXTRUDER_TEMP;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=
				++Gparser.indexer.M109_SET_WAIT_EXTRUDER_TEMP;
		Gparser.parserControl.activeMovementTask=M109_SET_WAIT_EXTRUDER_TEMP;
		break;

	case M107_FAN_OFF:

		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=M107_FAN_OFF;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=
				++Gparser.indexer.M107_FAN_OFF;
		Gparser.parserControl.activeMovementTask=M107_FAN_OFF;
		break;

	case M117_DISPLAY_MESSAGE:

		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=M117_DISPLAY_MESSAGE;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=
				++Gparser.indexer.M117_DISPLAY_MESSAGE;
		Gparser.parserControl.activeMovementTask=M117_DISPLAY_MESSAGE;

		memcpy(Gparser.M117_DISPLAY_MESSAGE[Gparser.indexer.M117_DISPLAY_MESSAGE],
				Gparser.parserControl.message,sizeof(Gparser.parserControl.message));

		break;


	case M_FUNCTION:
		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=M_FUNCTION;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=++Gparser.indexer.M_FUNCTION;
		break;
	case SPEED:
		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=SPEED;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=++Gparser.indexer.SPEED;
		break;
	case TOOL:
		Gparser.parserControl.taskBuffer[++Gparser.parserControl.taskIndex][0]=TOOL;
		Gparser.parserControl.taskBuffer[Gparser.parserControl.taskIndex][1]=1; //tool indexer will not performed
		break;
	case WRONG_PARAMETER:
		parserError(WRONG_PARAMETER_ERROR);
		break;
	default:
		break;
	}
}

//TODO taskData sadece G gelirse hata verebilir
uint8_t getTask(char* taskData)
{
	uint8_t Task;
	Task=(uint8_t)atoi(&taskData[1]);
	switch(taskData[0])
	{
	case 'G':
	{
		switch(Task)
		{

		case 0:
			return G00_RAPID_MOVEMENT;
		case 1:
			return G01_LINEAR_INTERPOLATION;
		case 2:
			return G02_CIRCULAR_CW_INTERPOLATION;
		case 3:
			return G03_CIRCULAR_CCW_INTERPOLATION;
		case 17:
			return G17_XY_PLANE;
		case 20:
			return G20_INCHES_MODE;
		case 21:
			return G21_METRIC_MODE;
		case 28:
			return G28_MOVE_TO_ORIGIN;

		case 40:
			return G40_CANCEL_RADIUS_COMPENSATION;
		case 49:
			return G49_CANCEL_LENGTH_COMPENSATION;
		case 64:
			return G64_CONSTANT_SPEED_MODE;
		case 90:
			return G90_ABSOLUTE_MODE_SELECT;
		case 91:
			return G91_INCREMENTAL_MODE_SELECT;
		case 92:
			return G92_SET_POSITION;


		}
	}
	break;
	case 'M':
	{
		switch(Task)
		{

		case 82:
			return M82_SET_EXTRUDER_ABSOLUTE_MODE;
		case 104:
			return M104_SET_EXTRUDER_TEMP;
		case 107:
			return M107_FAN_OFF;
		case 109:
			return M109_SET_WAIT_EXTRUDER_TEMP;
		case 117:
			return M117_DISPLAY_MESSAGE;
		case 190:
			return M190_SET_WAIT_BED_TEMP;




		}
		break;
	}
	case 'S':
		return SPEED;
	case 'T':
		return TOOL;
	}
	return WRONG_PARAMETER;
}


void assignFeedRate(float feedRate, char modalTask)
{
	switch(modalTask)
	{
	case G01_LINEAR_INTERPOLATION:
		Gparser.G01_LINEAR_INTERPOLATION[Gparser.indexer.G01_LINEAR_INTERPOLATION].feedRate=feedRate;
		break;
	case G02_CIRCULAR_CW_INTERPOLATION:
		Gparser.G02_CIRCULAR_CW_INTERPOLATION[Gparser.indexer.G02_CIRCULAR_CW_INTERPOLATION].feedRate=feedRate;
		break;
	case G03_CIRCULAR_CCW_INTERPOLATION:
		Gparser.G03_CIRCULAR_CCW_INTERPOLATION[Gparser.indexer.G03_CIRCULAR_CCW_INTERPOLATION].feedRate=feedRate;
		break;
	}
}


void isTaskLineUsed(uint8_t *Gline)
{
	if(Gline[0]!='N')
	{
		Gparser.lineController.lineNumberUsed=LINE_NUMBER_INACTIVE;
	}
	else
	{
		Gparser.lineController.lineNumberUsed=LINE_NUMBER_ACTIVE;
	}
}


void lineSplit(uint8_t* line)
{
	uint8_t cntr=0;
	while(*line!='\n')
	{
		while(*line==' ')line++;
		cntr=0;
		switch(*line)
		{
		case '\0':
		case '\r':
		case '\n':
			return;
		case 'X':
		case 'Y':
		case 'Z':
		case 'E':
		case 'I':
		case 'J':
		case 'R':
		case 'F':
		case 'S':
		case 'T':
		case 'M':

		case 'G':

			//			if((*(line)=='M')&&(*(line+1)=='1')&&(*(line+2)=='1')&&(*(line+3)=='7'))
			//			{
			//				line+=4;
			//				while(*line==' ')line++;
			//				memset(Gparser.parserControl.message,0,sizeof(Gparser.parserControl.message));
			//				while((*line!=' ') && (*line!=START_COMMENT)&&(*line!='\n')&&(cntr<(sizeof(Gparser.parserControl.message)-2)))
			//				{
			//					Gparser.parserControl.message[cntr++]=*line++;
			//
			//				}
			//				Gparser.parserControl.message[cntr++]='\n';
			//				Gparser.lineController.wordCounter++;
			//				break;
			//
			//			}

			/*get remaining here G 00 T 01 likewise codes may be added here*/
			Gparser.lineController.subLineData[Gparser.lineController.wordCounter][cntr++]=(char)*line++;
			while(*(line)==' ')line++;
			if(*line=='.')Gparser.lineController.subLineData[Gparser.lineController.wordCounter][cntr++]='0';
			while((*line!=' ') && (*line!=START_COMMENT)&&(*line!='\n'))
			{
				Gparser.lineController.subLineData[Gparser.lineController.wordCounter][cntr++]=*line++;
			}

			if((Gparser.lineController.subLineData[Gparser.lineController.wordCounter][0]=='M')&&
					(Gparser.lineController.subLineData[Gparser.lineController.wordCounter][1]=='1')&&
					(Gparser.lineController.subLineData[Gparser.lineController.wordCounter][2]=='1')&&
					(Gparser.lineController.subLineData[Gparser.lineController.wordCounter][3]=='7'))
			{
				while(*line==' ')line++;
				memset(Gparser.parserControl.message,0,sizeof(Gparser.parserControl.message));
				cntr=0;
				while((*line!=' ') && (*line!=START_COMMENT)&&(*line!='\n')&&(cntr<(sizeof(Gparser.parserControl.message)-2)))
				{
					Gparser.parserControl.message[cntr++]=*line++;

				}
				Gparser.parserControl.message[cntr++]='\n';
			}

			Gparser.lineController.wordCounter++;
			break;
		case START_COMMENT:
			while(*line!=END_COMMENT)line++;
			break;

		default:
			parserError(WRONG_START_LETTER_ERROR);
			break;

		}
		if(Gparser.lineController.wordCounter>MAXIMUM_WORD_SPLIT)
		{
			parserError(MAXIMUM_WORD_SPLIT_ERROR);
		}
		if(cntr>MAXIMUM_WORD_LENGTH)
		{
			parserError(MAXIMUM_WORD_LENGTH_ERROR);
		}


	}

}

void initGpaser()
{
	resetGpaser();
}

void resetGpaser()
{
	memset(&Gparser, 0x0, sizeof(Gparser));
}
void parserError(uint8_t errorIndex)
{
	while(1);
}



