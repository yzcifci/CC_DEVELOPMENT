/*
 * Gparser.c
 *
 *  Created on: 10 Oca 2018
 *      Author: yzcifci
 */


#include "main.h"

struct parser_ parser;
struct test_ test;


uint8_t  pars(char *data)
{
	while((*data==' '))data++;
	if((*data==START_COMMENT)||(*data==END_CHAR))return COMMENT_LINE;
	parser.parameters[parser.head].task=getTask(data);
	parameterParse(data);
	return PARSABLE_VALID_DATA;


}

void parameterParse(char *data)
{

	memset(&parser.parameters[parser.head].parameter[0],0xff,sizeof(parser.parameters[parser.head].parameter));
	char wordData[16];
	char *word;
	float fdata;
	int32_t idata;
	while((*data!=' ') && (*data!=END_CHAR))data++;
	if(*data==END_CHAR)return;
	while((*data==' '))data++;

	if(parser.parameters[parser.head].task==M117_DISPLAY_MESSAGE)
	{
		word=parser.parameters[parser.head].parameter;
		while((*data!=' ')&&(*data!='\n'))*word++=*data++;
	}

	while(*data!=END_CHAR)
	{

		word=wordData;
		switch(*data)
		{
		case 'X':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			fdata=atof(wordData);
			memcpy(&parser.parameters[parser.head].parameter[0],&fdata,4);
			break;
		case 'Y':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			fdata=atof(wordData);
			memcpy(&parser.parameters[parser.head].parameter[4],&fdata,4);
			break;
		case 'Z':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			fdata=atof(wordData);
			memcpy(&parser.parameters[parser.head].parameter[8],&fdata,4);
			break;

		case 'E':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			fdata=atof(wordData);
			memcpy(&parser.parameters[parser.head].parameter[12],&fdata,4);
			break;

		case 'F':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			fdata=atof(wordData);
			memcpy(&parser.parameters[parser.head].parameter[16],&fdata,4);
			break;

		case 'S':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			idata=atoi(wordData);
			memcpy(&parser.parameters[parser.head].parameter[0],&idata,4);
			break;

		case START_COMMENT:
			return;

		default:
			errorLog(WRONG_START_LETTER_ERROR);
			break;

		}
		while(*data==' ')data++;
	}


}

uint16_t getTask(char* taskData)
{
	uint8_t Task;
	Task=(uint8_t)atoi(&taskData[1]);
	switch(taskData[0])
	{
	case 'G':
	{
		switch(Task)
		{

		case 0:
			return G00_RAPID_MOVEMENT;
		case 1:
			return G01_LINEAR_INTERPOLATION;

		case 20:
			return G20_INCHES_MODE;
		case 21:
			return G21_METRIC_MODE;
		case 28:
			return G28_MOVE_TO_ORIGIN;

		case 90:
			return G90_ABSOLUTE_MODE_SELECT;
		case 91:
			return G91_INCREMENTAL_MODE_SELECT;
		case 92:
			return G92_SET_POSITION;


		}
	}
	break;
	case 'M':
	{
		switch(Task)
		{

		case 82:
			return M82_SET_EXTRUDER_ABSOLUTE_MODE;
		case 84:
			return M84_STOP_STEPPERS_IDLE;
		case 104:
			return M104_SET_EXTRUDER_TEMP;
		case 105:
			return M105_REQUEST_TEMP;
		case 106:
			return M106_FAN_ON;
		case 107:
			return M107_FAN_OFF;
		case 109:
			return M109_SET_WAIT_EXTRUDER_TEMP;
		case 117:
			return M117_DISPLAY_MESSAGE;
		case 140:
			return M140_SET_BED_TEMP;
		case 190:
			return M190_SET_WAIT_BED_TEMP;
		case 204:
			return M204_SET_ACCELERATION;
		}
		break;
	}

	}


	errorLog(WRONG_TASK_ERROR);
	return 0xffff;
}



void parserError(uint8_t errorIndex)
{
	systemOFF();
	while(1);
}

void initializeParser()
{
	memset(&parser, 0xff, sizeof(parser));
	uint16_t size=(sizeof(parser.parameters[0].parameter))/4;

	for(uint32_t i=0; i<PARSER_PARAMETER_SIZE;i++)
	{
		for(uint8_t j=0;j<size;j++)
		{
			*(float*)(&parser.parameters[i].parameter[4*j])=(float)0.0;
		}

	}

	parser.bufferStatus=BUFFER_NOT_FULL;
	parser.empty=PARSER_PARAMETER_SIZE;
	parser.filled=0;
	parser.head=0;
	parser.tail=0;
}




void parserHeadPlus1(void)
{
  parser.head++;
  if(parser.head>=PARSER_PARAMETER_SIZE)parser.head=0;
  parser.filled++;
  parser.empty--;

  if(parser.empty)parser.bufferStatus=BUFFER_NOT_FULL;
  else
  {
	  parser.bufferStatus=BUFFER_FULL;
  }

  if(parser.filled<0)
  {
	  errorLog(PARSER_BUFFER_FILLED_INDEX_BELOV_ZERO_ERROR);
  }
  else if(parser.filled>PARSER_PARAMETER_SIZE)
  {
	  errorLog(PARSER_BUFFER_FILLED_INDEX_ABOVE_MAX_ERROR);
  }
  if(parser.empty<0)
  {
	  errorLog(PARSER_BUFFER_EMPTY_INDEX_BELOV_ZERO_ERROR);
  }
  else if(parser.empty>PARSER_PARAMETER_SIZE)
  {
	  errorLog(PARSER_BUFFER_EMPTY_INDEX_ABOVE_MAX_ERROR);
  }

}
void parserTailPlus1(void)
{
  parser.tail++;
  if(parser.tail>=PARSER_PARAMETER_SIZE)parser.tail=0;
  parser.filled--;
  parser.empty++;

  if(parser.empty)parser.bufferStatus=BUFFER_NOT_FULL;
  else
  {
	  parser.bufferStatus=BUFFER_FULL;
  }

  if(parser.filled<0)
  {
	  errorLog(PARSER_BUFFER_FILLED_INDEX_BELOV_ZERO_ERROR);
  }
  else if(parser.filled>PARSER_PARAMETER_SIZE)
  {
	  errorLog(PARSER_BUFFER_FILLED_INDEX_ABOVE_MAX_ERROR);
  }
  if(parser.empty<0)
  {
	  errorLog(PARSER_BUFFER_EMPTY_INDEX_BELOV_ZERO_ERROR);
  }
  else if(parser.empty>PARSER_PARAMETER_SIZE)
  {
	  errorLog(PARSER_BUFFER_EMPTY_INDEX_ABOVE_MAX_ERROR);
  }




}

