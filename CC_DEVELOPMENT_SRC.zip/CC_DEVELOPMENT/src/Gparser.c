/*
 * Gparser.c
 *
 *  Created on: 10 Oca 2018
 *      Author: yzcifci
 */


#include "task_operator_interface.h"

struct parser_ parser;
struct test_ test;


uint8_t pars(char *data)
{
	if(parser.bufferStatus==BUFFER_FULL)return 0;
	while((*data==' '))data++;
	if((*data==START_COMMENT)||(*data==END_CHAR))return BUFFER_NOT_FULL;
	parser.parameters[parser.head].task=getTask(data);
	parameterParse(data);
	parser.head++;
	if(parser.head>=(MAX_BUFFERED_TASK))parser.head=0;
	parser.tailHeadDiff++;

	if(parser.tailHeadDiff>=(MAX_BUFFERED_TASK-1))
	{
		parser.bufferStatus=BUFFER_FULL;
	}
	else
	{
		parser.bufferStatus=BUFFER_NOT_FULL;
	}

	return BUFFER_NOT_FULL;

}

void parameterParse(char *data)
{

	memset(&parser.parameters[parser.head].parameter[0],0xff,sizeof(parser.parameters[parser.head].parameter));
	char wordData[16];
	char *word;
	float fdata;
	uint16_t idata;
	while((*data!=' ') && (*data!=END_CHAR))data++;
	if(*data==END_CHAR)return;
	while((*data==' '))data++;

	if(parser.parameters[parser.head].task==M117_DISPLAY_MESSAGE)
	{
		word=parser.parameters[parser.head].parameter;
		while((*data!=' ')&&(*data!='\n'))*word++=*data++;
	}

	while(*data!=END_CHAR)
	{

		word=wordData;
		switch(*data)
		{
		case 'X':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			fdata=atof(wordData);
			memcpy(&parser.parameters[parser.head].parameter[0],&fdata,4);
			break;
		case 'Y':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			fdata=atof(wordData);
			memcpy(&parser.parameters[parser.head].parameter[4],&fdata,4);
			break;
		case 'Z':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			fdata=atof(wordData);
			memcpy(&parser.parameters[parser.head].parameter[8],&fdata,4);
			break;

		case 'E':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			fdata=atof(wordData);
			memcpy(&parser.parameters[parser.head].parameter[12],&fdata,4);
			break;

		case 'F':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			fdata=atof(wordData);
			memcpy(&parser.parameters[parser.head].parameter[16],&fdata,4);
			break;

		case 'S':
			data++;
			while((*data!=' ')&&(*data!='\n')&&(*data!=';'))*word++=*data++;
			*word='\n';
			idata=atoi(wordData);
			memcpy(&parser.parameters[parser.head].parameter[0],&idata,4);
			break;

		case START_COMMENT:
			return;

		default:
			parserError(WRONG_START_LETTER_ERROR);
			break;

		}
		while(*data==' ')data++;
	}


}

uint16_t getTask(char* taskData)
{
	uint8_t Task;
	Task=(uint8_t)atoi(&taskData[1]);
	switch(taskData[0])
	{
	case 'G':
	{
		switch(Task)
		{

		case 0:
			return G00_RAPID_MOVEMENT;
		case 1:
			return G01_LINEAR_INTERPOLATION;

		case 20:
			return G20_INCHES_MODE;
		case 21:
			return G21_METRIC_MODE;
		case 28:
			return G28_MOVE_TO_ORIGIN;

		case 90:
			return G90_ABSOLUTE_MODE_SELECT;
		case 91:
			return G91_INCREMENTAL_MODE_SELECT;
		case 92:
			return G92_SET_POSITION;


		}
	}
	break;
	case 'M':
	{
		switch(Task)
		{

		case 82:
			return M82_SET_EXTRUDER_ABSOLUTE_MODE;
		case 84:
			return M84_STOP_STEPPERS_IDLE;
		case 104:
			return M104_SET_EXTRUDER_TEMP;
		case 106:
			return M106_FAN_ON;
		case 107:
			return M107_FAN_OFF;
		case 109:
			return M109_SET_WAIT_EXTRUDER_TEMP;
		case 117:
			return M117_DISPLAY_MESSAGE;
		case 140:
			return M140_SET_BED_TEMP;
		case 190:
			return M190_SET_WAIT_BED_TEMP;
		}
		break;
	}

	}


	parserError(WRONG_TASK_ERROR);
	return 0xffff;
}



void parserError(uint8_t errorIndex)
{
	systemOFF();
	while(1);
}

void initializeParser()
{
	memset(&parser, 0x0, sizeof(parser));
}

