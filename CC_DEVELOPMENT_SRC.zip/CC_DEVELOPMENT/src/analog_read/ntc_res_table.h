/*
 * ntc_res_table.h
 *
 *  Created on: 10 Tem 2018
 *      Author: yzcifci
 */

#ifndef ANALOG_READ_NTC_RES_TABLE_H_
#define ANALOG_READ_NTC_RES_TABLE_H_

uint16_t heatbedNTCtable[26];
uint16_t extruderNTCtable[261];
#endif /* ANALOG_READ_NTC_RES_TABLE_H_ */
