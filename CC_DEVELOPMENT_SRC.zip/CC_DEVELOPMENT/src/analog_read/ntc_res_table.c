/*
 * ntc_res_table.c
 *
 *  Created on: 10 Tem 2018
 *      Author: yzcifci
 */
#include "task_operator_interface.h"
uint16_t heatbedNTCtable[340]=
{

};





uint16_t extruderNTCtable[340]=
{

};
