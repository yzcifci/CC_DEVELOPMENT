/*
 * adc_control.h
 *
 *  Created on: 18 May 2018
 *      Author: yzcifci
 */

#ifndef ADC_CONTROL_H_
#define ADC_CONTROL_H_

/*
 * adc_control.c
 *
 *  Created on: 18 May 2018
 *      Author: yzcifci
 */


extern ADC_HandleTypeDef hadc1;
extern DMA_HandleTypeDef hdma_adc1;


extern struct ADC_control_
{
	uint32_t periodicADCcntr;
	uint16_t readADCVal[2];
	uint8_t readFlag;
}ADC_control;

void ADC_Init();
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc);
void ADC_IRQHandler(void);
void DMA2_Stream0_IRQHandler(void);
void ADCReadTest();
void startADCconversions();
void periodicADCConvertCall();

#endif /* ADC_CONTROL_H_ */
