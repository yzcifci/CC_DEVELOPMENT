/*
 * GPIO_control.c
 *
 *  Created on: 14 Oca 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

/*
 * ham data 1: forward 0:backward
 */
void setDirX(uint8_t dir)
{
	if(dir)dir=DIR_FORWARD_X;
	else
	{
		dir=DIR_BACKWARD_X;
	}
	HAL_GPIO_WritePin(DIR_PORT_X1,DIR_PIN_X1, dir);
}

/*
 * ham data 1: forward 0:backward
 */
void setDirY(uint8_t dir)
{
	if(dir)dir=DIR_FORWARD_Y;
	else
	{
		dir=DIR_BACKWARD_Y;
	}
	HAL_GPIO_WritePin(DIR_PORT_Y,DIR_PIN_Y, dir);
}

/*
 * ham data 1: forward 0:backward
 */
void setDirZ(uint8_t dir)
{
	if(dir)dir=DIR_FORWARD_Z;
	else
	{
		dir=DIR_BACKWARD_Z;
	}
	HAL_GPIO_WritePin(DIR_PORT_Z,DIR_PIN_Z, dir);
}

/*
 * ham data 1: forward 0:backward
 */
void setDirE(uint8_t dir)
{
	if(dir)dir=DIR_FORWARD_E;
	else
	{
		dir=DIR_BACKWARD_E;
	}
	HAL_GPIO_WritePin(DIR_PORT_E,DIR_PIN_E, dir);
}

uint32_t timings[128];
uint8_t cntrtime=0;
void toggleX(char dirX)
{
	setDirX(dirX);
	HAL_GPIO_TogglePin(PORT_X1,PIN_X1);

//	setDirY(dirX);
//	HAL_GPIO_TogglePin(PORT_Y,PIN_Y);
//
//	// test start timing
//	if(cntrtime<128)timings[cntrtime++]=timerControl.globalCntr;
//	else
//	{
//		cntrtime=0;
//	}
//
//	if((cntrtime>1)&&(timings[cntrtime-1]-timings[cntrtime-2]!=600))
//	{
//		cntrtime=0;
//	}
#if MOVEMENT_TEST_ENABLE
	movementTestHandler(COORDINATE_X, dirX);
#endif

}

void toggleY(char dirY)
{
	setDirY(dirY);
	HAL_GPIO_TogglePin(PORT_Y,PIN_Y);

#if MOVEMENT_TEST_ENABLE
	movementTestHandler(COORDINATE_Y, dirY);
#endif
}

void toggleZ(char dirZ)
{
	setDirZ(dirZ);
	HAL_GPIO_TogglePin(PORT_Z,PIN_Z);

#if MOVEMENT_TEST_ENABLE
	movementTestHandler(COORDINATE_Z, dirZ);
#endif
}

void toggleE(char dirE)
{
	setDirE(dirE);
	HAL_GPIO_TogglePin(PORT_E,PIN_E);

}

void enableX()
{
	HAL_GPIO_WritePin(ENABLE_PORT_X1,ENABLE_PIN_X1, ENABLE_STEPPER);
}
void enableY()
{
	HAL_GPIO_WritePin(ENABLE_PORT_Y,ENABLE_PIN_Y, ENABLE_STEPPER);
}
void enableZ()
{
	HAL_GPIO_WritePin(ENABLE_PORT_Z,ENABLE_PIN_Z, ENABLE_STEPPER);
}
void enableE()
{
	HAL_GPIO_WritePin(ENABLE_PORT_E,ENABLE_PIN_E, ENABLE_STEPPER);
}

void disableX()
{
	HAL_GPIO_WritePin(ENABLE_PORT_X1,ENABLE_PIN_X1, DISABLE_STEPPER);
}
void disableY()
{
	HAL_GPIO_WritePin(ENABLE_PORT_Y,ENABLE_PIN_Y, DISABLE_STEPPER);
}
void disableZ()
{
	HAL_GPIO_WritePin(ENABLE_PORT_Z,ENABLE_PIN_Z, DISABLE_STEPPER);
}
void disableE()
{
	HAL_GPIO_WritePin(ENABLE_PORT_E,ENABLE_PIN_E, DISABLE_STEPPER);
}

void stopMovement()
{
	disableX();
	disableY();
	disableZ();
	disableE();
	resetPinMovementPinStates();
}

void resetPinMovementPinStates()
{
	HAL_GPIO_WritePin(PORT_X1,PIN_X1,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PORT_Y,PIN_Y,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PORT_Z,PIN_Z,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PORT_E,PIN_E,GPIO_PIN_RESET);
}





void startStep(char dirX,char dirY, char dirZ, char dirE, uint16_t Tx,uint16_t Ty,uint16_t Tz, uint16_t Te)
{
	if(Tx)
	{
		setDirX(dirX);
		HAL_GPIO_WritePin(PORT_X1,PIN_X1,GPIO_PIN_SET);
	}
	if(Ty)
	{
		setDirY(dirY);
		HAL_GPIO_WritePin(PORT_Y,PIN_Y,GPIO_PIN_SET);
	}
	if(Tz)
	{
		setDirZ(dirZ);
		HAL_GPIO_WritePin(PORT_Z,PIN_Z,GPIO_PIN_SET);
	}

	if(Te)
	{
		setDirE(dirE);
		HAL_GPIO_WritePin(PORT_E,PIN_E,GPIO_PIN_SET);
	}

}



void initPorts()
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	/* Configure the PORT X1 pin */

	/*PORTS*/
	GPIO_InitStruct.Pin = PIN_X1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(PORT_X1);
	HAL_GPIO_Init(PORT_X1, &GPIO_InitStruct);
	HAL_GPIO_WritePin(PORT_X1,PIN_X1, GPIO_PIN_RESET);


	GPIO_InitStruct.Pin = PIN_Y;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(PORT_Y);
	HAL_GPIO_Init(PORT_Y, &GPIO_InitStruct);
	HAL_GPIO_WritePin(PORT_Y,PIN_Y, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = PIN_Z;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(PORT_Z);
	HAL_GPIO_Init(PORT_Z, &GPIO_InitStruct);
	HAL_GPIO_WritePin(PORT_Z,PIN_Z, GPIO_PIN_RESET);


	GPIO_InitStruct.Pin = PIN_E;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(PORT_E);
	HAL_GPIO_Init(PORT_E, &GPIO_InitStruct);
	HAL_GPIO_WritePin(PORT_E,PIN_E, GPIO_PIN_RESET);

	/*ENABLE PORTS*/

	GPIO_InitStruct.Pin = ENABLE_PIN_X1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(ENABLE_PORT_X1);
	HAL_GPIO_Init(ENABLE_PORT_X1, &GPIO_InitStruct);
	HAL_GPIO_WritePin(ENABLE_PORT_X1,ENABLE_PIN_X1, GPIO_PIN_RESET);


	GPIO_InitStruct.Pin = ENABLE_PIN_Y;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(ENABLE_PORT_Y);
	HAL_GPIO_Init(ENABLE_PORT_Y, &GPIO_InitStruct);
	HAL_GPIO_WritePin(ENABLE_PORT_Y,ENABLE_PIN_Y, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = ENABLE_PIN_Z;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(ENABLE_PORT_Z);
	HAL_GPIO_Init(ENABLE_PORT_Z, &GPIO_InitStruct);
	HAL_GPIO_WritePin(ENABLE_PORT_Z,ENABLE_PIN_Z, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = ENABLE_PIN_E;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(ENABLE_PORT_E);
	HAL_GPIO_Init(ENABLE_PORT_E, &GPIO_InitStruct);
	HAL_GPIO_WritePin(ENABLE_PORT_E,ENABLE_PIN_E, GPIO_PIN_RESET);

	/* DIRECTION PORTS*/

	GPIO_InitStruct.Pin = DIR_PIN_X1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(DIR_PORT_X1);
	HAL_GPIO_Init(DIR_PORT_X1, &GPIO_InitStruct);
	HAL_GPIO_WritePin(DIR_PORT_X1,DIR_PIN_X1, GPIO_PIN_RESET);


	GPIO_InitStruct.Pin = DIR_PIN_Y;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(DIR_PORT_Y);
	HAL_GPIO_Init(DIR_PORT_Y, &GPIO_InitStruct);
	HAL_GPIO_WritePin(DIR_PORT_Y,DIR_PIN_Y, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = DIR_PIN_Z;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(DIR_PORT_Z);
	HAL_GPIO_Init(DIR_PORT_Z, &GPIO_InitStruct);
	HAL_GPIO_WritePin(DIR_PORT_Z,DIR_PIN_Z, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = DIR_PIN_E;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(DIR_PORT_E);
	HAL_GPIO_Init(DIR_PORT_E, &GPIO_InitStruct);
	HAL_GPIO_WritePin(DIR_PORT_E,DIR_PIN_E, GPIO_PIN_RESET);


	/*EXTRUDER HEATER INIT*/
	GPIO_InitStruct.Pin = EXTRUDER_HEATER_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(EXTRUDER_HEATER_PORT);
	HAL_GPIO_Init(EXTRUDER_HEATER_PORT, &GPIO_InitStruct);
	HAL_GPIO_WritePin(EXTRUDER_HEATER_PORT,EXTRUDER_HEATER_PIN, GPIO_PIN_RESET);

	/*EXTRUDER COOLER INIT*/
	GPIO_InitStruct.Pin = EXTRUDER_COOLER_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(EXTRUDER_COOLER_PORT);
	HAL_GPIO_Init(EXTRUDER_COOLER_PORT, &GPIO_InitStruct);
	HAL_GPIO_WritePin(EXTRUDER_COOLER_PORT,EXTRUDER_COOLER_PIN, GPIO_PIN_RESET);

	/*HEATBED HEATER INIT*/
	GPIO_InitStruct.Pin = HEATBED_HEATER_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(HEATBED_HEATER_PORT);
	HAL_GPIO_Init(HEATBED_HEATER_PORT, &GPIO_InitStruct);
	HAL_GPIO_WritePin(HEATBED_HEATER_PORT,HEATBED_HEATER_PIN, GPIO_PIN_RESET);

	/*LIMIT SWITCHES INIT*/
	GPIO_InitStruct.Pin = LIMIT_SWITCH_PIN_X;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_CLOCK_ENABLE(LIMIT_SWITCH_PORT_X);
	HAL_GPIO_Init(LIMIT_SWITCH_PORT_X, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = LIMIT_SWITCH_PIN_Y;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_CLOCK_ENABLE(LIMIT_SWITCH_PORT_Y);
	HAL_GPIO_Init(LIMIT_SWITCH_PORT_Y, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = LIMIT_SWITCH_PIN_Z;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_CLOCK_ENABLE(LIMIT_SWITCH_PORT_Z);
	HAL_GPIO_Init(LIMIT_SWITCH_PORT_Z, &GPIO_InitStruct);


	/*X AXIS MOTOR SWİTCH INIT*/
	GPIO_InitStruct.Pin = PORTX_PIN_MS1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTX_MS1);
	HAL_GPIO_Init(PORTX_MS1, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = PORTX_PIN_MS2;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTX_MS2);
	HAL_GPIO_Init(PORTX_MS2, &GPIO_InitStruct);


	GPIO_InitStruct.Pin = PORTX_PIN_MS3;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTX_MS3);
	HAL_GPIO_Init(PORTX_MS3, &GPIO_InitStruct);

	/*Y AXIS MOTOR SWİTCH INIT*/
	GPIO_InitStruct.Pin = PORTY_PIN_MS1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTY_MS1);
	HAL_GPIO_Init(PORTY_MS1, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = PORTY_PIN_MS2;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTY_MS2);
	HAL_GPIO_Init(PORTY_MS2, &GPIO_InitStruct);


	GPIO_InitStruct.Pin = PORTY_PIN_MS3;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTY_MS3);
	HAL_GPIO_Init(PORTY_MS3, &GPIO_InitStruct);

	/*Z AXIS MOTOR SWİTCH INIT*/
	GPIO_InitStruct.Pin = PORTZ_PIN_MS1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTZ_MS1);
	HAL_GPIO_Init(PORTZ_MS1, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = PORTZ_PIN_MS2;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTZ_MS2);
	HAL_GPIO_Init(PORTZ_MS2, &GPIO_InitStruct);


	GPIO_InitStruct.Pin = PORTZ_PIN_MS3;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTZ_MS3);
	HAL_GPIO_Init(PORTZ_MS3, &GPIO_InitStruct);


	/*EXTRUDER MOTOR SWİTCH INIT*/
	GPIO_InitStruct.Pin = PORTE_PIN_MS1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTE_MS1);
	HAL_GPIO_Init(PORTE_MS1, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = PORTE_PIN_MS2;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTE_MS2);
	HAL_GPIO_Init(PORTE_MS2, &GPIO_InitStruct);


	GPIO_InitStruct.Pin = PORTE_PIN_MS3;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_CLOCK_ENABLE(PORTE_MS3);
	HAL_GPIO_Init(PORTE_MS3, &GPIO_InitStruct);


	disableY();
	disableZ();
	disableE();


	setMicroStepX(16);
	setMicroStepY(16);
	setMicroStepZ(16);
	setMicroStepE(16);

	enableX();
	HAL_Delay(500);
	enableY();
	HAL_Delay(500);
	enableZ();
	HAL_Delay(500);
	enableE();

}




void GPIO_CLOCK_ENABLE(GPIO_TypeDef* GPIO)
{
	if(GPIO==GPIOA)__HAL_RCC_GPIOA_CLK_ENABLE();
	else if(GPIO==GPIOB)__HAL_RCC_GPIOB_CLK_ENABLE();
	else if(GPIO==GPIOC)__HAL_RCC_GPIOC_CLK_ENABLE();
	else if(GPIO==GPIOD)__HAL_RCC_GPIOD_CLK_ENABLE();
	else if(GPIO==GPIOE)__HAL_RCC_GPIOE_CLK_ENABLE();
}

uint8_t readLimitSwitchX()
{
 return  HAL_GPIO_ReadPin(LIMIT_SWITCH_PORT_X, LIMIT_SWITCH_PIN_X);
}

uint8_t readLimitSwitchY()
{
 return  HAL_GPIO_ReadPin(LIMIT_SWITCH_PORT_Y, LIMIT_SWITCH_PIN_Y);
}

uint8_t readLimitSwitchZ()
{
 return  HAL_GPIO_ReadPin(LIMIT_SWITCH_PORT_Z, LIMIT_SWITCH_PIN_Z);
}
void extruderHeaterOn()
{
	HAL_GPIO_WritePin(EXTRUDER_HEATER_PORT,EXTRUDER_HEATER_PIN, EXTRUDER_HEATER_ON);
}

void extruderHeaterOff()
{
	HAL_GPIO_WritePin(EXTRUDER_HEATER_PORT,EXTRUDER_HEATER_PIN, EXTURDER_HEATER_OFF);
}

void extruderCoolerOn()
{
	HAL_GPIO_WritePin(EXTRUDER_COOLER_PORT,EXTRUDER_COOLER_PIN, EXTRUDER_COOLER_ON);
}

void extruderCoolerOff()
{
	HAL_GPIO_WritePin(EXTRUDER_COOLER_PORT,EXTRUDER_COOLER_PIN, EXTURDER_COOLER_OFF);
}

void heatBedHeaterOn()
{
	HAL_GPIO_WritePin(HEATBED_HEATER_PORT,HEATBED_HEATER_PIN, HEATBED_HEATER_ON);
}

void heatBedHeaterOff()
{
	HAL_GPIO_WritePin(HEATBED_HEATER_PORT,HEATBED_HEATER_PIN, HEATBED_HEATER_OFF);
}




void setMicroStepX(uint8_t microStep)
{



	if(microStep==1)
	{
		HAL_GPIO_WritePin(PORTX_MS1,PORTX_PIN_MS1, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(PORTX_MS2,PORTX_PIN_MS2, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(PORTX_MS3,PORTX_PIN_MS3, GPIO_PIN_RESET);
	}
	else if(microStep==2)
	{
		HAL_GPIO_WritePin(PORTX_MS1,PORTX_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTX_MS2,PORTX_PIN_MS2, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTX_MS3,PORTX_PIN_MS3, GPIO_PIN_RESET);

	}

	else if(microStep==4)
	{
		HAL_GPIO_WritePin(PORTX_MS1,PORTX_PIN_MS1, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTX_MS2,PORTX_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTX_MS3,PORTX_PIN_MS3, GPIO_PIN_RESET);
	}

	else if(microStep==8)
	{
		HAL_GPIO_WritePin(PORTX_MS1,PORTX_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTX_MS2,PORTX_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTX_MS3,PORTX_PIN_MS3, GPIO_PIN_RESET);

	}

	else if(microStep==16)
	{
		HAL_GPIO_WritePin(PORTX_MS1,PORTX_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTX_MS2,PORTX_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTX_MS3,PORTX_PIN_MS3, GPIO_PIN_SET);

	}


	else if(microStep==32)
	{
		HAL_GPIO_WritePin(PORTX_MS1,PORTX_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTX_MS2,PORTX_PIN_MS2, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTX_MS3,PORTX_PIN_MS3, GPIO_PIN_SET);

	}

	else
	{
		parameterError(WRONG_MICROSTEP_ERROR);
		return;
	}

	deviceControl.stepPosition.stepX=((microStep*deviceControl.stepPosition.stepX)/deviceControl.microStepX);
	deviceControl.microStepX=microStep;

}



void setMicroStepY(uint8_t microStep)
{



	if(microStep==1)
	{
		HAL_GPIO_WritePin(PORTY_MS1,PORTY_PIN_MS1, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(PORTY_MS2,PORTY_PIN_MS2, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(PORTY_MS3,PORTY_PIN_MS3, GPIO_PIN_RESET);
	}
	else if(microStep==2)
	{
		HAL_GPIO_WritePin(PORTY_MS1,PORTY_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTY_MS2,PORTY_PIN_MS2, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTY_MS3,PORTY_PIN_MS3, GPIO_PIN_RESET);

	}

	else if(microStep==4)
	{
		HAL_GPIO_WritePin(PORTY_MS1,PORTY_PIN_MS1, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTY_MS2,PORTY_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTY_MS3,PORTY_PIN_MS3, GPIO_PIN_RESET);
	}

	else if(microStep==8)
	{
		HAL_GPIO_WritePin(PORTY_MS1,PORTY_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTY_MS2,PORTY_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTY_MS3,PORTY_PIN_MS3, GPIO_PIN_RESET);

	}

	else if(microStep==16)
	{
		HAL_GPIO_WritePin(PORTY_MS1,PORTY_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTY_MS2,PORTY_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTY_MS3,PORTY_PIN_MS3, GPIO_PIN_SET);

	}


	else if(microStep==32)
	{
		HAL_GPIO_WritePin(PORTY_MS1,PORTY_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTY_MS2,PORTY_PIN_MS2, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTY_MS3,PORTY_PIN_MS3, GPIO_PIN_SET);

	}


	else
	{
		parameterError(WRONG_MICROSTEP_ERROR);
		return;
	}
	deviceControl.stepPosition.stepY=((microStep*deviceControl.stepPosition.stepY)/deviceControl.microStepY);
	deviceControl.microStepY=microStep;
}


void setMicroStepZ(uint8_t microStep)
{



	if(microStep==1)
	{
		HAL_GPIO_WritePin(PORTZ_MS1,PORTZ_PIN_MS1, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(PORTZ_MS2,PORTZ_PIN_MS2, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(PORTZ_MS3,PORTZ_PIN_MS3, GPIO_PIN_RESET);
	}
	else if(microStep==2)
	{
		HAL_GPIO_WritePin(PORTZ_MS1,PORTZ_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTZ_MS2,PORTZ_PIN_MS2, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTZ_MS3,PORTZ_PIN_MS3, GPIO_PIN_RESET);

	}

	else if(microStep==4)
	{
		HAL_GPIO_WritePin(PORTZ_MS1,PORTZ_PIN_MS1, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTZ_MS2,PORTZ_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTZ_MS3,PORTZ_PIN_MS3, GPIO_PIN_RESET);
	}

	else if(microStep==8)
	{
		HAL_GPIO_WritePin(PORTZ_MS1,PORTZ_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTZ_MS2,PORTZ_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTZ_MS3,PORTZ_PIN_MS3, GPIO_PIN_RESET);

	}

	else if(microStep==16)
	{
		HAL_GPIO_WritePin(PORTZ_MS1,PORTZ_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTZ_MS2,PORTZ_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTZ_MS3,PORTZ_PIN_MS3, GPIO_PIN_SET);

	}

	else if(microStep==32)
	{
		HAL_GPIO_WritePin(PORTZ_MS1,PORTZ_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTZ_MS2,PORTZ_PIN_MS2, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTZ_MS3,PORTZ_PIN_MS3, GPIO_PIN_SET);

	}


	else
	{
		parameterError(WRONG_MICROSTEP_ERROR);
		return;
	}
	deviceControl.stepPosition.stepZ=((microStep*deviceControl.stepPosition.stepZ)/deviceControl.microStepZ);
	deviceControl.microStepZ=microStep;
}


void setMicroStepE(uint8_t microStep)
{



	if(microStep==1)
	{
		HAL_GPIO_WritePin(PORTE_MS1,PORTE_PIN_MS1, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(PORTE_MS2,PORTE_PIN_MS2, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(PORTE_MS3,PORTE_PIN_MS3, GPIO_PIN_RESET);
	}
	else if(microStep==2)
	{
		HAL_GPIO_WritePin(PORTE_MS1,PORTE_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTE_MS2,PORTE_PIN_MS2, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTE_MS3,PORTE_PIN_MS3, GPIO_PIN_RESET);

	}

	else if(microStep==4)
	{
		HAL_GPIO_WritePin(PORTE_MS1,PORTE_PIN_MS1, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTE_MS2,PORTE_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTE_MS3,PORTE_PIN_MS3, GPIO_PIN_RESET);
	}

	else if(microStep==8)
	{
		HAL_GPIO_WritePin(PORTE_MS1,PORTE_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTE_MS2,PORTE_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTE_MS3,PORTE_PIN_MS3, GPIO_PIN_RESET);

	}

	else if(microStep==16)
	{
		HAL_GPIO_WritePin(PORTE_MS1,PORTE_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTE_MS2,PORTE_PIN_MS2, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTE_MS3,PORTE_PIN_MS3, GPIO_PIN_SET);

	}

	else if(microStep==32)
	{
		HAL_GPIO_WritePin(PORTE_MS1,PORTE_PIN_MS1, GPIO_PIN_SET);
			HAL_GPIO_WritePin(PORTE_MS2,PORTE_PIN_MS2, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(PORTE_MS3,PORTE_PIN_MS3, GPIO_PIN_SET);

	}

	else
	{
		parameterError(WRONG_MICROSTEP_ERROR);
		return;
	}
	deviceControl.stepPosition.stepE=((microStep*deviceControl.stepPosition.stepE)/deviceControl.microStepE);
	deviceControl.microStepE=microStep;
}



