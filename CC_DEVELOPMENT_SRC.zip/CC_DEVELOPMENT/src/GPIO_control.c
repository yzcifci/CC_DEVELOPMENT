/*
 * GPIO_control.c
 *
 *  Created on: 14 Oca 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"


void toggleX(char dirX)
{
	HAL_GPIO_WritePin(DIR_PORT_X1,DIR_PIN_X1, dirX);
	HAL_GPIO_WritePin(DIR_PORT_X2,DIR_PIN_X2, dirX);
	HAL_GPIO_TogglePin(PORT_X1,PIN_X1);
	HAL_GPIO_TogglePin(PORT_X2,PIN_X2);

#if MOVEMENT_TEST_ENABLE
	movementTestHandler(COORDINATE_X, dirX);
#endif

}

void toggleY(char dirY)
{
	HAL_GPIO_WritePin(DIR_PORT_Y,DIR_PIN_Y, dirY);
	HAL_GPIO_TogglePin(PORT_Y,PIN_Y);

#if MOVEMENT_TEST_ENABLE
	movementTestHandler(COORDINATE_Y, dirY);
#endif
}

void toggleZ(char dirZ)
{
	HAL_GPIO_WritePin(DIR_PORT_Z,DIR_PIN_Z, dirZ);
	HAL_GPIO_TogglePin(PORT_Z,PIN_Z);

#if MOVEMENT_TEST_ENABLE
	movementTestHandler(COORDINATE_Z, dirZ);
#endif
}

void stopMovement()
{
	HAL_GPIO_WritePin(PORT_X1,PIN_X1,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PORT_X2,PIN_X2,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PORT_Y,PIN_Y,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PORT_Z,PIN_Z,GPIO_PIN_RESET);
}


void startStep(char dirX,char dirY, char dirZ, uint16_t Tx,uint16_t Ty,uint16_t Tz)
{
	if(Tx)
	{
		HAL_GPIO_WritePin(DIR_PORT_X1,DIR_PIN_X1, dirX);
		HAL_GPIO_WritePin(DIR_PORT_X2,DIR_PIN_X2, dirX);
		HAL_GPIO_WritePin(PORT_X1,PIN_X1,GPIO_PIN_SET);
		HAL_GPIO_WritePin(PORT_X2,PIN_X2,GPIO_PIN_SET);
	}
	if(Ty)
	{
		HAL_GPIO_WritePin(DIR_PORT_Y,DIR_PIN_Y, dirY);
		HAL_GPIO_WritePin(PORT_Y,PIN_Y,GPIO_PIN_SET);
	}
	if(Tz)
	{
		HAL_GPIO_WritePin(DIR_PORT_Z,DIR_PIN_Z, dirZ);
		HAL_GPIO_WritePin(PORT_Z,PIN_Z,GPIO_PIN_SET);
	}


}



void initPorts()
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	/* Configure the PORT X1 pin */

	GPIO_InitStruct.Pin = PIN_X1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(PORT_X1);
	HAL_GPIO_Init(PORT_X1, &GPIO_InitStruct);
	HAL_GPIO_WritePin(PORT_X1,PIN_X1, GPIO_PIN_RESET);


	GPIO_InitStruct.Pin = PIN_X2;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(PORT_X2);
	HAL_GPIO_Init(PORT_X2, &GPIO_InitStruct);
	HAL_GPIO_WritePin(PORT_X2,PIN_X2, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = PIN_Y;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(PORT_Y);
	HAL_GPIO_Init(PORT_Y, &GPIO_InitStruct);
	HAL_GPIO_WritePin(PORT_Y,PIN_Y, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = PIN_Z;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(PORT_Z);
	HAL_GPIO_Init(PORT_Y, &GPIO_InitStruct);
	HAL_GPIO_WritePin(PORT_Z,PIN_Z, GPIO_PIN_RESET);



	/*ENABLE PORTS*/

	GPIO_InitStruct.Pin = ENABLE_PIN_X1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(ENABLE_PORT_X1);
	HAL_GPIO_Init(ENABLE_PORT_X1, &GPIO_InitStruct);
	HAL_GPIO_WritePin(ENABLE_PORT_X1,ENABLE_PIN_X1, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = ENABLE_PIN_X2;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(ENABLE_PORT_X2);
	HAL_GPIO_Init(ENABLE_PORT_X2, &GPIO_InitStruct);
	HAL_GPIO_WritePin(ENABLE_PORT_X2,ENABLE_PIN_X2, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = ENABLE_PIN_Y;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(ENABLE_PORT_Y);
	HAL_GPIO_Init(ENABLE_PORT_Y, &GPIO_InitStruct);
	HAL_GPIO_WritePin(ENABLE_PORT_Y,ENABLE_PIN_Y, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = ENABLE_PIN_Z;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(ENABLE_PORT_Z);
	HAL_GPIO_Init(ENABLE_PORT_Z, &GPIO_InitStruct);
	HAL_GPIO_WritePin(ENABLE_PORT_Z,ENABLE_PIN_Z, GPIO_PIN_RESET);


	/* DIRECTION PORTS*/

	GPIO_InitStruct.Pin = DIR_PIN_X1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(DIR_PORT_X1);
	HAL_GPIO_Init(DIR_PORT_X1, &GPIO_InitStruct);
	HAL_GPIO_WritePin(DIR_PORT_X1,DIR_PIN_X1, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = DIR_PIN_X2;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(DIR_PORT_X2);
	HAL_GPIO_Init(DIR_PORT_X2, &GPIO_InitStruct);
	HAL_GPIO_WritePin(DIR_PORT_X2,DIR_PIN_X2, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = DIR_PIN_Y;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(DIR_PORT_Y);
	HAL_GPIO_Init(DIR_PORT_Y, &GPIO_InitStruct);
	HAL_GPIO_WritePin(DIR_PORT_Y,DIR_PIN_Y, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = DIR_PIN_Z;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(DIR_PORT_Z);
	HAL_GPIO_Init(DIR_PORT_Z, &GPIO_InitStruct);
	HAL_GPIO_WritePin(DIR_PORT_Z,DIR_PIN_Z, GPIO_PIN_RESET);

	/* LASER ON OFF PORT INITIALISATION*/
	GPIO_InitStruct.Pin = LASER_SWITCH_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(LASER_SWITCH_PORT);
	HAL_GPIO_Init(LASER_SWITCH_PORT, &GPIO_InitStruct);
	HAL_GPIO_WritePin(LASER_SWITCH_PORT,LASER_SWITCH_PIN, GPIO_PIN_RESET);


	/* COOLANT PORT INITIALISATION*/
	GPIO_InitStruct.Pin = COOLANT_SWITCH_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_CLOCK_ENABLE(COOLANT_SWITCH_PORT);
	HAL_GPIO_Init(COOLANT_SWITCH_PORT, &GPIO_InitStruct);
	HAL_GPIO_WritePin(COOLANT_SWITCH_PORT,COOLANT_SWITCH_PIN, GPIO_PIN_RESET);


}


 void laserSwitch(uint8_t state)
 {
		HAL_GPIO_WritePin(LASER_SWITCH_PORT,LASER_SWITCH_PIN, state);
 }

 void coolantSwitch(uint8_t state)
 {
		HAL_GPIO_WritePin(COOLANT_SWITCH_PORT,COOLANT_SWITCH_PIN, GPIO_PIN_RESET);
 }


void GPIO_CLOCK_ENABLE(GPIO_TypeDef* GPIO)
{
	if(GPIO==GPIOA)__HAL_RCC_GPIOA_CLK_ENABLE();
	else if(GPIO==GPIOB)__HAL_RCC_GPIOB_CLK_ENABLE();
	else if(GPIO==GPIOC)__HAL_RCC_GPIOC_CLK_ENABLE();
	else if(GPIO==GPIOD)__HAL_RCC_GPIOD_CLK_ENABLE();
}

