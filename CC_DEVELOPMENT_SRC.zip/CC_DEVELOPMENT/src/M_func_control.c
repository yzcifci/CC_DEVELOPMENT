/*
 * M_func_control.c
 *
 *  Created on: 19 May 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct printerIOParameters_ printerIOParameters;

void M84_STOP_STEPPERS_IDLE_func()
{
	stopMovement();
}
uint8_t M190_SET_WAIT_BED_TEMP_func(char *parameter)
{
	static uint8_t parameterParsed=0;
	static uint16_t timeout=0;

	//TODO M190_SET_WAIT_BED_TEMP_func function rutrned for now
	return TASK_COMPLETED;

	if(!parameterParsed)
	{
		printerIOParameters.desiredBedTemp=*(uint16_t*)parameter;
		printerIOParameters.currentBedTemp=readExtruderTemp();
		timeout=0;
		parameterParsed=1;
	}

	if((printerIOParameters.currentBedTemp<printerIOParameters.desiredBedTemp)&&
			(timeout++<MAXIMUM_HEATBED_WAIT_TIME))
	{
		return TASK_RUNNING;
	}
	else if((timeout>=MAXIMUM_HEATBED_WAIT_TIME))
	{
		return TASK_EXECUTE_ERROR;
	}
	else
	{
		parameterParsed=0;
		return TASK_COMPLETED;
	}
}

void M104_SET_EXTRUDER_TEMP_func(char *parameter)
{

	printerIOParameters.desiredExturderTemp=*(int16_t*)parameter;
	if(printerIOParameters.desiredExturderTemp==0)
	{
		extruderHeaterOff();
		printerIOParameters.exturderHeatPeridoicControlEnable=0;
		return;
	}
	printerIOParameters.exturderHeatPeridoicControlEnable=1;

}


uint8_t M109_SET_WAIT_EXTRUDER_TEMP_func(char *parameter)
{
	static uint8_t parameterParsed=0;
	static uint16_t timeout=0;
	//TODO M190_SET_WAIT_BED_TEMP_func function rutrned for now
	return TASK_COMPLETED;



	if(!parameterParsed)
	{
		printerIOParameters.desiredExturderTemp=*(int16_t*)parameter;
		printerIOParameters.currentExturderTemp=readExtruderTemp();
		timeout=0;
		parameterParsed=1;
	}

	if((printerIOParameters.currentExturderTemp<printerIOParameters.desiredExturderTemp)&&
			(timeout++<MAXIMUM_EXTRUDER_HEAT_WAIT_TIME))
	{
		return TASK_RUNNING;
	}
	else if((timeout>=MAXIMUM_EXTRUDER_HEAT_WAIT_TIME))
	{
		return TASK_EXECUTE_ERROR;
	}
	else
	{
		parameterParsed=0;
		return TASK_COMPLETED;
	}

}

void M140_SET_BED_TEMP_func(char *parameter)
{

	printerIOParameters.desiredBedTemp=*(int16_t*)parameter;

	if(printerIOParameters.desiredBedTemp==0)
	{
		heatBedHeaterOff();
		printerIOParameters.bedHeatPeridoicControlEnable=0;
		return;
	}

	printerIOParameters.bedHeatPeridoicControlEnable=1;


}

uint8_t M107_FAN_OFF_func()
{
	extruderCoolerOff();
	return TASK_COMPLETED;
}

uint8_t M106_FAN_ON_func()
{
	extruderCoolerOn();
	return TASK_COMPLETED;
}


uint8_t M117_DISPLAY_MESSAGE_func(char* message)
{
	//todo M117_DISPLAY_MESSAGE_func will be inserted here
	return TASK_COMPLETED;

}

int16_t readBedTemp()
{
	int16_t index;
	int16_t temp;
	int16_t maxTemp=HEATBED_MAX_TEMP;
	index=binarySearch(heatbedNTCtable, sizeof(heatbedNTCtable)/2,ADC_control.readADCVal[0] );
	temp=index+HEATBED_MIN_TEMP;
	if(temp>maxTemp)
	{
		parameterError(HEATBED_TEMP_READ_ERROR);
	}
	return temp;
}

int16_t readExtruderTemp()
{
	int16_t index;
	int16_t temp;
	int16_t maxTemp=EXTRUDER_MAX_TEMP;
	index=binarySearch(extruderNTCtable, sizeof(extruderNTCtable)/2,ADC_control.readADCVal[1] );
	temp=index+EXTRUDER_MIN_TEMP;
	if(temp>maxTemp)
	{
		parameterError(EXTRUDER_TEMP_READ_ERROR);
	}
	return temp;
}

void extruderTempControl()
{
	printerIOParameters.currentExturderTemp=readExtruderTemp();
	if(printerIOParameters.currentExturderTemp<printerIOParameters.desiredExturderTemp-EXTRUDER_TEMP_HYSTER)
	{
		extruderHeaterOn();
	}
	else if(printerIOParameters.currentExturderTemp>printerIOParameters.desiredExturderTemp)
	{
		extruderHeaterOff();
	}
}

void bedTempControl()
{
	printerIOParameters.currentBedTemp=readBedTemp();
	if(printerIOParameters.currentBedTemp<printerIOParameters.desiredBedTemp-BED_TEMP_HYSTER)
	{
		heatBedHeaterOn();
	}
	else if(printerIOParameters.currentBedTemp>printerIOParameters.desiredBedTemp)
	{
		heatBedHeaterOff();
	}
}

void tempControl()
{
	if(ADC_control.readFlag==0)return;
	ADC_control.readFlag=0;
	if(printerIOParameters.exturderHeatPeridoicControlEnable)extruderTempControl();
	if(printerIOParameters.bedHeatPeridoicControlEnable)bedTempControl();

}


