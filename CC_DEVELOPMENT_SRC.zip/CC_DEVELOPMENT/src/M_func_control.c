/*
 * M_func_control.c
 *
 *  Created on: 19 May 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct printerIOParameters_ printerIOParameters;
uint8_t M190_SET_WAIT_BED_TEMP_func(char *parameter)
{
	static uint8_t parameterParsed=0;
	static uint16_t timeout=0;

	//TODO M190_SET_WAIT_BED_TEMP_func function rutrned for now
	return TASK_COMPLETED;

	if(!parameterParsed)
	{
		printerIOParameters.desiredBedTemp=*(uint16_t*)parameter;
		printerIOParameters.currentBedTemp=readExtruderTemp();
		timeout=0;
		parameterParsed=1;
	}

	if((printerIOParameters.currentBedTemp<printerIOParameters.desiredBedTemp)&&
			(timeout++<MAXIMUM_HEATBED_WAIT_TIME))
	{
		return TASK_RUNNING;
	}
	else if((timeout>=MAXIMUM_HEATBED_WAIT_TIME))
	{
		return TASK_EXECUTE_ERROR;
	}
	else
	{
		parameterParsed=0;
		return TASK_COMPLETED;
	}
}

void M104_SET_EXTRUDER_TEMP_func(char *parameter)
{

	printerIOParameters.desiredExturderTemp=*(uint16_t*)parameter;
	printerIOParameters.exturderHeatPeridoicControlEnable=1;

}


uint8_t M109_SET_WAIT_EXTRUDER_TEMP_func(char *parameter)
{
	static uint8_t parameterParsed=0;
	static uint16_t timeout=0;
	//TODO M190_SET_WAIT_BED_TEMP_func function rutrned for now
	return TASK_COMPLETED;



	if(!parameterParsed)
	{
		printerIOParameters.desiredExturderTemp=*(uint16_t*)parameter;
		printerIOParameters.currentExturderTemp=readExtruderTemp();
		timeout=0;
		parameterParsed=1;
	}

	if((printerIOParameters.currentExturderTemp<printerIOParameters.desiredExturderTemp)&&
			(timeout++<MAXIMUM_EXTRUDER_HEAT_WAIT_TIME))
	{
		return TASK_RUNNING;
	}
	else if((timeout>=MAXIMUM_EXTRUDER_HEAT_WAIT_TIME))
	{
		return TASK_EXECUTE_ERROR;
	}
	else
	{
		parameterParsed=0;
		return TASK_COMPLETED;
	}

}

uint8_t M107_FAN_OFF_func()
{
	extruderCoolerOff();
	return TASK_COMPLETED;
}


uint8_t M117_DISPLAY_MESSAGE_func(char* message)
{
	//todo M117_DISPLAY_MESSAGE_func will be inserted here
	return TASK_COMPLETED;

}

uint16_t readBedTemp()
{
	uint16_t readData;
	readData=printerIOParameters.readADCVal[0];
	return readData;
}

uint16_t readExtruderTemp()
{
	uint16_t readData;
	readData=printerIOParameters.readADCVal[1];
	return readData;
}

void extruderTempControl()
{
	printerIOParameters.currentExturderTemp=readExtruderTemp();
	if(printerIOParameters.currentExturderTemp<printerIOParameters.desiredExturderTemp-EXTRUDER_TEMP_HYSTER)
	{
		extruderHeaterOn();
	}
	else if(printerIOParameters.currentExturderTemp>printerIOParameters.desiredExturderTemp)
	{
		extruderHeaterOff();
	}
}

void bedTempControl()
{
	printerIOParameters.currentBedTemp=readExtruderTemp();
	if(printerIOParameters.currentBedTemp<printerIOParameters.desiredBedTemp-BED_TEMP_HYSTER)
	{
		heatBedHeaterOn();
	}
	else if(printerIOParameters.currentBedTemp>printerIOParameters.desiredBedTemp)
	{
		heatBedHeaterOff();
	}
}

void periodicADCread()
{
	if(((printerIOParameters.periodicADCcntr++)%5000)==0)
	{
		if(printerIOParameters.exturderHeatPeridoicControlEnable)extruderTempControl();
		if(printerIOParameters.bedHeatPeridoicControlEnable)bedTempControl();
		startADCconversions();
	}


}


void startADCconversions()
{
	if(HAL_ADC_Start_DMA(&hadc1, (uint32_t*)&printerIOParameters.readADCVal, 2) != HAL_OK)
	{
		/* Start Conversation Error */
		Error_Handler();
	}
}
