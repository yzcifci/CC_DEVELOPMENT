/*
 * M_func_control.c
 *
 *  Created on: 19 May 2018
 *      Author: yzcifci
 */

#include "main.h"

struct printerIOParameters_ printerIOParameters;

void M84_STOP_STEPPERS_IDLE_func()
{
	stopMovement();
}
uint8_t M190_SET_WAIT_BED_TEMP_func(char *parameter)
{
	static uint8_t parameterParsed=0;
	static uint32_t timeCaptured=0;
	static uint32_t dTime=0;

#if MOVEMENT_TEST_ENABLE
	printerIOParameters.heatBedSt=HEAT_BED_HEAT_OFF;
	return TASK_COMPLETED;
#endif

	if(!parameterParsed)
	{
		printerIOParameters.desiredBedTemp=*(int32_t*)parameter;
		printerIOParameters.currentBedTemp=readBedTemp();
		dTime=0;
		timeCaptured=0;
		parameterParsed=1;
		setHistHeatBed(0);
	}

	dTime=timerControl.globalCntr-timeCaptured;

	if((printerIOParameters.currentBedTemp<(printerIOParameters.desiredBedTemp))&&
			(dTime<MAXIMUM_HEATBED_WAIT_TIME))
	{
		// test start heat off
		printerIOParameters.heatBedSt=HEAT_BED_HEAT_UP;
		//		printerIOParameters.heatBedSt=HEAT_BED_HEAT_OFF;
		// test end
		return TASK_RUNNING;

	}
	else if((dTime>=MAXIMUM_HEATBED_WAIT_TIME))
	{
		printerIOParameters.heatBedSt=HEAT_BED_HEAT_OFF;
		// test start heat off
		//		return TASK_COMPLETED;
		return TASK_EXECUTE_ERROR;
		// test end
	}
	else
	{
		parameterParsed=0;
		printerIOParameters.heatBedSt=HEAT_BED_HEAT_STEADY;
		return TASK_COMPLETED;
	}
}

void M104_SET_EXTRUDER_TEMP_func(char *parameter)
{

	printerIOParameters.desiredExturderTemp=*(int32_t*)parameter;
	if(printerIOParameters.desiredExturderTemp==0)
	{
		extruderHeaterOff();
		printerIOParameters.heatExtSt=EXT_HEAT_OFF;
		return;
	}
	setHistHeatExt(0);
	printerIOParameters.heatExtSt=EXT_HEAT_STEADY;

}

void M105_REQUEST_TEMP_func(char *parameter)
{
	/*
	 * temperatures will be returned here
	 */
}


uint8_t M109_SET_WAIT_EXTRUDER_TEMP_func(char *parameter)
{
	static uint8_t parameterParsed=0;
	static uint32_t dTime=0;
	static uint32_t timeCaptured=0;

#if MOVEMENT_TEST_ENABLE
	printerIOParameters.heatExtSt=EXT_HEAT_OFF;
	return TASK_COMPLETED;
#endif


	if(!parameterParsed)
	{
		printerIOParameters.desiredExturderTemp=*(int32_t*)parameter;
		printerIOParameters.currentExturderTemp=readExtruderTemp();
		dTime=0;
		timeCaptured=timerControl.globalCntr;
		parameterParsed=1;
		setHistHeatExt(0);
	}

	dTime=timerControl.globalCntr-timeCaptured;
	if((printerIOParameters.currentExturderTemp<printerIOParameters.desiredExturderTemp)&&
			(dTime<MAXIMUM_EXTRUDER_HEAT_WAIT_TIME))
	{
		// test start heat off
		//		printerIOParameters.heatExtSt=EXT_HEAT_OFF;
		printerIOParameters.heatExtSt=EXT_HEAT_UP;
		// test end
		return TASK_RUNNING;
	}
	else if((dTime>=MAXIMUM_EXTRUDER_HEAT_WAIT_TIME))
	{
		// test start heat
		//		return TASK_COMPLETED;
		return TASK_EXECUTE_ERROR;
		// test end
	}
	else
	{
		parameterParsed=0;
		printerIOParameters.heatExtSt=EXT_HEAT_STEADY;
		return TASK_COMPLETED;
	}

}

void M140_SET_BED_TEMP_func(char *parameter)
{

	printerIOParameters.desiredBedTemp=*(int32_t*)parameter;
	if(printerIOParameters.desiredBedTemp==0)
	{
		heatBedHeaterOff();
		printerIOParameters.heatBedSt=HEAT_BED_HEAT_OFF;
		return;
	}

	// TEST START HEATERS OFF
	printerIOParameters.heatBedSt=HEAT_BED_HEAT_STEADY;
	//	printerIOParameters.heatBedSt=HEAT_BED_HEAT_OFF;
	// TEST END
	setHistHeatBed(0);


}

uint8_t M107_FAN_OFF_func()
{
	extruderCoolerOff();
	return TASK_COMPLETED;
}

uint8_t M106_FAN_ON_func()
{
	extruderCoolerOn();
	return TASK_COMPLETED;
}


uint8_t M117_DISPLAY_MESSAGE_func(char* message)
{
	//todo M117_DISPLAY_MESSAGE_func will be inserted here
	return TASK_COMPLETED;

}

