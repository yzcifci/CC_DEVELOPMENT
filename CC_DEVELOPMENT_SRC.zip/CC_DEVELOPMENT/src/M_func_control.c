/*
 * M_func_control.c
 *
 *  Created on: 19 May 2018
 *      Author: yzcifci
 */

#include "main.h"

struct printerIOParameters_ printerIOParameters;

void M84_STOP_STEPPERS_IDLE_func()
{
	stopMovement();
}
uint8_t M190_SET_WAIT_BED_TEMP_func(char *parameter)
{
	static uint8_t parameterParsed=0;
	static uint16_t timeout=0;

	//TODO M190_SET_WAIT_BED_TEMP_func function rutrned for now
//		return TASK_COMPLETED;
	if(!parameterParsed)
	{
		printerIOParameters.desiredBedTemp=*(int32_t*)parameter;
		printerIOParameters.currentBedTemp=readBedTemp();
		timeout=0;
		parameterParsed=1;
		setHistHeatBed(0);
	}

	if((printerIOParameters.currentBedTemp<(printerIOParameters.desiredBedTemp))&&
			(timeout++<MAXIMUM_HEATBED_WAIT_TIME))
	{
		printerIOParameters.heatBedSt=HEAT_BED_HEAT_UP;
		return TASK_RUNNING;

	}
	else if((timeout>=MAXIMUM_HEATBED_WAIT_TIME))
	{
		printerIOParameters.heatBedSt=HEAT_BED_HEAT_OFF;
		return TASK_EXECUTE_ERROR;
	}
	else
	{
		parameterParsed=0;
		printerIOParameters.heatBedSt=HEAT_BED_HEAT_STEADY;
		return TASK_COMPLETED;
	}
}

void M104_SET_EXTRUDER_TEMP_func(char *parameter)
{

	printerIOParameters.desiredExturderTemp=*(int32_t*)parameter;
	if(printerIOParameters.desiredExturderTemp==0)
	{
		extruderHeaterOff();
		printerIOParameters.heatExtSt=EXT_HEAT_OFF;
		return;
	}
	setHistHeatExt(0);
	printerIOParameters.heatExtSt=EXT_HEAT_STEADY;

}

void M105_REQUEST_TEMP_func(char *parameter)
{
	/*
	 * temperatures will be returned here
	 */
}


uint8_t M109_SET_WAIT_EXTRUDER_TEMP_func(char *parameter)
{
	static uint8_t parameterParsed=0;
	static uint16_t timeout=0;
	//TODO M190_SET_WAIT_BED_TEMP_func function rutrned for now
//		return TASK_COMPLETED;



	if(!parameterParsed)
	{
		printerIOParameters.desiredExturderTemp=*(int32_t*)parameter;
		printerIOParameters.currentExturderTemp=readExtruderTemp();
		timeout=0;
		parameterParsed=1;
		setHistHeatExt(0);
	}

	if((printerIOParameters.currentExturderTemp<printerIOParameters.desiredExturderTemp)&&
			(timeout++<MAXIMUM_EXTRUDER_HEAT_WAIT_TIME))
	{
		printerIOParameters.heatExtSt=EXT_HEAT_UP;
		return TASK_RUNNING;
	}
	else if((timeout>=MAXIMUM_EXTRUDER_HEAT_WAIT_TIME))
	{
		return TASK_EXECUTE_ERROR;
	}
	else
	{
		parameterParsed=0;
		printerIOParameters.heatExtSt=EXT_HEAT_STEADY;
		return TASK_COMPLETED;
	}

}

void M140_SET_BED_TEMP_func(char *parameter)
{

	printerIOParameters.desiredBedTemp=*(int32_t*)parameter;
	if(printerIOParameters.desiredBedTemp==0)
	{
		heatBedHeaterOff();
		printerIOParameters.heatBedSt=HEAT_BED_HEAT_OFF;
		return;
	}
	printerIOParameters.heatBedSt=HEAT_BED_HEAT_STEADY;
	setHistHeatBed(0);


}

uint8_t M107_FAN_OFF_func()
{
	extruderCoolerOff();
	return TASK_COMPLETED;
}

uint8_t M106_FAN_ON_func()
{
	extruderCoolerOn();
	return TASK_COMPLETED;
}


uint8_t M117_DISPLAY_MESSAGE_func(char* message)
{
	//todo M117_DISPLAY_MESSAGE_func will be inserted here
	return TASK_COMPLETED;

}

