/*
 * stepper.h
 *
 *  Created on: 27 ?ub 2019
 *      Author: yzcifci
 */

#ifndef STEPPER_H_
#define STEPPER_H_

enum
{
	SPEED_UP,
	STEADY,
	BRAKE,
	NONE
};

extern struct stepStruct_
{
	uint8_t moveState;
	parserAssign parsData;

	uint32_t cntr;

	uint8_t refCoordinate;

	uint32_t halfStepCntrX;
	uint32_t halfStepCntrY;
	uint32_t halfStepCntrZ;
	uint32_t halfStepCntrE;
	uint32_t halfStepCntrRef;

	uint32_t cntrtx;
	uint32_t cntrty;
	uint32_t cntrtz;
	uint32_t cntrte;

	float tx;
	float ty;
	float tz;
	float te;

	float fx;
	float fy;
	float fz;
	float fe;

	float toggletx;
	float togglety;
	float toggletz;
	float togglete;
	float toggleT;

	uint8_t stepCallTx;
	uint8_t stepCallTy;
	uint8_t stepCallTz;
	uint8_t stepCallTe;


	float txFract;
	float tyFract;
	float tzFract;
	float teFract;

	uint32_t stepX;
	uint32_t stepY;
	uint32_t stepZ;
	uint32_t stepE;

	uint8_t isSpeedUp;
	uint8_t isSteady;
	uint8_t isBrake;


	float minT;
	float multTX;
	float multTY;
	float multTZ;
	float multTE;



}stepStruct;


typedef struct
{
	float x;
	float y;
	float z;
	float e;

	float tx;
	float ty;
	float tz;

	float toggletx;
	float togglety;
	float toggletz;

	float toggleT;

	float feed;

}G28Struct_;



/*
 * stepper.c
 *
 *  Created on: 27 ?ub 2019
 *      Author: yzcifci
 */


struct stepStruct_ stepStruct;
uint8_t startMove(char *parameter);
uint8_t stepperMoveCall();
uint8_t toggleXCallback();
uint8_t toggleYCallback();
uint8_t toggleZCallback();
uint8_t toggleECallback();
void moveStepAccelerate(uint8_t coordinate);
uint8_t checkMoveEnd();
uint8_t G28_MOVE_TO_ORIGIN_callBack(void);
float getPulsePeriodTx(float feed);
float getPulsePeriodTy(float feed);
float getPulsePeriodTz(float feed);
float getPulsePeriodTe(float feed);
void setEndFeeds();

uint8_t G28_MOVE_TO_ORIGIN_func(char *parameters);
void setAccelerationTurn();
uint8_t moveTaskIdle(void);


#endif /* STEPPER_H_ */
