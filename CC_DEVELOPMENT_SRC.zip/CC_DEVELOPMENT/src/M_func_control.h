/*
 * M_func_control.h
 *
 *  Created on: 19 May 2018
 *      Author: yzcifci
 */

#ifndef M_FUNC_CONTROL_H_
#define M_FUNC_CONTROL_H_

/*
 * M_func_control.c
 *
 *  Created on: 19 May 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct printerIOParameters_ printerIOParameters;


extern struct printerIOParameters_
{
	int16_t desiredBedTemp;
	int16_t currentBedTemp;
	int16_t desiredExturderTemp;
	int16_t currentExturderTemp;

	uint8_t bedHeatPeridoicControlEnable;
	uint8_t exturderHeatPeridoicControlEnable;



}printerIOParameters;


uint8_t M190_SET_WAIT_BED_TEMP_func(char *parameter);
void  M104_SET_EXTRUDER_TEMP_func(char *parameter);
uint8_t M109_SET_WAIT_EXTRUDER_TEMP_func(char *parameter);
uint8_t M106_FAN_ON_func();
uint8_t M107_FAN_OFF_func();
uint8_t M117_DISPLAY_MESSAGE_func(char* message);
void M140_SET_BED_TEMP_func(char *parameter);
int16_t readBedTemp();
int16_t readExtruderTemp();
void extruderTempControl();
void bedTempControl();
void tempControl();
#endif /* M_FUNC_CONTROL_H_ */
