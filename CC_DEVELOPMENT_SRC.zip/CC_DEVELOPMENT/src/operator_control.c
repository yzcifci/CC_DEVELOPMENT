/*
 * operator_control.c
 *
 *  Created on: 24 May 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"
struct deviceControl_ deviceControl;
struct taskControl_ taskControl;

void taskOperatorControl()
{

	if(parser.tailHeadDiff)
	{

		switch(parser.parameters[parser.tail].task)
		{
		case G00_RAPID_MOVEMENT:
			if(taskControl.taskStatus!=TASK_RUNNING)
				taskControl.taskStatus=startLinearInterPolation((char*)&parser.parameters[parser.tail]);
			else
			{
				taskControl.taskStatus=linearInterPolationPeriodicCall();
			}
			break;
		case G01_LINEAR_INTERPOLATION:
			if(taskControl.taskStatus!=TASK_RUNNING)
				taskControl.taskStatus=startLinearInterPolation((char*)&parser.parameters[parser.tail]);
			else
			{
				taskControl.taskStatus=linearInterPolationPeriodicCall();
			}
			break;
		case G20_INCHES_MODE:
			deviceControl.lengthMode=INCHES_MODE;
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G21_METRIC_MODE:
			deviceControl.lengthMode=METRIC_MODE;
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G28_MOVE_TO_ORIGIN:
			if(taskControl.taskStatus!=TASK_RUNNING)
				taskControl.taskStatus=startLinearInterPolation((char*)&parser.parameters[parser.tail]);
			else
			{
				taskControl.taskStatus=linearInterPolationPeriodicCall();
			}
			break;

		case G90_ABSOLUTE_MODE_SELECT:
			deviceControl.lengthMode=ABSOLUTE_MODE;
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G91_INCREMENTAL_MODE_SELECT:
			deviceControl.incrementalMode=INCREMENTAL_MODE;
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G92_SET_POSITION:
			G92_SET_POSITION_func((char*)&parser.parameters[parser.tail]);
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M82_SET_EXTRUDER_ABSOLUTE_MODE:
			deviceControl.ExtruderIncrementalMode=ABSOLUTE_MODE;
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M104_SET_EXTRUDER_TEMP:
			M104_SET_EXTRUDER_TEMP_func((char*)&parser.parameters[parser.tail]);
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M107_FAN_OFF:
			M107_FAN_OFF_func();
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M117_DISPLAY_MESSAGE:
			taskControl.taskStatus= M117_DISPLAY_MESSAGE_func((char*)&parser.parameters[parser.tail]);
			break;

		case M109_SET_WAIT_EXTRUDER_TEMP:
			taskControl.taskStatus=M109_SET_WAIT_EXTRUDER_TEMP_func((char*)&parser.parameters[parser.tail]);
			break;
		case M190_SET_WAIT_BED_TEMP:
			taskControl.taskStatus=M190_SET_WAIT_BED_TEMP_func((char*)&parser.parameters[parser.tail]);
			break;

		}
		tailUpdateControl();
	}
}

void tailUpdateControl()
{
	if(taskControl.taskStatus==TASK_COMPLETED)
	{
		parser.tail++;
		if(parser.tail>=MAX_BUFFERED_TASK)parser.tail=0;
		if(parser.tailHeadDiff!=0)
		{
			parser.tailHeadDiff--;
		}
		else
		{
			parserError(TAIL_HEAD_DIFF_ERROR);
		}

	}

	if(parser.tailHeadDiff>=(MAX_BUFFERED_TASK-1))
	{
		parser.bufferStatus=BUFFER_FULL;
	}
	else
	{
		parser.bufferStatus=BUFFER_NOT_FULL;
	}
}


void initSystem()
{
	initializeParser();
	initTaskOperator();
	initPorts();
	initTimer();
	initSerialCom();
}



void initTaskOperator()
{
	memset(&taskControl, 0x0, sizeof(taskControl));
}


void G92_SET_POSITION_func(char*parameter)
{
	positionXYZE position;
	memcpy(&position,parameter,sizeof(position));


	if(*(uint32_t*)&parameter[0]!=0xffffffff)deviceControl.stepPosition.stepX=mmToStepX(position.X);;
	if(*(uint32_t*)&parameter[4]!=0xffffffff)deviceControl.stepPosition.stepY=mmToStepY(position.Y);
	if(*(uint32_t*)&parameter[8]!=0xffffffff)deviceControl.stepPosition.stepZ=mmToStepZ(position.Z);
	if(*(uint32_t*)&parameter[12]!=0xffffffff)deviceControl.stepPosition.stepE=mmToStepE(position.E);

}
