/*
 * operator_control.c
 *
 *  Created on: 24 May 2018
 *      Author: yzcifci
 */

#include "main.h"
struct deviceControl_ deviceControl;
struct taskControl_ taskControl;

void taskOperatorControl()
{
	if(parser.workableTailHeadDiff)
	{
		switch(parser.parameters[parser.tail].task)
		{
		case G00_RAPID_MOVEMENT:
			if(taskControl.taskStatus!=TASK_RUNNING)
				taskControl.taskStatus=startMove((char*)&parser.parameters[parser.tail]);
			else
			{
//				taskControl.taskStatus=steppergetTaskStatus();
			}
			break;
		case G01_LINEAR_INTERPOLATION:
			if(taskControl.taskStatus!=TASK_RUNNING)
				taskControl.taskStatus=startMove((char*)&parser.parameters[parser.tail]);
			else
			{
//				taskControl.taskStatus=steppergetTaskStatus();
			}
			break;
		case G20_INCHES_MODE:
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G21_METRIC_MODE:
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G28_MOVE_TO_ORIGIN:
			if(taskControl.taskStatus!=TASK_RUNNING)
				taskControl.taskStatus=G28_MOVE_TO_ORIGIN_func((char*)&parser.parameters[parser.tail]);
			else
			{
//				taskControl.taskStatus=steppergetTaskStatus();
			}
			break;

		case G90_ABSOLUTE_MODE_SELECT:
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G91_INCREMENTAL_MODE_SELECT:
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G92_SET_POSITION:
			resetExtruderLength();
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M82_SET_EXTRUDER_ABSOLUTE_MODE:
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M84_STOP_STEPPERS_IDLE:
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M104_SET_EXTRUDER_TEMP:
			M104_SET_EXTRUDER_TEMP_func((char*)&parser.parameters[parser.tail]);
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M105_REQUEST_TEMP:
			M105_REQUEST_TEMP_func((char*)&parser.parameters[parser.tail]);
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case M106_FAN_ON:
			M106_FAN_ON_func();
			taskControl.taskStatus=TASK_COMPLETED;
			break;


		case M107_FAN_OFF:
			M107_FAN_OFF_func();
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M109_SET_WAIT_EXTRUDER_TEMP:
			taskControl.taskStatus=M109_SET_WAIT_EXTRUDER_TEMP_func((char*)&parser.parameters[parser.tail]);
			break;

		case M117_DISPLAY_MESSAGE:
			taskControl.taskStatus= M117_DISPLAY_MESSAGE_func((char*)&parser.parameters[parser.tail]);
			break;


		case M140_SET_BED_TEMP:
			M140_SET_BED_TEMP_func((char*)&parser.parameters[parser.tail]);
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case M190_SET_WAIT_BED_TEMP:
			taskControl.taskStatus=M190_SET_WAIT_BED_TEMP_func((char*)&parser.parameters[parser.tail]);
			break;

		case M204_SET_ACCELERATION:
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		}
		tailUpdateControl();
	}
}

void tailUpdateControl()
{
	if(taskControl.taskStatus==TASK_COMPLETED)
	{
		parser.tail++;
		if(parser.tail>=PARSER_PARAMETER_SIZE)parser.tail=0;
		if(parser.tailHeadDiff!=0)
		{
			parser.tailHeadDiff--;
		}
		else
		{
			parserError(TAIL_HEAD_DIFF_ERROR);
		}

		if(parser.workableTailHeadDiff!=0)
		{
			parser.workableTailHeadDiff--;
		}
		else
		{
			parserError(TAIL_HEAD_DIFF_ERROR);
		}

	}

	if(parser.tailHeadDiff>=(PARSER_PARAMETER_SIZE-1))
	{
		parser.bufferStatus=BUFFER_FULL;
	}
	else
	{
		parser.bufferStatus=BUFFER_NOT_FULL;
	}
}


void initSystem()
{
	initSystemParameters();
	initPorts();
	initFatfs();
	ADC_Init();
	initTimer();



#if MOVEMENT_TEST_ENABLE
	initSerialCom();
#endif

}



void initTaskOperator()
{
	memset(&taskControl, 0x0, sizeof(taskControl));
}





void systemOFF()
{
	stopMovement();
	extruderCoolerOff();
	heatBedHeaterOff();
	extruderHeaterOff();
}



void initSystemParameters()
{
	memset(&printerIOParameters,0,sizeof(printerIOParameters));
	initAccelerationControlUnit();
    initTaskOperator();
	initializeParser();
}

void resetExtruderLength()
{
	printerIOParameters.position.mmPosition.E=0;
	printerIOParameters.position.stepPosition.stepE=0;

}


void errorLog(uint16_t errorIndex)
{
	systemOFF();
	while(1);
}
