/*
 * operator_control.c
 *
 *  Created on: 24 May 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"
struct deviceControl_ deviceControl;
struct taskControl_ taskControl;

void taskOperatorControl()
{

	if(parser.workableTailHeadDiff)
	{

		switch(parser.parameters[parser.tail].task)
		{
		case G00_RAPID_MOVEMENT:
			if(taskControl.taskStatus!=TASK_RUNNING)
				taskControl.taskStatus=startMove((char*)&parser.parameters[parser.tail]);
			else
			{
				taskControl.taskStatus=steppergetTaskStatus();
			}
			break;
		case G01_LINEAR_INTERPOLATION:
			if(taskControl.taskStatus!=TASK_RUNNING)
				taskControl.taskStatus=startMove((char*)&parser.parameters[parser.tail]);
			else
			{
				taskControl.taskStatus=steppergetTaskStatus();
			}
			break;
		case G20_INCHES_MODE:
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G21_METRIC_MODE:
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G28_MOVE_TO_ORIGIN:
			if(taskControl.taskStatus!=TASK_RUNNING)
				taskControl.taskStatus=G28_MOVE_TO_ORIGIN_func((char*)&parser.parameters[parser.tail]);
			else
			{
				taskControl.taskStatus=steppergetTaskStatus();
			}
			break;

		case G90_ABSOLUTE_MODE_SELECT:
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G91_INCREMENTAL_MODE_SELECT:
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case G92_SET_POSITION:
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M82_SET_EXTRUDER_ABSOLUTE_MODE:
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M84_STOP_STEPPERS_IDLE:
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M104_SET_EXTRUDER_TEMP:
			M104_SET_EXTRUDER_TEMP_func((char*)&parser.parameters[parser.tail]);
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M106_FAN_ON:
			M106_FAN_ON_func();
			taskControl.taskStatus=TASK_COMPLETED;
			break;


		case M107_FAN_OFF:
			M107_FAN_OFF_func();
			taskControl.taskStatus=TASK_COMPLETED;
			break;

		case M109_SET_WAIT_EXTRUDER_TEMP:
			taskControl.taskStatus=M109_SET_WAIT_EXTRUDER_TEMP_func((char*)&parser.parameters[parser.tail]);
			break;

		case M117_DISPLAY_MESSAGE:
			taskControl.taskStatus= M117_DISPLAY_MESSAGE_func((char*)&parser.parameters[parser.tail]);
			break;


		case M140_SET_BED_TEMP:
			M140_SET_BED_TEMP_func((char*)&parser.parameters[parser.tail]);
			taskControl.taskStatus=TASK_COMPLETED;
			break;
		case M190_SET_WAIT_BED_TEMP:
			taskControl.taskStatus=M190_SET_WAIT_BED_TEMP_func((char*)&parser.parameters[parser.tail]);
			break;

		}
		tailUpdateControl();
	}

	periodicADCConvertCall();
	tempBedPWMOutCntrl();
	tempExtPWMOutCntrl();


}

void tailUpdateControl()
{
	if(taskControl.taskStatus==TASK_COMPLETED)
	{
		parser.tail++;
		if(parser.tail>=PARSER_PARAMETER_SIZE)parser.tail=0;
		if(parser.tailHeadDiff!=0)
		{
			parser.tailHeadDiff--;
		}
		else
		{
			parserError(TAIL_HEAD_DIFF_ERROR);
		}

		if(parser.workableTailHeadDiff!=0)
		{
			parser.workableTailHeadDiff--;
		}
		else
		{
			parserError(TAIL_HEAD_DIFF_ERROR);
		}

	}

	if(parser.tailHeadDiff>=(PARSER_PARAMETER_SIZE-1))
	{
		parser.bufferStatus=BUFFER_FULL;
	}
	else
	{
		parser.bufferStatus=BUFFER_NOT_FULL;
	}
}


void initSystem()
{
	initPorts();
	initFatfs();
	initializeParser();
	initTaskOperator();

	ADC_Init();
	initTimer();
	// test start PA2 PA3 UART pinleri y motor ms pinleri ile çakışmaktadır
	initSerialCom();
	// test end

}



void initTaskOperator()
{
	memset(&taskControl, 0x0, sizeof(taskControl));
}


void G92_SET_POSITION_func(char*parameter)
{
	positionXYZE position;
	memcpy(&position,parameter,sizeof(position));


	if(*(uint32_t*)&parameter[0]!=0xffffffff)deviceControl.stepPosition.stepX=mmToStepX(position.X);
	if(*(uint32_t*)&parameter[4]!=0xffffffff)deviceControl.stepPosition.stepY=mmToStepY(position.Y);
	if(*(uint32_t*)&parameter[8]!=0xffffffff)deviceControl.stepPosition.stepZ=mmToStepZ(position.Z);
	if(*(uint32_t*)&parameter[12]!=0xffffffff)deviceControl.stepPosition.stepE=mmToStepE(position.E);

}



uint16_t binarySearch(uint16_t* array, uint16_t size, uint16_t search)
{
	uint16_t first, last, middle;

	if(search>array[size-1])return (size-1);
	else if(search<array[0])
		return 0;
	first = 0;
	last = size - 1;
	middle = (first+last)/2;

	while (first <= last)
	{
		if((array[middle]<search) && (search<array[middle+1]))
		{
			if((search-array[middle])>(array[middle+1]-search))
			{
				return middle+1;
			}
			else
			{
				return middle;
			}
		}

		else if (array[middle] < search)
		{
			first = middle + 1;
		}
		else if (array[middle] == search)
		{
			return middle;
		}

		else
			last = middle - 1;

		middle = (first + last)/2;
	}
	if (first > last)
		parameterError(BINARY_SEARCH_INDEX_ERROR);

	return 0;
}



void systemOFF()
{
	stopMovement();
	extruderCoolerOff();
	heatBedHeaterOff();
	extruderHeaterOff();
}


void systemExecuter()
{
	fatfsParser();
	tempControl();
}


/*
uint8_t G28_MOVE_TO_ORIGIN_func(char *parameters)
{
	// test start movement test
	return TASK_COMPLETED;
	//test end
	static uint8_t state=0;
	static uint8_t taskStatus;
	static uint32_t cntr=0;

	static uint32_t Tx;
	static uint32_t Ty;
	static uint32_t Tz;

	static uint8_t flagX=0;
	static uint8_t flagY=0;
	static uint8_t flagZ=0;


	switch (state)
	{
	case 0:
		taskStatus=0xff;

		if(*(uint32_t*)&parameters[0]!=0xffffffff)flagX=1;
		if(*(uint32_t*)&parameters[4]!=0xffffffff)flagY=1;
		if(*(uint32_t*)&parameters[8]!=0xffffffff)flagZ=1;

		if(((readLimitSwitchX()==LIMIT_SWITCH_PRESSED)||(flagX==0))&&
				((readLimitSwitchY()==LIMIT_SWITCH_PRESSED)||(flagY==0))&&
				((readLimitSwitchZ()==LIMIT_SWITCH_PRESSED)||(flagZ==0)))
		{
			resetPositions(flagX, flagY, flagZ);
			state=2;
			break;
		}
		else
		{
			Tx=getPulsePeriodX(MAXIMUM_START_STOP_FEED_RATE);
			Ty=getPulsePeriodY(MAXIMUM_START_STOP_FEED_RATE);
			Tz=getPulsePeriodZ(MAXIMUM_START_STOP_FEED_RATE_Z);

			cntr++;
			if(((cntr%(Tx/2))==0)&& (readLimitSwitchX()==LIMIT_SWITCH_NOT_PRESSED)&&(flagX==1))toggleX(0);
			if(((cntr%(Ty/2))==0)&& (readLimitSwitchY()==LIMIT_SWITCH_NOT_PRESSED)&&(flagY==1))toggleY(0);
			if(((cntr%(Tz/2))==0)&& (readLimitSwitchZ()==LIMIT_SWITCH_NOT_PRESSED)&&(flagZ==1))toggleZ(0);
		}
		state=1;

		break;
	case 1:
		if(((readLimitSwitchX()==LIMIT_SWITCH_PRESSED)||(flagX==0))&&
				((readLimitSwitchY()==LIMIT_SWITCH_PRESSED)||(flagY==0))&&
				((readLimitSwitchZ()==LIMIT_SWITCH_PRESSED)||(flagZ==0)))
		{
			resetPositions(flagX, flagY, flagZ);
			state=2;
			break;
		}
		else
		{
			cntr++;
			if(((cntr%(Tx/2))==0)&& (readLimitSwitchX()==LIMIT_SWITCH_NOT_PRESSED)&&(flagX==1))toggleX(0);
			if(((cntr%(Ty/2))==0)&& (readLimitSwitchY()==LIMIT_SWITCH_NOT_PRESSED)&&(flagY==1))toggleY(0);
			if(((cntr%(Tz/2))==0)&& (readLimitSwitchZ()==LIMIT_SWITCH_NOT_PRESSED)&&(flagZ==1))toggleZ(0);
		}
		state=1;
		break;
	case 2:
		taskStatus=startLinearInterPolation(parameters);
		if(taskStatus!=TASK_COMPLETED)state=3;
		break;
	case 3:
		taskStatus=linearInterPolationPeriodicCall();
		break;

	}

	if(taskStatus==TASK_COMPLETED)
	{

		Tx=0;
		Ty=0;
		Tz=0;
		flagX=0;
		flagY=0;
		flagZ=0;
		state=0;
		cntr=0;
	}

	return taskStatus;

}


void resetPositions(uint8_t x, uint8_t y, uint8_t z)
{
	if(x)
	{
		deviceControl.mmPosition.X=0;
		deviceControl.stepPosition.stepX=0;
	}
	if(y)
	{
		deviceControl.mmPosition.Y=0;
		deviceControl.stepPosition.stepY=0;
	}
	if(z)
	{
		deviceControl.mmPosition.Z=0;
		deviceControl.stepPosition.stepZ=0;
	}
	resetPinMovementPinStates();
}
 */
