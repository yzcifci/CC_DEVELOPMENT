/*
 * operator_control.c
 *
 *  Created on: 24 May 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"
 struct deviceControl_ deviceControl;
 struct taskControl_ taskControl;

void taskOperatorControl()
{

	if(parser.head!=parser.tail)
	{
		switch(parser.parameters[parser.tail].task)
		{
			case G00_RAPID_MOVEMENT:
				//todo

				if(taskControl.taskStatus!=TASK_RUNNING)
				{
					taskControl.taskStatus=startLinearInterPolation(parser.parameters[parser.tail].parameter);
				}
				else
				{
					taskControl.taskStatus=linearInterPolationPeriodicCall();
				}

				if(taskControl.taskStatus==TASK_COMPLETED)
				{
					parser.tail++;
				}
				break;
		}
	}
}




void initSystem()
{
	initializeParser();
	initTaskOperator();
	initPorts();
	initTimer();
	initSerialCom();
}



void initTaskOperator()
{
	memset(&taskControl, 0x0, sizeof(taskControl));
}
