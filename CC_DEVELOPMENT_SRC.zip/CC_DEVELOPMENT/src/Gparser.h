/*
 * Gparser.h
 *
 *  Created on: 10 Oca 2018
 *      Author: yzcifci
 */

#ifndef GPARSER_H_
#define GPARSER_H_

#include "stm32f4xx_hal.h"
#include "parameters.h"

#define CHECK_BIG(STATE1,STATE2) ((STATE1)>=(STATE2)? (1):(0))
#define MAX(x,y) ((x) > (y) ? (x) : (y))






typedef enum
{
	CIRCULAR_INTERPOLATION_I_J_TYPE,
	CIRCULAR_INTERPOLATION_R_TYPE
}CIRCULAR_INTERPOLATION_PARAMETER_TYPE;

typedef enum
{
	LINE_NUMBER_INACTIVE,
	LINE_NUMBER_ACTIVE
}islineNumberUsed;

enum
{
	BUFFER_NOT_FULL,
	BUFFER_FULL

};



typedef struct
{
	CIRCULAR_INTERPOLATION_PARAMETER_TYPE paramaterType;
	float X;
	float Y;
	float I;
	float J;
	float radius;
	float feedRate;
}circularParameterPrototype;

extern struct parser_
{
	struct
	{
		char parameter[128];
		uint16_t task;
	}parameters[PARSER_PARAMETER_SIZE];

	uint8_t tail;
	uint8_t head;
	uint8_t tailHeadDiff;

	uint8_t workableTailHeadDiff;
	uint8_t workableHead;

	uint8_t processTailHeadDiff;
	uint8_t bufferStatus;
}parser;

extern struct test_
{
	uint32_t data;
	uint32_t formerdata;
	uint32_t tailHeadDiff;
	uint32_t formertailHeadDiff;
	uint8_t bufferStatus;
	uint8_t formerbufferStatus;
}test;

uint8_t pars(char *data);
void parameterParse(char *data);






void initializeParser();
uint8_t mainParser(uint8_t *Gline);
void prepareParserLine(uint8_t *Gline);
void taskParameterParser(char *taskData);
void lineIndexer(char *data);
void modalTaskPostParser(char taskParameter, char task, uint16_t number);
void modalTaskPreParser(char character);
void setSpeed(float speed);
void setSparameter(uint16_t value);
void setToolParameter(uint8_t tool);
void assignXaxis(float val);
void assignYaxis(float val);
void assignZaxis(float val);
void assignExtruder(float val);
void getPrePositionParameters(char coordinate, float val);
void assignCircularInterPolationParameterType(char task);
void assignIparameter(float val);
void assignJparameter(float val);
void assignRadiusParameter(float val);
void assignFeedRateParameter(float val);
void taskIndexer(uint8_t task);
uint16_t getTask(char* taskData);
void assignFeedRate(float feedRate, char modalTask);
void isTaskLineUsed(uint8_t *Gline);
void lineSplit(uint8_t* line);
void initGpaser();
void resetGpaser();
void parserError(uint8_t errorIndex);
void initSubParser(uint16_t index);




#endif /* GPARSER_H_ */
