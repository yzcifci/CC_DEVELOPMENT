/*
 * Gparser.h
 *
 *  Created on: 10 Oca 2018
 *      Author: yzcifci
 */

#include "parameters.h"
#ifndef GPARSER_H_
#define GPARSER_H_

#define MAX_ITEM_NUMBER 64  //must be size of char or uint16
#define CHECK_BIG(STATE1,STATE2) ((STATE1)>=(STATE2)? (1):(0))
#define MAX(x,y) ((x) > (y) ? (x) : (y))



enum
{
	MAXIMUM_WORD_SPLIT_ERROR,
	MAXIMUM_WORD_LENGTH_ERROR,
	WRONG_START_LETTER_ERROR,
	WRONG_PARAMETER_ERROR

};



typedef enum
{
	CIRCULAR_INTERPOLATION_I_J_TYPE,
	CIRCULAR_INTERPOLATION_R_TYPE
}CIRCULAR_INTERPOLATION_PARAMETER_TYPE;

typedef enum
{
	LINE_NUMBER_INACTIVE,
	LINE_NUMBER_ACTIVE
}islineNumberUsed;

enum
{
	BUFFER_NOT_FULL,
	BUFFER_FULL

};



typedef struct
{
	CIRCULAR_INTERPOLATION_PARAMETER_TYPE paramaterType;
	float X;
	float Y;
	float I;
	float J;
	float radius;
	float feedRate;
}circularParameterPrototype;

extern struct Gparser_
{
	struct
	{
		float X;
		float Y;
		float Z;
		float E;
	}G00_RAPID_MOVEMENT[MAX_ITEM_NUMBER];

	struct
	{
		float X;
		float Y;
		float Z;
		float E;
		float feedRate;
	}G01_LINEAR_INTERPOLATION[MAX_ITEM_NUMBER];

	circularParameterPrototype G02_CIRCULAR_CW_INTERPOLATION[MAX_ITEM_NUMBER];
	circularParameterPrototype G03_CIRCULAR_CCW_INTERPOLATION[MAX_ITEM_NUMBER];


	uint16_t lineNumber[MAX_ITEM_NUMBER];
	uint16_t SPEED[MAX_ITEM_NUMBER];
	uint16_t TOOL ;
	uint16_t M_FUNCTION[MAX_ITEM_NUMBER];



	struct
	{
		uint16_t G00_RAPID_MOVEMENT;
		uint16_t G01_LINEAR_INTERPOLATION;
		uint16_t G02_CIRCULAR_CW_INTERPOLATION;
		uint16_t G03_CIRCULAR_CCW_INTERPOLATION;
		uint16_t lineNumber;
		uint16_t SPEED;
		uint16_t M_FUNCTION;

	}indexer;

	struct
	{
		char taskParsestatus[MAX_ITEM_NUMBER];
		uint16_t taskBuffer[MAX_ITEM_NUMBER][2];
		uint16_t taskIndex;
		uint16_t operatorIndex;
		char lengthMode;
		char incAbsoluteSelect;
		uniPosXYZE position;
		uint8_t activeMovementTask;
		float activeFeedRate;

	}parserControl;

	struct
	{
		float X;
		float Y;
		float Z;
		float I;
		float J;
		float R;
		float F;
		uint8_t task;
		uint16_t lineNumber;
	}modalTaskControl;

	struct
	{
		islineNumberUsed lineNumberUsed;
		char subLineData[MAXIMUM_WORD_SPLIT][MAXIMUM_WORD_LENGTH];
		uint8_t wordCounter;
	}lineController;



}Gparser;


void initializeParser();
uint8_t mainParser(uint8_t *Gline);
void prepareParserLine(uint8_t *Gline);
void taskParameterParser(char *taskData);
void lineIndexer(char *data);
void modalTaskPostParser(char taskParameter, char task, uint16_t number);
void modalTaskPreParser(char character);
void setMfunction(uint8_t Mfunction);
void setSpeed(float speed);
void setToolParameter(uint8_t tool);
void assignXaxis(float val);
void assignYaxis(float val);
void assignZaxis(float val);
void assignExtruder(float val);
void getPrePositionParameters(char coordinate, float val);
void assignCircularInterPolationParameterType(char task);
void assignIparameter(float val);
void assignJparameter(float val);
void assignRadiusParameter(float val);
void assignFeedRateParameter(float val);
void taskIndexer(uint8_t task);
uint8_t getTask(char* taskData);
void assignFeedRate(float feedRate, char modalTask);
void isTaskLineUsed(uint8_t *Gline);
void lineSplit(uint8_t* line);
void initGpaser();
void resetGpaser();
void parserError(uint8_t errorIndex);




#endif /* GPARSER_H_ */
