/*
 * Gparser.h
 *
 *  Created on: 10 Oca 2018
 *      Author: yzcifci
 */

#ifndef GPARSER_H_
#define GPARSER_H_

#include "stm32f4xx_hal.h"
#include "parameters.h"

#define CHECK_BIG(STATE1,STATE2) ((STATE1)>=(STATE2)? (1):(0))
#define MAX(x,y) ((x) > (y) ? (x) : (y))


typedef enum
{
	PARSABLE_VALID_DATA,
	COMMENT_LINE,
}parsStatus;


typedef enum
{
	LINE_NUMBER_INACTIVE,
	LINE_NUMBER_ACTIVE
}islineNumberUsed;

enum
{
	BUFFER_NOT_FULL,
	BUFFER_FULL

};




/*
 *tail 		:when new data processed at operator control then this parameter increments one
 *head		:when new data parsed to process at operator control this parameter increments one
 *empty		:gives the empty area in parser parameter buffer
 *filled	:gives the filled area in parser parameter buffer
 */
extern struct parser_
{
	struct
	{
		char parameter[128];
		uint16_t task;
	}parameters[PARSER_PARAMETER_SIZE];

	uint16_t tail;
	uint16_t head;
	int16_t empty;
	int16_t filled;

	uint8_t bufferStatus;
}parser;

extern struct test_
{
	uint32_t data;
	uint32_t formerdata;
	uint32_t tailHeadDiff;
	uint32_t formertailHeadDiff;
	uint8_t bufferStatus;
	uint8_t formerbufferStatus;
}test;

uint8_t pars(char *data);
void parameterParse(char *data);
void initializeParser();
uint16_t getTask(char* taskData);
void initGpaser();
void parserHeadPlus1(void);
void parserTailPlus1(void);

#endif /* GPARSER_H_ */
