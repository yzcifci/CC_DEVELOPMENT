/*
 * taskPrepare.c
 *
 *  Created on: 16 Mar 2019
 *      Author: yzcifci
 */

#include "main.h"

struct prepData_ prepData;
void taskPrepare()
{
	uint16_t index		=parser.head;
	uint8_t task		=parser.parameters[index].task;
	char* parameter		=(char*)&parser.parameters[index].parameter[0];

	switch(task)
	{
	case G00_RAPID_MOVEMENT:
		if(deviceControl.lengthMode==INCHES_MODE)convertDatasInchesToMetric(parameter);
		updatePositions(parameter);
		break;

	case G01_LINEAR_INTERPOLATION:
		if(deviceControl.lengthMode==INCHES_MODE)convertDatasInchesToMetric(parameter);
		updatePositions(parameter);
		break;

	case G20_INCHES_MODE:
		deviceControl.lengthMode=INCHES_MODE;
		break;

	case G21_METRIC_MODE:
		deviceControl.lengthMode=METRIC_MODE;
		break;

	case G90_ABSOLUTE_MODE_SELECT:
		deviceControl.incrementalMode=ABSOLUTE_MODE;
		break;

	case G91_INCREMENTAL_MODE_SELECT:
		deviceControl.incrementalMode=INCREMENTAL_MODE;
		break;

	case G92_SET_POSITION:
		setPositions(parameter);
		break;

	case M82_SET_EXTRUDER_ABSOLUTE_MODE:
		deviceControl.ExtruderIncrementalMode=ABSOLUTE_MODE;
		break;

	case M204_SET_ACCELERATION:
		setAcceleration(parameter);
		break;


	}

}


void updatePositions(char *add)
{
	parserAssign parsData;
	parserAssign *parsDataAdd = (parserAssign*)add;
	parsData.x=parsDataAdd->x;
	parsData.y=parsDataAdd->y;
	parsData.z=parsDataAdd->z;
	parsData.e=parsDataAdd->e;
	if(deviceControl.incrementalMode==INCREMENTAL_MODE)
	{
		parsData.x+=deviceControl.mmPosition.X;
		parsData.y+=deviceControl.mmPosition.Y;
		parsData.z+=deviceControl.mmPosition.Z;
		parsData.e+=deviceControl.mmPosition.E;
	}
	else if(deviceControl.ExtruderIncrementalMode==INCREMENTAL_MODE)
	{
		parsData.e+=deviceControl.mmPosition.E;
	}

	parsDataAdd->x=parsData.x;
	parsDataAdd->y=parsData.y;
	parsDataAdd->z=parsData.z;
	parsDataAdd->e=parsData.e;

}

void convertDatasInchesToMetric(char *add)
{
	parserAssign parsData;
	parserAssign *parsDataAdd = (parserAssign*)add;

	parsData.x=parsDataAdd->x;
	parsData.y=parsDataAdd->y;
	parsData.z=parsDataAdd->z;
	parsData.e=parsDataAdd->e;

	parsData.x=parsData.x*MM_TO_INCH_MULT;
	parsData.y=parsData.y*MM_TO_INCH_MULT;
	parsData.z=parsData.z*MM_TO_INCH_MULT;
	parsData.e=parsData.e*MM_TO_INCH_MULT;

	parsDataAdd->x=parsData.x;
	parsDataAdd->y=parsData.y;
	parsDataAdd->z=parsData.z;
	parsDataAdd->e=parsData.e;


}

void setPositions(char *add)
{
	parserAssign parsData;
	parserAssign *parsDataAdd = (parserAssign*)add;

	parsData.x=parsDataAdd->x;
	parsData.y=parsDataAdd->y;
	parsData.z=parsDataAdd->z;
	parsData.e=parsDataAdd->e;


	if(*(uint32_t*)(uint32_t)&parsDataAdd->x!=0xffffffff)deviceControl.mmPosition.X=parsData.x;
	if(*(uint32_t*)(uint32_t)&parsDataAdd->y!=0xffffffff)deviceControl.mmPosition.Y=parsData.y;
	if(*(uint32_t*)(uint32_t)&parsDataAdd->z!=0xffffffff)deviceControl.mmPosition.Z=parsData.z;
	if(*(uint32_t*)(uint32_t)&parsDataAdd->e!=0xffffffff)deviceControl.mmPosition.E=parsData.e;


	deviceControl.stepPosition.stepX=mmToStepX(deviceControl.mmPosition.X);
	deviceControl.stepPosition.stepY=mmToStepY(deviceControl.mmPosition.Y);
	deviceControl.stepPosition.stepZ=mmToStepZ(deviceControl.mmPosition.Z);
	deviceControl.stepPosition.stepE=mmToStepE(deviceControl.mmPosition.E);
}


 void setAcceleration(char *add)
 {
	 float accelerationVal=(float)(*(int32_t*)add);
	 deviceControl.accelerationVal=accelerationVal;
 }


