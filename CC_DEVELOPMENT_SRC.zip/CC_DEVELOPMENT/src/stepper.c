/*
 * stepper.c
 *
 *  Created on: 27 ?ub 2019
 *      Author: yzcifci
 */

#include "main.h"

struct stepStruct_ stepStruct;


float endFx=0;
float endFy=0;
uint16_t movCntr=0;

// test start
uint32_t stopAtMovement=43;
//test end

uint8_t startMove(char *parameter)
{
	memset((char*)&stepStruct,0x0,sizeof(stepStruct));
	memcpy((char*)(uint32_t)&stepStruct.parsData,(char*)(uint32_t)parameter,116);

	if((stepStruct.parsData.stepX==0)&&(stepStruct.parsData.stepY==0)&&
			(stepStruct.parsData.stepZ==0)&&(stepStruct.parsData.stepE==0))return TASK_COMPLETED;

	// test start feed test
	movCntr++;
	if(movCntr==stopAtMovement)
	{
		volatile uint8_t x=0;
		x++;
	}


	if(fatfsControl.endOfPrintRead==0)
	{
		if((fabs(endFx-stepStruct.parsData.f1sx)>(MAXIMUM_XY_COORDINATE_FEED_DIFF))||((fabs(endFy-stepStruct.parsData.f1sy)>(MAXIMUM_XY_COORDINATE_FEED_DIFF))))
			errorLog(STEP_MOVEMENT_START_FEED_ERROR);
	}


	stepStruct.fx=stepStruct.parsData.f1sx;
	stepStruct.fy=stepStruct.parsData.f1sy;
	stepStruct.fz=stepStruct.parsData.fz;
	stepStruct.fe=stepStruct.parsData.f1se;

	stepStruct.tx=getPulsePeriodTx(stepStruct.fx);
	stepStruct.ty=getPulsePeriodTy(stepStruct.fy);
	stepStruct.tz=getPulsePeriodTz(stepStruct.fz);
	stepStruct.te=getPulsePeriodTe(stepStruct.fe);

	uint32_t dStep=0;
	float t=1000000;
	if(stepStruct.parsData.stepX>dStep)
	{
		stepStruct.refCoordinate=COORDINATE_X;
		dStep=stepStruct.parsData.stepX;
		t=stepStruct.tx/2;
	}

	if(stepStruct.parsData.stepY>dStep)
	{
		stepStruct.refCoordinate=COORDINATE_Y;
		dStep=stepStruct.parsData.stepY;
		t=stepStruct.ty/2;
	}

	if(stepStruct.parsData.stepE>dStep)
	{
		stepStruct.refCoordinate=EXTRUDER;
		dStep=stepStruct.parsData.stepE;
		t=stepStruct.te/2;
	}

	stepStruct.multTX=(float)((float)dStep/(float)stepStruct.parsData.stepX);
	stepStruct.multTY=(float)((float)dStep/(float)stepStruct.parsData.stepY);
	stepStruct.multTE=(float)((float)dStep/(float)stepStruct.parsData.stepE);
	stepStruct.toggleT=t;
	setTimStepCallBack((uint32_t)(uint8_t*)stepperMoveCall);
	setStepTimT(t);

	if(stepStruct.parsData.stepZ)setTimZ((uint32_t)toggleZCallback);

	stepStruct.moveState=NONE;
	setAccelerationTurn();
	return TASK_RUNNING;
}


uint8_t stepperMoveCall()
{
	uint8_t taskSt;
	float div=1;
	switch(stepStruct.refCoordinate)
	{
	case COORDINATE_X:
		/*operate X*/
		taskSt=toggleXCallback();
		if(taskSt==TASK_COMPLETED||taskSt==TASK_XYE_COMPLETED)return taskSt;


		/*operate Y*/
		if(stepStruct.parsData.stepY)
		{
			div=(float)((float)(stepStruct.halfStepCntrX+1)/(float)(stepStruct.halfStepCntrY+1));
			if(div==stepStruct.multTY)
			{
				taskSt=toggleYCallback();
				if((taskSt==TASK_COMPLETED)||(taskSt==TASK_XYE_COMPLETED))return taskSt;
			}
			else if(div>stepStruct.multTY)
			{
				float multFrac=(stepStruct.halfStepCntrY+1)*stepStruct.multTY;
				setTY((multFrac-(uint32_t)multFrac)*(stepStruct.tx/2));
				setTimY((uint32_t)toggleYCallback);
			}
		}

		/*operate E*/
		if(stepStruct.parsData.stepE)
		{
			div=(float)((float)(stepStruct.halfStepCntrX+1)/(float)(stepStruct.halfStepCntrE+1));
			if(div==stepStruct.multTE)
			{
				taskSt=toggleECallback();
				if((taskSt==TASK_COMPLETED)||(taskSt==TASK_XYE_COMPLETED))return taskSt;
			}
			else if(div>stepStruct.multTE)
			{
				float multFrac=(stepStruct.halfStepCntrE+1)*stepStruct.multTE;
				setTE((multFrac-(uint32_t)multFrac)*(stepStruct.tx/2));
				setTimE((uint32_t)toggleECallback);
			}
		}

		setStepTimT(stepStruct.tx/2);
		break;

	case COORDINATE_Y:

		/*operate Y*/
		taskSt=toggleYCallback();
		if((taskSt==TASK_COMPLETED)||(taskSt==TASK_XYE_COMPLETED))return taskSt;

		/*operate X*/
		if(stepStruct.parsData.stepX)
		{
			div=(float)((float)(stepStruct.halfStepCntrY+1)/(float)(stepStruct.halfStepCntrX+1));
			if(div==stepStruct.multTX)
			{
				taskSt=toggleXCallback();
				if((taskSt==TASK_COMPLETED)||(taskSt==TASK_XYE_COMPLETED))return taskSt;
			}
			else if(div>stepStruct.multTX)
			{
				float multFrac=(stepStruct.halfStepCntrX+1)*stepStruct.multTX;
				setTX((multFrac-(uint32_t)multFrac)*(stepStruct.ty/2));
				setTimX((uint32_t)toggleXCallback);
			}
		}

		/*operate E*/
		if(stepStruct.parsData.stepE)
		{
			div=(float)((float)(stepStruct.halfStepCntrY+1)/(float)(stepStruct.halfStepCntrE+1));
			if(div==stepStruct.multTE)
			{
				taskSt=toggleECallback();
				if((taskSt==TASK_COMPLETED)||(taskSt==TASK_XYE_COMPLETED))return taskSt;
			}
			else if(div>stepStruct.multTE)
			{
				float multFrac=(stepStruct.halfStepCntrE+1)*stepStruct.multTE;
				setTE((multFrac-(uint32_t)multFrac)*(stepStruct.ty/2));
				setTimE((uint32_t)toggleECallback);
			}
		}

		setStepTimT(stepStruct.ty/2);

		break;

	case EXTRUDER:

		/*operate E*/
		taskSt=toggleECallback();
		if(taskSt==TASK_COMPLETED||taskSt==TASK_XYE_COMPLETED)return taskSt;

		/*operate X*/
		if(stepStruct.parsData.stepX)
		{
			div=(float)((float)(stepStruct.halfStepCntrE+1)/(float)(stepStruct.halfStepCntrX+1));
			if(div==stepStruct.multTX)
			{
				taskSt=toggleXCallback();
				if((taskSt==TASK_COMPLETED)||(taskSt==TASK_XYE_COMPLETED))return taskSt;
			}
			else if(div>stepStruct.multTX)
			{
				float multFrac=(stepStruct.halfStepCntrX+1)*stepStruct.multTX;
				setTX((multFrac-(uint32_t)multFrac)*(stepStruct.te/2));
				setTimX((uint32_t)toggleXCallback);
			}
		}

		/*operate Y*/
		if(stepStruct.parsData.stepY)
		{
			div=(float)((float)(stepStruct.halfStepCntrE+1)/(float)(stepStruct.halfStepCntrY+1));
			if(div==stepStruct.multTY)
			{
				taskSt=toggleYCallback();
				if((taskSt==TASK_COMPLETED)||(taskSt==TASK_XYE_COMPLETED))return taskSt;
			}
			else if(div>stepStruct.multTY)
			{
				float multFrac=(stepStruct.halfStepCntrY+1)*stepStruct.multTY;
				setTY((multFrac-(uint32_t)multFrac)*(stepStruct.te/2));
				setTimY((uint32_t)toggleYCallback);
			}
		}

		setStepTimT(stepStruct.te/2);
		break;
	}
	return TASK_RUNNING;
}

uint8_t toggleXCallback()
{
	uint8_t taskSt=TASK_RUNNING;
	toggleX(stepStruct.parsData.dirX);
	stepStruct.halfStepCntrX++;
	if(stepStruct.halfStepCntrX%2==0)
	{
		stepStruct.stepX++;
		if(stepStruct.refCoordinate==COORDINATE_X)moveStepAccelerate(COORDINATE_X);
	}

	taskSt=checkMoveEnd();
	if(taskSt==TASK_XYE_COMPLETED)
	{
		setStepTimT(1*MULT_FACTOR);
		setTX(1*MULT_FACTOR);
		setTY(1*MULT_FACTOR);
		setTE(1*MULT_FACTOR);
		setTimStepCallBack((uint32_t)moveTaskIdle);
		setTimX((uint32_t)moveTaskIdle);
		setTimY((uint32_t)moveTaskIdle);
		setTimE((uint32_t)moveTaskIdle);
	}
	else if(taskSt==TASK_COMPLETED)
	{
		setStepTimT(1*MULT_FACTOR);
		setTX(1*MULT_FACTOR);
		setTY(1*MULT_FACTOR);
		setTE(1*MULT_FACTOR);
		setTimStepCallBack((uint32_t)moveTaskIdle);
		setTimX((uint32_t)moveTaskIdle);
		setTimY((uint32_t)moveTaskIdle);
		setTimZ((uint32_t)moveTaskIdle);
		setTimE((uint32_t)moveTaskIdle);
	}
	setTX(1*MULT_FACTOR);
	setTimX((uint32_t)moveTaskIdle);
	return taskSt;

}

uint8_t toggleYCallback()
{
	uint8_t taskSt;
	toggleY(stepStruct.parsData.dirY);
	stepStruct.halfStepCntrY++;
	if(stepStruct.halfStepCntrY%2==0)
	{
		stepStruct.stepY++;
		if(stepStruct.refCoordinate==COORDINATE_Y)moveStepAccelerate(COORDINATE_Y);
	}

	taskSt=checkMoveEnd();
	if(taskSt==TASK_XYE_COMPLETED)
	{
		setStepTimT(1*MULT_FACTOR);
		setTX(1*MULT_FACTOR);
		setTY(1*MULT_FACTOR);
		setTE(1*MULT_FACTOR);
		setTimStepCallBack((uint32_t)moveTaskIdle);
		setTimX((uint32_t)moveTaskIdle);
		setTimY((uint32_t)moveTaskIdle);
		setTimE((uint32_t)moveTaskIdle);
	}
	else if(taskSt==TASK_COMPLETED)
	{
		setStepTimT(1*MULT_FACTOR);
		setTX(1*MULT_FACTOR);
		setTY(1*MULT_FACTOR);
		setTE(1*MULT_FACTOR);
		setTimStepCallBack((uint32_t)moveTaskIdle);
		setTimX((uint32_t)moveTaskIdle);
		setTimY((uint32_t)moveTaskIdle);
		setTimZ((uint32_t)moveTaskIdle);
		setTimE((uint32_t)moveTaskIdle);
	}
	setTY(1*MULT_FACTOR);
	setTimY((uint32_t)moveTaskIdle);
	return taskSt;

}

uint8_t toggleZCallback()
{
	toggleZ(stepStruct.parsData.dirZ);
	stepStruct.halfStepCntrZ++;
	if(stepStruct.halfStepCntrZ%2==0)stepStruct.stepZ++;

	if(checkMoveEnd()==TASK_COMPLETED)
	{
		setStepTimT(1*MULT_FACTOR);
		setTX(1*MULT_FACTOR);
		setTY(1*MULT_FACTOR);
		setTE(1*MULT_FACTOR);
		setTimStepCallBack((uint32_t)moveTaskIdle);
		setTimX((uint32_t)moveTaskIdle);
		setTimY((uint32_t)moveTaskIdle);
		setTimZ((uint32_t)moveTaskIdle);
		setTimE((uint32_t)moveTaskIdle);
		return TASK_COMPLETED;
	}
	if(stepStruct.stepZ>=stepStruct.parsData.stepZ)
	{
		setTimZ((uint32_t)moveTaskIdle);
	}
	return TASK_RUNNING;
}


uint8_t toggleECallback()
{
	uint8_t taskSt;
	toggleE(stepStruct.parsData.dirE);
	stepStruct.halfStepCntrE++;
	if(stepStruct.halfStepCntrE%2==0)
	{
		stepStruct.stepE++;
		if(stepStruct.refCoordinate==EXTRUDER)moveStepAccelerate(EXTRUDER);
	}

	taskSt=checkMoveEnd();
	if(taskSt==TASK_XYE_COMPLETED)
	{
		setStepTimT(1*MULT_FACTOR);
		setTX(1*MULT_FACTOR);
		setTY(1*MULT_FACTOR);
		setTE(1*MULT_FACTOR);
		setTimStepCallBack((uint32_t)moveTaskIdle);
		setTimX((uint32_t)moveTaskIdle);
		setTimY((uint32_t)moveTaskIdle);
		setTimE((uint32_t)moveTaskIdle);
	}
	else if(taskSt==TASK_COMPLETED)
	{
		setStepTimT(1*MULT_FACTOR);
		setTX(1*MULT_FACTOR);
		setTY(1*MULT_FACTOR);
		setTE(1*MULT_FACTOR);
		setTimStepCallBack((uint32_t)moveTaskIdle);
		setTimX((uint32_t)moveTaskIdle);
		setTimY((uint32_t)moveTaskIdle);
		setTimZ((uint32_t)moveTaskIdle);
		setTimE((uint32_t)moveTaskIdle);
	}
	setTE(1*MULT_FACTOR);
	setTimE((uint32_t)moveTaskIdle);
	return taskSt;
}

void moveStepAccelerate(uint8_t coordinate)
{
	switch(stepStruct.moveState)
	{
	case SPEED_UP:
	{
		if(stepStruct.refCoordinate==COORDINATE_X)
		{
			if(stepStruct.stepX>=stepStruct.parsData.p1x)
			{
				if(stepStruct.isSteady==1)stepStruct.moveState=STEADY;
				else if(stepStruct.isBrake==1)stepStruct.moveState=BRAKE;
				else
				{
					stepStruct.moveState=NONE;
				}
			}
		}
		else if(stepStruct.refCoordinate==COORDINATE_Y)
		{
			if(stepStruct.stepY>=stepStruct.parsData.p1y)
			{
				if(stepStruct.isSteady==1)stepStruct.moveState=STEADY;
				else if(stepStruct.isBrake==1)stepStruct.moveState=BRAKE;
				else
				{
					stepStruct.moveState=NONE;
				}
			}
		}
		else
		{
			if(stepStruct.stepE>=stepStruct.parsData.p1e)
			{
				if(stepStruct.isSteady==1)stepStruct.moveState=STEADY;
				else if(stepStruct.isBrake==1)stepStruct.moveState=BRAKE;
				else
				{
					stepStruct.moveState=NONE;
				}

			}
		}
		// edit end



		switch(coordinate)
		{
		case COORDINATE_X:
			stepStruct.fx+=(stepStruct.parsData.a1x*stepStruct.tx*60)/MULT_FACTOR;
			stepStruct.tx=getPulsePeriodTx(stepStruct.fx);
			break;
		case COORDINATE_Y:
			stepStruct.fy+=(stepStruct.parsData.a1y*stepStruct.ty*60)/MULT_FACTOR;
			stepStruct.ty=getPulsePeriodTy(stepStruct.fy);
			break;
		case COORDINATE_Z:
			break;
		case EXTRUDER:
			stepStruct.fe+=(stepStruct.parsData.a1e*stepStruct.te*60)/MULT_FACTOR;
			stepStruct.te=getPulsePeriodTy(stepStruct.fe);
			break;
		}
		break;
	}
	case STEADY:

		stepStruct.tx=getPulsePeriodTx(stepStruct.fx);
		stepStruct.ty=getPulsePeriodTy(stepStruct.fy);
		//stepStruct.te=stepStruct.parsData.t2se;
		if(stepStruct.isBrake)
		{
			// eidt start
			if(stepStruct.refCoordinate==COORDINATE_X)
			{
				if(stepStruct.stepX>=stepStruct.parsData.p2x)
				{
					stepStruct.moveState=BRAKE;
				}
			}
			else if(stepStruct.refCoordinate==COORDINATE_Y)
			{
				if(stepStruct.stepY>=stepStruct.parsData.p2y)
				{
					stepStruct.moveState=BRAKE;
				}
			}
			else
			{
				if(stepStruct.stepE>=stepStruct.parsData.p2e)
				{
					stepStruct.moveState=BRAKE;
				}
			}
		}
		break;

	case BRAKE:
	{
		switch(coordinate)
		{
		case COORDINATE_X:
			stepStruct.fx-=(stepStruct.parsData.a2x*stepStruct.tx*60)/MULT_FACTOR;
			stepStruct.tx=getPulsePeriodTx(stepStruct.fx);
			break;
		case COORDINATE_Y:
			stepStruct.fy-=(stepStruct.parsData.a2y*stepStruct.ty*60)/MULT_FACTOR;
			stepStruct.ty=getPulsePeriodTy(stepStruct.fy);
			break;
		case COORDINATE_Z:
			break;
		case EXTRUDER:
			stepStruct.fe-=(stepStruct.parsData.a2e*stepStruct.te*60)/MULT_FACTOR;
			stepStruct.te=getPulsePeriodTy(stepStruct.fe);
			break;
		}
		break;
	}

	}
}

uint8_t checkMoveEnd()
{
	if((stepStruct.stepX>=stepStruct.parsData.stepX)&&
			(stepStruct.stepY>=stepStruct.parsData.stepY)&&
			(stepStruct.stepZ>=stepStruct.parsData.stepZ)&&
			(stepStruct.stepE>=stepStruct.parsData.stepE))
	{
		if((stepStruct.stepX!=stepStruct.parsData.stepX)||
				(stepStruct.stepY!=stepStruct.parsData.stepY)||
				(stepStruct.stepZ!=stepStruct.parsData.stepZ)||
				(stepStruct.stepE!=stepStruct.parsData.stepE))errorLog(XYZE_STEP_SYNCHRONISATION_ERROR);
		setEndFeeds();
		return TASK_COMPLETED;
	}

	else if((stepStruct.stepX>=stepStruct.parsData.stepX)&&
			(stepStruct.stepY>=stepStruct.parsData.stepY)&&
			(stepStruct.stepE>=stepStruct.parsData.stepE))
	{
		if((stepStruct.stepX!=stepStruct.parsData.stepX)||
				(stepStruct.stepY!=stepStruct.parsData.stepY)||
				(stepStruct.stepE!=stepStruct.parsData.stepE))errorLog(XYE_STEP_SYNCHRONISATION_ERROR);
		setEndFeeds();
		return TASK_XYE_COMPLETED;
	}
	return TASK_RUNNING;
}



static 	G28Struct_ G28Data;
uint8_t G28_MOVE_TO_ORIGIN_func(char *parameters)
{

#if MOVEMENT_TEST_ENABLE
	return TASK_COMPLETED;
#endif

	memset(&G28Data,0xff,sizeof(G28Data));
	G28Struct_* G28DataPntr=(G28Struct_*)parameters;
	G28Data.x=G28DataPntr->x;
	G28Data.y=G28DataPntr->y;
	G28Data.z=G28DataPntr->z;
	G28Data.tx=0;
	G28Data.ty=0;
	G28Data.tz=0;
	G28Data.toggletx=0;
	G28Data.togglety=0;
	G28Data.toggletz=0;
	if(G28Data.x==0)G28Data.tx=getPulsePeriodTx(MAXIMUM_START_STOP_FEED_RATE);
	if(G28Data.y==0)G28Data.ty=getPulsePeriodTy(MAXIMUM_START_STOP_FEED_RATE);
	if(G28Data.z==0)G28Data.tz=getPulsePeriodTz(MAXIMUM_START_STOP_FEED_RATE_Z);
	G28Data.toggletx=G28Data.tx/2;
	G28Data.togglety=G28Data.ty/2;
	G28Data.toggletz=G28Data.tz/2;

	float t=10000000;
	if((G28Data.toggletx<t) && (G28Data.tx!=0))t=G28Data.toggletx;
	if((G28Data.togglety<t) && (G28Data.ty!=0))t=G28Data.togglety;
	if((G28Data.toggletz<t) && (G28Data.tz!=0))t=G28Data.toggletz;
	setTimStepCallBack((uint32_t)G28_MOVE_TO_ORIGIN_callBack);
	setStepTimT(t);
	G28Data.toggleT=t;
	return TASK_RUNNING;

}


uint8_t G28_MOVE_TO_ORIGIN_callBack(void)
{
	if((G28Data.x==0)&&(readLimitSwitchX()==LIMIT_SWITCH_NOT_PRESSED))G28Data.toggletx-=G28Data.toggleT;
	if((G28Data.y==0)&&(readLimitSwitchY()==LIMIT_SWITCH_NOT_PRESSED))G28Data.togglety-=G28Data.toggleT;
	if((G28Data.z==0)&&(readLimitSwitchZ()==LIMIT_SWITCH_NOT_PRESSED))G28Data.toggletz-=G28Data.toggleT;

	if((G28Data.toggletx==0) && (G28Data.x==0))
	{
		toggleX(0);
		G28Data.toggletx=G28Data.tx/2;
	}
	if((G28Data.togglety==0) && (G28Data.y==0))
	{
		toggleY(0);
		G28Data.togglety=G28Data.ty/2;
	}
	if((G28Data.toggletz==0) && (G28Data.z==0))
	{
		toggleZ(0);
		G28Data.toggletz=G28Data.tz/2;
	}
	if(((G28Data.x!=0)||(readLimitSwitchX()==LIMIT_SWITCH_PRESSED))&&
			((G28Data.y!=0)||(readLimitSwitchY()==LIMIT_SWITCH_PRESSED))&&
			((G28Data.z!=0)||(readLimitSwitchZ()==LIMIT_SWITCH_PRESSED)))
	{
		setTimStepCallBack((uint32_t)moveTaskIdle);
		setStepTimT(1*MULT_FACTOR); //set t 1 sc

		printerIOParameters.position.stepPosition.stepX=0;
		printerIOParameters.position.stepPosition.stepY=0;
		printerIOParameters.position.stepPosition.stepZ=0;
		printerIOParameters.position.stepPosition.stepE=0;
		return TASK_COMPLETED;
	}
	else
	{
		float t=10000000;
		if((G28Data.toggletx<t) && (G28Data.tx!=0))t=G28Data.toggletx;
		if((G28Data.togglety<t) && (G28Data.ty!=0))t=G28Data.togglety;
		if((G28Data.toggletz<t) && (G28Data.tz!=0))t=G28Data.toggletz;
		setStepTimT(t);
		G28Data.toggleT=t;
	}

	return TASK_RUNNING;
}

float getPulsePeriodTx(float feed)
{
	if(feed==0)return 0;
	float t;
	t=(MM_PER_ROTATION_X*MULT_FACTOR*60)/(STEPS_PER_ROTATION_X*deviceControl.microStepX*feed);
	return t;
}

float getPulsePeriodTy(float feed)
{
	if(feed==0)return 0;
	float t;
	t=(MM_PER_ROTATION_Y*MULT_FACTOR*60)/(STEPS_PER_ROTATION_Y*deviceControl.microStepY*feed);
	return t;
}

float getPulsePeriodTz(float feed)
{
	if(feed==0)return 0;
	float t;
	t=(MM_PER_ROTATION_Z*MULT_FACTOR*60)/(STEPS_PER_ROTATION_Z*deviceControl.microStepZ*feed);
	return t;
}

float getPulsePeriodTe(float feed)
{
	if(feed==0)return 0;
	float t;
	t=(MM_PER_ROTATION_E*MULT_FACTOR*60)/(STEPS_PER_ROTATION_E*deviceControl.microStepE*feed);
	return t;
}

void setEndFeeds()
{
	endFx=0;
	endFy=0;
	switch(stepStruct.refCoordinate)
	{
	case COORDINATE_X:
		endFx=stepStruct.fx;
		if(stepStruct.parsData.stepY)endFy=stepStruct.fx/stepStruct.multTY;
		break;
	case COORDINATE_Y:
		endFy=stepStruct.fy;
		if(stepStruct.parsData.stepX)endFx=stepStruct.fy/stepStruct.multTX;
		break;
	case EXTRUDER:
		if(stepStruct.parsData.stepX)endFx=stepStruct.fe/stepStruct.multTX;
		if(stepStruct.parsData.stepY)endFx=stepStruct.fe/stepStruct.multTY;
		break;
	default:
		break;
	}
}

void setAccelerationTurn()
{
	switch(stepStruct.refCoordinate)
	{
	case COORDINATE_X:
		if(stepStruct.parsData.a1x!=0)stepStruct.isSpeedUp=1;
		if(stepStruct.parsData.a2x!=0)stepStruct.isBrake=1;
		if(stepStruct.parsData.p2x>stepStruct.parsData.p1x)stepStruct.isSteady=1;
		break;

	case COORDINATE_Y:
		if(stepStruct.parsData.a1y!=0)stepStruct.isSpeedUp=1;
		if(stepStruct.parsData.a2y!=0)stepStruct.isBrake=1;
		if(stepStruct.parsData.p2y>stepStruct.parsData.p1y)stepStruct.isSteady=1;
		break;

	case EXTRUDER:
		if(stepStruct.parsData.a1e!=0)stepStruct.isSpeedUp=1;
		if(stepStruct.parsData.a2e!=0)stepStruct.isBrake=1;
		if(stepStruct.parsData.p2e>stepStruct.parsData.p1e)stepStruct.isSteady=1;
		break;
	}

	if(stepStruct.isSpeedUp)stepStruct.moveState=SPEED_UP;
	else if(stepStruct.isSteady)stepStruct.moveState=STEADY;
	else if(stepStruct.isBrake)stepStruct.moveState=BRAKE;
	else
		stepStruct.moveState=NONE;
}

uint8_t moveTaskIdle(void)
{
	return TASK_IDLE;
}
