/*
 * stepper.c
 *
 *  Created on: 27 ?ub 2019
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct stepStruct_ stepStruct;

uint8_t taskStatus=TASK_COMPLETED;
uint32_t pdata[1024];
uint32_t cntr=0;
uint8_t startMove(char *parameter)
{

	if(taskStatus==TASK_RUNNING)return TASK_RUNNING;
	memset((char*)&stepStruct,0x0,sizeof(stepStruct));
	memcpy((char*)(uint32_t)&stepStruct.parsData,(char*)(uint32_t)parameter,116);



	stepStruct.fx=stepStruct.parsData.f1sx;
	stepStruct.fy=stepStruct.parsData.f1sy;
	stepStruct.fz=stepStruct.parsData.fz;
	stepStruct.fe=stepStruct.parsData.f1se;

	stepStruct.tx=getPulsePeriodTx(stepStruct.fx);
	stepStruct.ty=getPulsePeriodTy(stepStruct.fy);
	stepStruct.tz=getPulsePeriodTz(stepStruct.fz);
	stepStruct.te=getPulsePeriodTe(stepStruct.fe);

	stepStruct.toggletx=stepStruct.tx/2;
	stepStruct.togglety=stepStruct.ty/2;
	stepStruct.toggletz=stepStruct.tz/2;
	stepStruct.togglete=stepStruct.te/2;

	if((stepStruct.tx==0)&&(stepStruct.ty==0)&&(stepStruct.tz==0)&&(stepStruct.te==0))return TASK_COMPLETED;

	uint32_t dStep=0;
	if(stepStruct.parsData.stepX>dStep)
	{
		stepStruct.refCoordinate=COORDINATE_X;
		dStep=stepStruct.parsData.stepX;
	}

	if(stepStruct.parsData.stepY>dStep)
	{
		stepStruct.refCoordinate=COORDINATE_Y;
		dStep=stepStruct.parsData.stepY;
	}

	if(stepStruct.parsData.stepE>dStep)
	{
		stepStruct.refCoordinate=EXTRUDER;
		dStep=stepStruct.parsData.stepE;
	}

	stepStruct.multTX=dStep/stepStruct.parsData.stepX;
	stepStruct.multTY=dStep/stepStruct.parsData.stepY;
	stepStruct.multTE=dStep/stepStruct.parsData.stepE;



	float t=1000000;
	if(t>stepStruct.toggletx && stepStruct.toggletx!=0 )
	{
		t=stepStruct.toggletx;
	}
	if(t>stepStruct.togglety && stepStruct.togglety!=0 )
	{
		t=stepStruct.togglety;
	}

	if(t>stepStruct.toggletz&& stepStruct.toggletz!=0)
	{
		t=stepStruct.toggletz;
	}
	if(t>stepStruct.togglete&& stepStruct.togglete!=0)
	{
		t=stepStruct.togglete;
	}

	stepStruct.toggleT=t;
	setTimStepCallBack(stepperMoveCall);
	setStepTimT(t);



	stepStruct.moveState=NONE;
	if((stepStruct.parsData.a1x!=0)||(stepStruct.parsData.a1y!=0))stepStruct.isSpeedUp=1;
	else
	{
		stepStruct.isSpeedUp=0;
	}


	if((stepStruct.parsData.a2x!=0)||(stepStruct.parsData.a2y!=0))stepStruct.isBrake=1;
	else
	{
		stepStruct.isBrake=0;
	}

	int16_t p1stSubx=stepStruct.parsData.stepX-stepStruct.parsData.p1x;
	int16_t p1stSuby=stepStruct.parsData.stepY-stepStruct.parsData.p1y;
	int16_t p2stSubx=stepStruct.parsData.p2x;
	int16_t p2stSuby=stepStruct.parsData.p2y;

	if(((stepStruct.isSpeedUp)&&(p1stSubx>5 || p1stSuby>5 ))||
			((stepStruct.isBrake)&&(p2stSubx>5 || p2stSuby>5 )))
	{
		stepStruct.isSteady=1;
	}
	else
	{
		stepStruct.isSteady=0;
	}

	if(stepStruct.isSpeedUp)stepStruct.moveState=SPEED_UP;
	else if(stepStruct.isSteady)stepStruct.moveState=STEADY;
	else if(stepStruct.isBrake)stepStruct.moveState=BRAKE;
	else
	{
		stepStruct.moveState=NONE;
	}

	taskStatus=TASK_RUNNING;

	return taskStatus;
}


uint8_t stepperMoveCall()
{
	static uint8_t lock =0;
	if(taskStatus==TASK_COMPLETED)return TASK_COMPLETED;
	else if(lock==1)stepperError(STEPPER_FUNC_STEP_REENTER_ERROR);

	lock=1;
	static uint8_t toggCntrx=0;
	static uint8_t toggCntry=0;
	static uint8_t toggCntrz=0;
	static uint8_t toggCntre=0;

	if(stepStruct.parsData.stepX)stepStruct.toggletx-=stepStruct.toggleT;
	if(stepStruct.parsData.stepY)stepStruct.togglety-=stepStruct.toggleT;
	if(stepStruct.stepZ<stepStruct.parsData.stepZ)stepStruct.toggletz-=stepStruct.toggleT;
	if(stepStruct.parsData.stepE)stepStruct.togglete-=stepStruct.toggleT;

	if((stepStruct.toggletx==0) &&(stepStruct.parsData.stepX!=0))
	{
		stepStruct.halfStepCntrX++;
		if(stepStruct.refCoordinate==COORDINATE_X)stepStruct.halfStepCntrRef++;
		toggleX(stepStruct.parsData.dirX);
		toggCntrx++;
		if((toggCntrx%2)==0)
		{
			stepStruct.stepX++;
			taskStatus=checkMoveEnd();
			moveStepAccelerate(COORDINATE_X);

		}
	}

	if((stepStruct.togglety==0) &&(stepStruct.parsData.stepY!=0))
	{
		stepStruct.halfStepCntrY++;
		if(stepStruct.refCoordinate==COORDINATE_Y)stepStruct.halfStepCntrRef++;
		toggleY(stepStruct.parsData.dirY);
		toggCntry++;
		if((toggCntry%2)==0)
		{
			stepStruct.stepY++;
			taskStatus=checkMoveEnd();
			moveStepAccelerate(COORDINATE_Y);

		}
	}

	if(stepStruct.stepZ<stepStruct.parsData.stepZ)
	{
		stepStruct.halfStepCntrZ++;
		//if(stepStruct.refCoordinate==COORDINATE_Y)stepStruct.halfStepCntrRef++;
		toggleZ(stepStruct.parsData.dirZ);
		toggCntrz++;
		if((toggCntrz%2)==0)
		{
			stepStruct.stepZ++;
			taskStatus=checkMoveEnd();
			//moveStepAccelerate(COORDINATE_Y);

		}
		stepStruct.toggletz=stepStruct.tz/2;
	}





	if((stepStruct.togglete==0) &&(stepStruct.parsData.stepE!=0))
	{
		stepStruct.halfStepCntrE++;
		if(stepStruct.refCoordinate==EXTRUDER)stepStruct.halfStepCntrRef++;
		toggleE(stepStruct.parsData.dirE);
		toggCntre++;
		if((toggCntre%2)==0)
		{
			stepStruct.stepE++;
			taskStatus=checkMoveEnd();
			moveStepAccelerate(EXTRUDER);

		}
	}

	if(taskStatus==TASK_COMPLETED)
	{
		setTimStepCallBack((uint32_t)moveTaskIdle);
		setStepTimT(1*MULT_FACTOR);
	}

	{//update reference time

		if((stepStruct.refCoordinate==COORDINATE_X) && stepStruct.toggletx==0)
		{
			stepStruct.toggletx=stepStruct.tx/2;
			stepStruct.toggleT=stepStruct.toggletx;
		}
		else if((stepStruct.refCoordinate==COORDINATE_Y) && stepStruct.togglety==0)
		{
			stepStruct.togglety=stepStruct.ty/2;
			stepStruct.toggleT=stepStruct.togglety;
		}
		else if((stepStruct.refCoordinate==EXTRUDER) && stepStruct.togglete==0)
		{
			stepStruct.togglete=stepStruct.te/2;
			stepStruct.toggleT=stepStruct.togglete;
		}
	}
	{// update timing x

		if(stepStruct.refCoordinate!=COORDINATE_X)
		{
			float div=((float)stepStruct.halfStepCntrRef+1)/((float)stepStruct.halfStepCntrX+1);
			if(div==stepStruct.multTX)
			{
				stepStruct.toggletx=stepStruct.toggleT;
			}
			else if(div>stepStruct.multTX)
			{
				float subDiv=div-stepStruct.multTX;
				float subT=subDiv*stepStruct.toggleT;
				stepStruct.toggletx=subT;
			}
			else
			{
				stepStruct.toggletx=1000000;
			}
		}
	}

	{//update timing y

		if(stepStruct.refCoordinate!=COORDINATE_Y)
		{
			float div=((float)stepStruct.halfStepCntrRef+1)/((float)stepStruct.halfStepCntrY+1);
			if(div==stepStruct.multTY)
			{
				stepStruct.togglety=stepStruct.toggleT;
			}
			else if(div>stepStruct.multTY)
			{
				float subDiv=div-stepStruct.multTY;
				float subT=subDiv*stepStruct.toggleT;
				stepStruct.togglety=subT;
			}
			else
			{
				stepStruct.togglety=1000000;
			}
		}
	}


	{//update timing z
		/*
		if(stepStruct.refCoordinate!=COORDINATE_Y)
		{
			float div=((float)stepStruct.halfStepCntrRef+1)/((float)stepStruct.halfStepCntrZ+1);
			if(div==stepStruct.multTZ)
			{
				stepStruct.toggletz=stepStruct.toggleT;
			}
			else if(div>stepStruct.multTZ)
			{
				float subDiv=div-stepStruct.multTZ;
				float subT=subDiv*stepStruct.toggleT;
				stepStruct.toggletz=subT;
			}
			else
			{
				stepStruct.toggletz=1000000;
			}
		}
		 */
	}



	{//update timing e

		if(stepStruct.refCoordinate!=EXTRUDER)
		{
			float div=((float)stepStruct.halfStepCntrRef+1)/((float)stepStruct.halfStepCntrE+1);
			if(div==stepStruct.multTE)
			{
				stepStruct.togglete=stepStruct.toggleT;
			}
			else if(div>stepStruct.multTE)
			{
				float subDiv=div-stepStruct.multTE;
				float subT=subDiv*stepStruct.toggleT;
				stepStruct.togglete=subT;
			}
			else
			{
				stepStruct.togglete=1000000;
			}
		}
	}

	float t=99999999;
	if(t>stepStruct.toggletx && stepStruct.toggletx!=0 )
	{
		t=stepStruct.toggletx;
	}
	if(t>stepStruct.togglety && stepStruct.togglety!=0 )
	{
		t=stepStruct.togglety;
	}

	if(t>stepStruct.toggletz&& stepStruct.toggletz!=0)
	{
		t=stepStruct.toggletz;
	}
	if(t>stepStruct.togglete&& stepStruct.togglete!=0)
	{
		t=stepStruct.togglete;
	}
	stepStruct.toggleT=t;
	setStepTimT(t);

	lock=0;
	return taskStatus;

}
void moveStepAccelerate(uint8_t coordinate)
{
	if(taskStatus==TASK_COMPLETED)return;
	switch(stepStruct.moveState)
	{
	case SPEED_UP:
	{

		if((stepStruct.stepX>=stepStruct.parsData.p1x)&&
				(stepStruct.stepY>=stepStruct.parsData.p1y)&&
				(stepStruct.stepE>=stepStruct.parsData.p1e))
		{
			if(stepStruct.isSteady==1)stepStruct.moveState=STEADY;
			else if(stepStruct.isBrake==1)stepStruct.moveState=BRAKE;
			else
			{
				stepStruct.moveState=NONE;
			}


		}
		float subT;
		float subT1;
		float subT2;

		switch(coordinate)
		{
		case COORDINATE_X:
			stepStruct.fx+=(stepStruct.parsData.a1x*stepStruct.tx*60)/MULT_FACTOR;
			stepStruct.tx=getPulsePeriodTx(stepStruct.fx);
			break;
		case COORDINATE_Y:
			stepStruct.fy+=(stepStruct.parsData.a1y*stepStruct.ty*60)/MULT_FACTOR;
			stepStruct.ty=getPulsePeriodTy(stepStruct.fy);
			break;
		case COORDINATE_Z:

			break;
		case EXTRUDER:
			stepStruct.fe+=(stepStruct.parsData.a1e*stepStruct.te*60)/MULT_FACTOR;
			stepStruct.te=getPulsePeriodTy(stepStruct.fe);
			break;
		}
		break;
	}
	case STEADY:

		stepStruct.tx=getPulsePeriodTx(stepStruct.fx);
		stepStruct.ty=getPulsePeriodTy(stepStruct.fy);
		//stepStruct.te=stepStruct.parsData.t2se;
		if(stepStruct.isBrake)
		{
			if((stepStruct.stepX>=stepStruct.parsData.p2x)&&
					(stepStruct.stepY>=stepStruct.parsData.p2y)&&
					(stepStruct.stepE>=stepStruct.parsData.p2e))
			{
				stepStruct.moveState=BRAKE;
			}
		}
		break;

	case BRAKE:
	{
		switch(coordinate)
		{
		case COORDINATE_X:
			stepStruct.fx-=(stepStruct.parsData.a2x*stepStruct.tx*60)/MULT_FACTOR;
			stepStruct.tx=getPulsePeriodTx(stepStruct.fx);
			break;
		case COORDINATE_Y:
			stepStruct.fy-=(stepStruct.parsData.a2y*stepStruct.ty*60)/MULT_FACTOR;
			stepStruct.ty=getPulsePeriodTy(stepStruct.fy);
			break;
		case COORDINATE_Z:

			break;
		case EXTRUDER:
			stepStruct.fe-=(stepStruct.parsData.a2e*stepStruct.te*60)/MULT_FACTOR;
			stepStruct.te=getPulsePeriodTy(stepStruct.fe);
			break;
		}
		break;
	}

	}
}





uint8_t checkMoveEnd()
{
	if((stepStruct.stepX>=stepStruct.parsData.stepX)&&
			(stepStruct.stepY>=stepStruct.parsData.stepY)&&
			(stepStruct.stepZ>=stepStruct.parsData.stepZ)&&
			(stepStruct.stepE>=stepStruct.parsData.stepE))
	{
		return TASK_COMPLETED;
	}
	else
	{
		return TASK_RUNNING;
	}

}


uint8_t steppergetTaskStatus()
{
	return taskStatus;
}


uint8_t stepperMoveCallX()
{
	if(cntr<1000)pdata[cntr++]=timerControl.globalCntr;
	static uint8_t toggCntrX=0;
	if(stepStruct.tx==0)return TASK_IDLE;
	else if(taskStatus==TASK_COMPLETED)return TASK_COMPLETED;
	toggleX(stepStruct.parsData.dirX);
	toggCntrX++;


	if((toggCntrX%2)==0)
	{
		stepStruct.stepX++;
		moveStepAccelerate(COORDINATE_X);
		taskStatus=checkMoveEnd();
		if(taskStatus==TASK_COMPLETED)setTimTX(1*MULT_FACTOR);
		else
		{
			setTimTX((stepStruct.tx/2));
		}
	}
	return taskStatus;
}


uint8_t stepperMoveCallY()
{
	static uint8_t toggCntrY=0;
	if(stepStruct.ty==0)return TASK_IDLE;
	else if(taskStatus==TASK_COMPLETED)return TASK_COMPLETED;
	toggleY(stepStruct.parsData.dirY);
	toggCntrY++;

	if((toggCntrY%2)==0)
	{
		stepStruct.stepY++;
		moveStepAccelerate(COORDINATE_Y);
		taskStatus=checkMoveEnd();
		if(taskStatus==TASK_COMPLETED)setTimTY(1*MULT_FACTOR);
		else
		{
			setTimTY((stepStruct.ty/2));
		}
	}
	return taskStatus;
}


uint8_t stepperMoveCallZ()
{
	static uint8_t toggCntrZ=0;
	if(stepStruct.tz==0)return TASK_IDLE;
	else if(taskStatus==TASK_COMPLETED)return TASK_COMPLETED;
	toggleZ(stepStruct.parsData.dirZ);
	toggCntrZ++;
	if((toggCntrZ%2)==0)
	{
		stepStruct.stepZ++;
		moveStepAccelerate(COORDINATE_Z);
		taskStatus=checkMoveEnd();
		if(taskStatus==TASK_COMPLETED)setTimTZ(0.001);
		else
		{
			setTimTZ(0.001);
		}
	}
	return taskStatus;

}

uint8_t stepperMoveCallE()
{
	static uint8_t toggCntrE=0;
	if(stepStruct.te==0)return TASK_IDLE;
	else if(taskStatus==TASK_COMPLETED)return TASK_COMPLETED;
	toggleE(stepStruct.parsData.dirE);
	toggCntrE++;
	if((toggCntrE%2)==0)
	{
		stepStruct.stepE++;
		moveStepAccelerate(EXTRUDER);
		taskStatus=checkMoveEnd();
		if(taskStatus==TASK_COMPLETED)setTimTE(1*TIME_DIVISION_PER_SEC);
		else
		{
			setTimTE((stepStruct.te/2));
		}
	}
	return taskStatus;
}

static 	G28Struct_ G28Data;

uint8_t G28_MOVE_TO_ORIGIN_func(char *parameters)
{
	// test start
	taskStatus=TASK_COMPLETED;
	return taskStatus;
	// end

	if(taskStatus==TASK_COMPLETED)
	{
		memset(&G28Data,0xff,sizeof(G28Data));

		G28Struct_* G28DataPntr=(G28Struct_*)parameters;

		G28Data.x=G28DataPntr->x;
		G28Data.y=G28DataPntr->y;
		G28Data.z=G28DataPntr->z;

		G28Data.tx=0;
		G28Data.ty=0;
		G28Data.tz=0;
		G28Data.toggletx=0;
		G28Data.togglety=0;
		G28Data.toggletz=0;

		if(G28Data.x==0)G28Data.tx=getPulsePeriodTx(MAXIMUM_START_STOP_FEED_RATE);
		if(G28Data.y==0)G28Data.ty=getPulsePeriodTy(MAXIMUM_START_STOP_FEED_RATE);
		if(G28Data.z==0)G28Data.tz=getPulsePeriodTz(MAXIMUM_START_STOP_FEED_RATE_Z);

		G28Data.toggletx=G28Data.tx/2;
		G28Data.togglety=G28Data.ty/2;
		G28Data.toggletz=G28Data.tz/2;

		float t=10000000;
		if((G28Data.toggletx<t) && (G28Data.tx!=0))t=G28Data.toggletx;
		if((G28Data.togglety<t) && (G28Data.ty!=0))t=G28Data.togglety;
		if((G28Data.toggletz<t) && (G28Data.tz!=0))t=G28Data.toggletz;

		setTimStepCallBack((uint32_t)G28_MOVE_TO_ORIGIN_callBack);
		setStepTimT(t);
		G28Data.toggleT=t;
		taskStatus=TASK_RUNNING;
	}

}


uint8_t G28_MOVE_TO_ORIGIN_callBack(void)
{
	if((G28Data.x==0)&&(readLimitSwitchX()==LIMIT_SWITCH_NOT_PRESSED))G28Data.toggletx-=G28Data.toggleT;
	if((G28Data.y==0)&&(readLimitSwitchY()==LIMIT_SWITCH_NOT_PRESSED))G28Data.togglety-=G28Data.toggleT;
	if((G28Data.z==0)&&(readLimitSwitchZ()==LIMIT_SWITCH_NOT_PRESSED))G28Data.toggletz-=G28Data.toggleT;

	if((G28Data.toggletx==0) && (G28Data.x==0))
	{
		toggleX(0);
		G28Data.toggletx=G28Data.tx/2;
	}
	if((G28Data.togglety==0) && (G28Data.y==0))
	{
		toggleY(0);
		G28Data.togglety=G28Data.ty/2;
	}
	if((G28Data.toggletz==0) && (G28Data.z==0))
	{
		toggleZ(0);
		G28Data.toggletz=G28Data.tz/2;
	}
	if(((G28Data.x!=0)||(readLimitSwitchX()==LIMIT_SWITCH_PRESSED))&&
			((G28Data.y!=0)||(readLimitSwitchY()==LIMIT_SWITCH_PRESSED))&&
			((G28Data.z!=0)||(readLimitSwitchZ()==LIMIT_SWITCH_PRESSED)))
	{
		taskStatus=TASK_COMPLETED;
		setTimStepCallBack((uint32_t)moveTaskIdle);
		setStepTimT(1*MULT_FACTOR); //set t 1 sc
	}
	else
	{
		float t=10000000;
		if((G28Data.toggletx<t) && (G28Data.tx!=0))t=G28Data.toggletx;
		if((G28Data.togglety<t) && (G28Data.ty!=0))t=G28Data.togglety;
		if((G28Data.toggletz<t) && (G28Data.tz!=0))t=G28Data.toggletz;
		setStepTimT(t);
		G28Data.toggleT=t;
	}

	return taskStatus;

}

float getPulsePeriodTx(float feed)
{
	if(feed==0)return 0;
	float t;
	t=(MM_PER_ROTATION_X*MULT_FACTOR*60)/(STEPS_PER_ROTATION_X*deviceControl.microStepX*feed);
	return t;
}

float getPulsePeriodTy(float feed)
{
	if(feed==0)return 0;
	float t;
	t=(MM_PER_ROTATION_Y*MULT_FACTOR*60)/(STEPS_PER_ROTATION_Y*deviceControl.microStepY*feed);
	return t;
}

float getPulsePeriodTz(float feed)
{
	if(feed==0)return 0;
	float t;
	t=(MM_PER_ROTATION_Z*MULT_FACTOR*60)/(STEPS_PER_ROTATION_Z*deviceControl.microStepZ*feed);
	return t;
}

float getPulsePeriodTe(float feed)
{
	if(feed==0)return 0;
	float t;
	t=(MM_PER_ROTATION_E*MULT_FACTOR*60)/(STEPS_PER_ROTATION_E*deviceControl.microStepE*feed);
	return t;
}


uint8_t moveTaskIdle(void)
{
	return TASK_IDLE;
}
void stepperError(uint16_t errorIndex)
{
	while(1);
}

