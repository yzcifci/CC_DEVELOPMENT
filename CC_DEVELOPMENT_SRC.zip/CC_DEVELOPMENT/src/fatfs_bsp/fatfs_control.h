/*
 * fatfs_control.h
 *
 *  Created on: 27 Haz 2018
 *      Author: yzcifci
 */

#ifndef FATFS_BSP_FATFS_CONTROL_H_
#define FATFS_BSP_FATFS_CONTROL_H_

#include "fatfs.h"

extern struct fatfsControl_
{
	char sendText[128];
	uint32_t lineCntr;
	uint8_t endOfPrintRead;
}fatfsControl;
void initFatfs();
void SDcardReadParsTask();

#endif /* FATFS_BSP_FATFS_CONTROL_H_ */
