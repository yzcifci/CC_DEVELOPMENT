/*
 * fatfs_control.c
 *
 *  Created on: 27 Haz 2018
 *      Author: yzcifci
 */

#include "main.h"

FATFS SDFatFs;  /* File system object for SD card logical drive */
FIL MyFile;     /* File object */
char SDPath[4]; /* SD card logical drive path */

struct fatfsControl_ fatfsControl;

FRESULT errorId=0;
void initFatfs()
{
	if(FATFS_LinkDriver(&SD_Driver, SDPath) == 0)
	{
		if(f_mount(&SDFatFs, (TCHAR const*)SDPath, 0) != FR_OK)
		{
			Error_Handler();
		}
		else
		{
			errorId=f_open(&MyFile, "STM32.TXT", FA_READ);
			if(errorId != FR_OK)
			{
				Error_Handler();
			}
		}
	}
}

void SDcardReadParsTask()
{
	static uint8_t parStatus=0;
#if MOVEMENT_TEST_ENABLE
	static uint8_t testStarted=0;
	if(testStarted==0)
	{
		printLine("STARTSYSTEM");
		testStarted=1;
	}
#endif
	if(fatfsControl.endOfPrintRead)return;

	if(f_eof(&MyFile)==0)
	{
		if(parser.bufferStatus!=BUFFER_FULL)
		{

			fatfsControl.lineCntr++;
			if(fatfsControl.lineCntr==1434)
			{
				volatile uint8_t x=0;
				x++;
			}
			f_gets((char*)fatfsControl.sendText,sizeof(fatfsControl.sendText),&MyFile);
			parStatus=pars((char*)fatfsControl.sendText);
			if(parStatus==PARSABLE_VALID_DATA)
			{
				taskPrepare();
				accelerationCorrect();
				parserHeadPlus1();
			}

		}

	}
	else
	{
		fatfsControl.endOfPrintRead=1;
		FATFS_UnLinkDriver(SDPath);
	}



}




