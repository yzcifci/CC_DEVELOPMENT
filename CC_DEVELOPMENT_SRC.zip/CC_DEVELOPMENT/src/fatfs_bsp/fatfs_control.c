/*
 * fatfs_control.c
 *
 *  Created on: 27 Haz 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

FATFS SDFatFs;  /* File system object for SD card logical drive */
FIL MyFile;     /* File object */
char SDPath[4]; /* SD card logical drive path */

uint32_t size=0;
uint32_t track=0;

void fatfsReadSeqTest()
{

	uint8_t rtext[100];
	/*##-1- Link the micro SD disk I/O driver ##################################*/
	if(FATFS_LinkDriver(&SD_Driver, SDPath) == 0)
	{
		/*##-2- Register the file system object to the FatFs module ##############*/
		if(f_mount(&SDFatFs, (TCHAR const*)SDPath, 0) != FR_OK)
		{
			/* FatFs Initialization Error */
			Error_Handler();
		}
		else
		{
			/*##-4- Open an existing text file object with read access #####*/
			if(f_open(&MyFile, "STM32.TXT", FA_READ) != FR_OK)
			{
				/* 'STM32.TXT' file Open for write Error */
				Error_Handler();
			}
			else
			{
				while(f_eof(&MyFile)==0)
				{
					f_gets((char*)rtext,sizeof(rtext),&MyFile);
				}
			}

		}
	}

	/*##-11- Unlink the RAM disk I/O driver ####################################*/
	FATFS_UnLinkDriver(SDPath);
}

FRESULT errorId=0;
void initFatfs()
{
	if(FATFS_LinkDriver(&SD_Driver, SDPath) == 0)
	{
		if(f_mount(&SDFatFs, (TCHAR const*)SDPath, 0) != FR_OK)
		{
			Error_Handler();
		}
		else
		{
			errorId=f_open(&MyFile, "STM32.TXT", FA_READ);
			if(errorId != FR_OK)
			{
				Error_Handler();
			}
		}
	}
}
void fatfsSendLineTest()
{

	uint8_t rtext[100];
	printLine("STARTSYSTEM");
	while(f_eof(&MyFile)==0)
	{

		while(parser.bufferStatus==BUFFER_FULL);
		f_gets((char*)rtext,sizeof(rtext),&MyFile);
		size=MyFile.obj.objsize;
		track=MyFile.fptr;
		pars((char*)rtext);

	}

	FATFS_UnLinkDriver(SDPath);

}


