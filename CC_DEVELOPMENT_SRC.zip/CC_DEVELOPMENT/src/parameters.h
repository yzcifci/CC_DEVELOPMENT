/*
 * parameters.h
 *
 *  Created on: 7 Oca 2018
 *      Author: yzcifci
 */

#include "stm32f4xx_hal.h"


#ifndef PARAMETERS_H_
#define PARAMETERS_H_

//#define ACCELERATION_ENABLE
#define MAXIMUM_START_STOP_FEED_RATE	500	//MM/DK
#define MAXIMUM_FEED_RATE	1000	//MM/DK
#define PI 3.14159265
/*STEP PORTS*/
#define PORT_X1	GPIOA
#define PORT_X2 GPIOA
#define PORT_Y	GPIOA
#define PORT_Z	GPIOA

#define PIN_X1	GPIO_PIN_0
#define PIN_X2	GPIO_PIN_1
#define PIN_Y	GPIO_PIN_2
#define PIN_Z	GPIO_PIN_3


/*ENABLE PORTS*/
#define ENABLE_PORT_X1	GPIOA
#define ENABLE_PORT_X2	GPIOA
#define ENABLE_PORT_Y	GPIOA
#define ENABLE_PORT_Z	GPIOA

#define ENABLE_PIN_X1	GPIO_PIN_0
#define ENABLE_PIN_X2	GPIO_PIN_1
#define ENABLE_PIN_Y	GPIO_PIN_2
#define ENABLE_PIN_Z	GPIO_PIN_3

/* DIRECTION PORTS*/
#define DIR_PORT_X1	GPIOA
#define DIR_PORT_X2	GPIOA
#define DIR_PORT_Y	GPIOA
#define DIR_PORT_Z	GPIOA

#define DIR_PIN_X1	GPIO_PIN_0
#define DIR_PIN_X2	GPIO_PIN_1
#define DIR_PIN_Y	GPIO_PIN_2
#define DIR_PIN_Z	GPIO_PIN_3

#define LASER_SWITCH_PORT	GPIOB
#define LASER_SWITCH_PIN	GPIO_PIN_0

#define COOLANT_SWITCH_PORT	GPIOB
#define COOLANT_SWITCH_PIN	GPIO_PIN_1

#define STEP_ANGLE_X	1.8
#define STEP_ANGLE_Y	1.8
#define STEP_ANGLE_Z	1.8

#define STEPS_PER_ROTATION_X	360/STEP_ANGLE_X
#define STEPS_PER_ROTATION_Y	360/STEP_ANGLE_Y
#define STEPS_PER_ROTATION_Z	360/STEP_ANGLE_Z

#define MM_PER_ROTATION_X	63
#define MM_PER_ROTATION_Y	63
#define MM_PER_ROTATION_Z	63

#define MM_PER_STEP_X		MM_PER_ROTATION_X/STEPS_PER_ROTATION_X
#define MM_PER_STEP_Y		MM_PER_ROTATION_Y/STEPS_PER_ROTATION_Y
#define MM_PER_STEP_Z		MM_PER_ROTATION_Z/STEPS_PER_ROTATION_Z


#define START_COMMENT	'('
#define END_COMMENT		')'
#define MAXIMUM_WORD_SPLIT	16
#define MAXIMUM_WORD_LENGTH	64

#define INCHES_TO_MM	2.54
#define MAXIMUM_LINE_EXECUTE_BUFFER	8



extern float feedRateTable[256];


enum
{
	TASK_COMPLETED,
	TASK_RUNNING,
	TASK_IDLE
};



enum
{
	G00_RAPID_MOVEMENT,
	G01_LINEAR_INTERPOLATION,
	G02_CIRCULAR_CW_INTERPOLATION,
	G03_CIRCULAR_CCW_INTERPOLATION,
	G17_XY_PLANE,
	G20_INCHES_MODE,
	G21_METRIC_MODE,
	G40_CANCEL_RADIUS_COMPENSATION,
	G49_CANCEL_LENGTH_COMPENSATION,
	G90_ABSOLUTE_MODE_SELECT,
	G91_INCREMENTAL_MODE_SELECT,
	M_FUNCTION,
	SPEED,
	TOOL,

	WRONG_PARAMETER

};


enum
{
	METRIC_MODE,
	INCHES_MODE
};
enum
{
	ABSOLUTE_MODE,
	INCREMENTAL_MODE
};
enum
{
	CIRCULAR_CLOCK_WISE,
	CIRCULAR_COUNTER_CLOCK_WISE,

};

enum
{
	DIR_NEGATIVE,
	DIR_POSITIVE
};

enum
{
	COORDINATE_X,
	COORDINATE_Y,
	COORDINATE_Z,
	I,
	J,
	K,
	RADIUS
};


enum
{
	TASK_PARSE_NOT_COMPLETED,
	TASK_PARSE_COMPLETED,

};
enum
{
	LASER_OFF,
	LASER_ON
};

enum
{
	COOLANT_OFF,
	COOLANT_ON
};

typedef struct positionXYZ_
{
	float X;
	float Y;
	float Z;
}positionXYZ;


typedef struct
{
	uint32_t stepX;
	uint32_t stepY;
	uint32_t stepZ;
}stepPosXYZ;

typedef struct stepPosXY_
{
	uint32_t stepX;
	uint32_t stepY;
}stepPosXY;

typedef struct
{
	positionXYZ mmPosition;
	stepPosXYZ stepPosition;
}uniPosXYZ;


uint32_t mmToStepX(float mm);
uint32_t mmToStepY(float mm);
uint32_t mmToStepZ(float mm);
float stepTommX(int64_t step);
float stepTommY(int64_t step);
float stepTommZ(int64_t step);
uint16_t getPulsePeriodX(float feedRateX);
uint16_t getPulsePeriodY(float feedRateY);
uint16_t getPulsePeriodZ(float feedRateZ);
float arctan(uint16_t stepX1, uint16_t stepY1, uint16_t stepX2, uint16_t stepY2);
float getLinearmmLength(float startX, float startY, float stopX, float stopY);
void updataPosStepToMM(uniPosXYZ* position);
uint32_t absDifferentiate(uint32_t val1, uint32_t val2);

#endif /* PARAMETERS_H_ */
