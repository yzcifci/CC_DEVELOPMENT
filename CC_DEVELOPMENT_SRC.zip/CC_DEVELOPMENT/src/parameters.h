/*
 * parameters.h
 *
 *  Created on: 7 Oca 2018
 *      Author: yzcifci
 */

#include "stm32f4xx_hal.h"


#ifndef PARAMETERS_H_
#define PARAMETERS_H_

//#define ACCELERATION_ENABLE
#define MAXIMUM_START_STOP_FEED_RATE			4000				//MM/DK
#define MAXIMUM_EXTRUDER_START_STOP_FEED_RATE	4000				//MM/DK
#define MAXIMUM_FEED_RATE						4000				//MM/DK
#define TIME_DIVISION_PER_SEC					10000 				//10000:FOR 100 us
#define PI 3.14159265
/*STEP PORTS*/
#define PORT_X1	GPIOB
#define PORT_Y	GPIOB
#define PORT_Z	GPIOB
#define PORT_E	GPIOB

#define PIN_X1	GPIO_PIN_0
#define PIN_Y	GPIO_PIN_2
#define PIN_Z	GPIO_PIN_3
#define PIN_E	GPIO_PIN_14


/*ENABLE PORTS*/
#define ENABLE_PORT_X1	GPIOB
#define ENABLE_PORT_Y	GPIOB
#define ENABLE_PORT_Z	GPIOB
#define ENABLE_PORT_E	GPIOB

#define ENABLE_PIN_X1	GPIO_PIN_4
#define ENABLE_PIN_Y	GPIO_PIN_6
#define ENABLE_PIN_Z	GPIO_PIN_7
#define ENABLE_PIN_E	GPIO_PIN_15

/* DIRECTION PORTS*/
#define DIR_PORT_X1	GPIOB
#define DIR_PORT_Y	GPIOB
#define DIR_PORT_Z	GPIOB
#define DIR_PORT_E	GPIOC

#define DIR_PIN_X1	GPIO_PIN_8
#define DIR_PIN_Y	GPIO_PIN_10
#define DIR_PIN_Z	GPIO_PIN_11
#define DIR_PIN_E	GPIO_PIN_1

#define EXTRUDER_HEATER_PORT GPIOC
#define EXTRUDER_HEATER_PIN	GPIO_PIN_4

#define EXTRUDER_COOLER_PORT GPIOC
#define EXTRUDER_COOLER_PIN	GPIO_PIN_5

#define HEATBED_HEATER_PORT	GPIOC
#define HEATBED_HEATER_PIN	GPIO_PIN_6



#define STEP_ANGLE_X	1.8
#define STEP_ANGLE_Y	1.8
#define STEP_ANGLE_Z	1.8
#define STEP_ANGLE_E	1.8


#define STEPS_PER_ROTATION_X	360/STEP_ANGLE_X
#define STEPS_PER_ROTATION_Y	360/STEP_ANGLE_Y
#define STEPS_PER_ROTATION_Z	360/STEP_ANGLE_Z
#define STEPS_PER_ROTATION_E	360/STEP_ANGLE_E

#define MM_PER_ROTATION_X	60
#define MM_PER_ROTATION_Y	60
#define MM_PER_ROTATION_Z	60
#define MM_PER_ROTATION_E	3.14

#define MM_PER_STEP_X		MM_PER_ROTATION_X/STEPS_PER_ROTATION_X
#define MM_PER_STEP_Y		MM_PER_ROTATION_Y/STEPS_PER_ROTATION_Y
#define MM_PER_STEP_Z		MM_PER_ROTATION_Z/STEPS_PER_ROTATION_Z
#define MM_PER_STEP_E		MM_PER_ROTATION_E/STEPS_PER_ROTATION_E

#define ZERO_POINT_LENGTH_X	0
#define ZERO_POINT_LENGTH_Y	0
#define ZERO_POINT_LENGTH_Z	0	//mm

#define WORK_AREA_START_MM_X	0
#define WORK_AREA_STOP_MM_X		1000	//mm

#define WORK_AREA_START_MM_Y	0
#define WORK_AREA_STOP_MM_Y		1000	//mm

#define WORK_AREA_START_MM_Z	0
#define WORK_AREA_STOP_MM_Z		200	//mm

#define START_COMMENT	';'
#define END_CHAR		'\n'
#define MAXIMUM_WORD_SPLIT	16
#define MAXIMUM_WORD_LENGTH	64

#define INCHES_TO_MM	2.54
#define MAXIMUM_LINE_EXECUTE_BUFFER	8

#define MAXIMUM_HEATBED_WAIT_TIME			5*60*1000*10 //5DK in terms of 100us
#define MAXIMUM_EXTRUDER_HEAT_WAIT_TIME		5*60*1000*10 //5DK in terms of 100us
#define EXTRUDER_TEMP_HYSTER	5
#define BED_TEMP_HYSTER	5


extern float feedRateTable[256];


enum
{
	TASK_COMPLETED,
	TASK_RUNNING,
	TASK_IDLE,
	TASK_EXECUTE_ERROR,
};



enum
{
	G00_RAPID_MOVEMENT,
	G01_LINEAR_INTERPOLATION,
	G20_INCHES_MODE,
	G21_METRIC_MODE,
	G28_MOVE_TO_ORIGIN,
	G90_ABSOLUTE_MODE_SELECT,
	G91_INCREMENTAL_MODE_SELECT,
	G92_SET_POSITION,
	M82_SET_EXTRUDER_ABSOLUTE_MODE,
	M104_SET_EXTRUDER_TEMP,
	M107_FAN_OFF,
	M117_DISPLAY_MESSAGE,
	M109_SET_WAIT_EXTRUDER_TEMP,
	M190_SET_WAIT_BED_TEMP,
	WRONG_PARAMETER

};


enum
{
	METRIC_MODE,
	INCHES_MODE
};
enum
{
	ABSOLUTE_MODE,
	INCREMENTAL_MODE
};
enum
{
	CIRCULAR_CLOCK_WISE,
	CIRCULAR_COUNTER_CLOCK_WISE,

};

enum
{
	DIR_NEGATIVE,
	DIR_POSITIVE
};

enum
{
	COORDINATE_X,
	COORDINATE_Y,
	COORDINATE_Z,
	EXTRUDER,
	I,
	J,
	K,
	RADIUS
};


enum
{
	TASK_PARSE_NOT_COMPLETED,
	TASK_PARSE_COMPLETED,

};
enum
{
	LASER_OFF,
	LASER_ON
};

enum
{
	COOLANT_OFF,
	COOLANT_ON
};

enum
{
	PARAMETER_X_OUTSIDE_WORK_AREA,
	PARAMETER_Y_OUTSIDE_WORK_AREA,
	PARAMETER_Z_OUTSIDE_WORK_AREA
};

enum
{
	EXTURDER_HEATER_OFF,
	EXTRUDER_HEATER_ON
};

enum
{
	EXTURDER_COOLER_OFF,
	EXTRUDER_COOLER_ON
};

enum
{
	HEATBED_HEATER_OFF,
	HEATBED_HEATER_ON
};
typedef struct positionXYZE_
{
	float X;
	float Y;
	float Z;
	float E;
}positionXYZE;


typedef struct
{
	uint32_t stepX;
	uint32_t stepY;
	uint32_t stepZ;
	uint32_t stepE;
}stepPosXYZE;

typedef struct stepPosXY_
{
	uint32_t stepX;
	uint32_t stepY;
}stepPosXY;

typedef struct
{
	positionXYZE mmPosition;
	stepPosXYZE stepPosition;
}uniPosXYZE;




uint32_t mmToStepX(float mm);
uint32_t mmToStepY(float mm);
uint32_t mmToStepZ(float mm);
uint32_t mmToStepE(float mm);
float stepTommX(int64_t step);
float stepTommY(int64_t step);
float stepTommZ(int64_t step);
void setInchToMM (positionXYZE *position);
uint16_t getPulsePeriodX(float feedRateX);
uint16_t getPulsePeriodY(float feedRateY);
uint16_t getPulsePeriodZ(float feedRateZ);
float arctan(uint32_t stepX1, uint32_t stepY1, uint32_t stepX2, uint32_t stepY2);
float angleToRad(float angle);
float getLinearmmLength(float startX, float startY, float stopX, float stopY);
void updataPosStepToMM(uniPosXYZE* position);
uint32_t absDifferentiate(uint32_t val1, uint32_t val2);
void parameterError();
char getDir(uint32_t startPosAxis, uint32_t stopPosAxis);

#endif /* PARAMETERS_H_ */
