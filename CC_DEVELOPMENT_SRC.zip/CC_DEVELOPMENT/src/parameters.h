/*
 * parameters.h
 *
 *  Created on: 7 Oca 2018
 *      Author: yzcifci
 */




#ifndef PARAMETERS_H_
#define PARAMETERS_H_



#define PARSER_PARAMETER_SIZE					64
#define MOVEMENT_TABLE_PARAMETER_SIZE			32

#define MAXIMUM_XY_COORDINATE_FEED_DIFF			750				//MM/DK
#define MAXIMUM_START_STOP_FEED_RATE			2000				//MM/DK
#define MAXIMUM_FEED_RATE						20000				//MM/DK
#define MIN_START_FEED							100				//MM/DK
#define MAXIMUM_START_STOP_FEED_RATE_Z			100				//MM/DK
#define TIME_DIVISION_PER_SEC					25000 				//10000:FOR 100 us
#define PI 3.14159265

#define STEP_DRIVER_TYPE_TMC2208 				0
#define STEP_DRIVER_TYPE_A4988					1
#define STEP_DRIVER_TYPEX						STEP_DRIVER_TYPE_TMC2208
#define STEP_DRIVER_TYPEY						STEP_DRIVER_TYPE_TMC2208
#define STEP_DRIVER_TYPEZ						STEP_DRIVER_TYPE_TMC2208
#define STEP_DRIVER_TYPEE						STEP_DRIVER_TYPE_TMC2208


/*STEP PORTS*/
#define PORT_X1	GPIOD
#define PORT_Y	GPIOA
#define PORT_Z	GPIOB
#define PORT_E	GPIOD

#define PIN_X1	GPIO_PIN_5
#define PIN_Y	GPIO_PIN_3
#define PIN_Z	GPIO_PIN_12
#define PIN_E	GPIO_PIN_10


/*ENABLE PORTS*/
#define ENABLE_PORT_X1	GPIOE
#define ENABLE_PORT_Y	GPIOE
#define ENABLE_PORT_Z	GPIOE
#define ENABLE_PORT_E	GPIOA

#define ENABLE_PIN_X1	GPIO_PIN_1
#define ENABLE_PIN_Y	GPIO_PIN_3
#define ENABLE_PIN_Z	GPIO_PIN_10
#define ENABLE_PIN_E	GPIO_PIN_8

/* DIRECTION PORTS*/
#define DIR_PORT_X1	GPIOD
#define DIR_PORT_Y	GPIOA
#define DIR_PORT_Z	GPIOE
#define DIR_PORT_E	GPIOD

#define DIR_PIN_X1	GPIO_PIN_3
#define DIR_PIN_Y	GPIO_PIN_5
#define DIR_PIN_Z	GPIO_PIN_15
#define DIR_PIN_E	GPIO_PIN_8


#define PORT_SLP_CLKX	GPIOA
#define PORT_SLP_CLKY	GPIOA
#define PORT_SLP_CLKZ	GPIOB
#define PORT_SLP_CLKE   GPIOD

#define PIN_SLP_CLKX	GPIO_PIN_12
#define PIN_SLP_CLKY	GPIO_PIN_2
#define PIN_SLP_CLKZ	GPIO_PIN_13
#define PIN_SLP_CLKE    GPIO_PIN_13

#define PORT_RST_PDNX	GPIOD
#define PORT_RST_PDNY	GPIOA
#define PORT_RST_PDNZ	GPIOB
#define PORT_RST_PDNE   GPIOD

#define PIN_RST_PDNX	GPIO_PIN_1
#define PIN_RST_PDNY	GPIO_PIN_4
#define PIN_RST_PDNZ	GPIO_PIN_11
#define PIN_RST_PDNE    GPIO_PIN_15


/*LIMIT SWITCHES*/
#define LIMIT_SWITCH_PORT_X	GPIOB
#define LIMIT_SWITCH_PORT_Y	GPIOD
#define LIMIT_SWITCH_PORT_Z	GPIOD

#define LIMIT_SWITCH_PIN_X	GPIO_PIN_15
#define LIMIT_SWITCH_PIN_Y	GPIO_PIN_9
#define LIMIT_SWITCH_PIN_Z	GPIO_PIN_11


/* MS PINS OF THE X STEP DRIVER*/
#define PORTX_MS1	GPIOB
#define PORTX_MS2	GPIOB
#define PORTX_MS3	GPIOD

#define PORTX_PIN_MS1	GPIO_PIN_9
#define PORTX_PIN_MS2	GPIO_PIN_5
#define PORTX_PIN_MS3	GPIO_PIN_7

/* MS PINS OF THE Y STEP DRIVER*/
#define PORTY_MS1	GPIOE
#define PORTY_MS2	GPIOC
#define PORTY_MS3	GPIOC

#define PORTY_PIN_MS1	GPIO_PIN_5
#define PORTY_PIN_MS2	GPIO_PIN_13
#define PORTY_PIN_MS3	GPIO_PIN_1

/* MS PINS OF THE Z STEP DRIVER*/
#define PORTZ_MS1	GPIOE
#define PORTZ_MS2	GPIOE
#define PORTZ_MS3	GPIOB

#define PORTZ_PIN_MS1	GPIO_PIN_12
#define PORTZ_PIN_MS2	GPIO_PIN_14
#define PORTZ_PIN_MS3	GPIO_PIN_10

/* MS PINS OF THE E STEP DRIVER*/
#define PORTE_MS1	GPIOC
#define PORTE_MS2	GPIOC
#define PORTE_MS3	GPIOD

#define PORTE_PIN_MS1	GPIO_PIN_6
#define PORTE_PIN_MS2	GPIO_PIN_7
#define PORTE_PIN_MS3	GPIO_PIN_12

#define PORT_WORKING_LED GPIOA
#define PIN_WORKING_LED GPIO_PIN_6

#define PORT_TEST_LED GPIOA
#define PIN_TEST_LED GPIO_PIN_7







#define EXTRUDER_HEATER_PORT GPIOB
#define EXTRUDER_HEATER_PIN	GPIO_PIN_3

#define EXTRUDER_COOLER_PORT GPIOE
#define EXTRUDER_COOLER_PIN	GPIO_PIN_0

#define HEATBED_HEATER_PORT	GPIOD
#define HEATBED_HEATER_PIN	GPIO_PIN_6



#define STEP_ANGLE_X	1.8
#define STEP_ANGLE_Y	1.8
#define STEP_ANGLE_Z	1.8
#define STEP_ANGLE_E	1.8


#define STEPS_PER_ROTATION_X	360/STEP_ANGLE_X
#define STEPS_PER_ROTATION_Y	360/STEP_ANGLE_Y
#define STEPS_PER_ROTATION_Z	360/STEP_ANGLE_Z
#define STEPS_PER_ROTATION_E	360/STEP_ANGLE_E

#define MM_PER_ROTATION_X	32
#define MM_PER_ROTATION_Y	32
#define MM_PER_ROTATION_Z	8
//edit test start extruder mm per rot
//#define MM_PER_ROTATION_E	33.3
#define MM_PER_ROTATION_E	32
//test end
#define MM_PER_STEP_X		MM_PER_ROTATION_X/STEPS_PER_ROTATION_X
#define MM_PER_STEP_Y		MM_PER_ROTATION_Y/STEPS_PER_ROTATION_Y
#define MM_PER_STEP_Z		MM_PER_ROTATION_Z/STEPS_PER_ROTATION_Z
#define MM_PER_STEP_E		MM_PER_ROTATION_E/STEPS_PER_ROTATION_E

#define STEP_PER_MM_X		STEPS_PER_ROTATION_X/MM_PER_ROTATION_X
#define STEP_PER_MM_Y		STEPS_PER_ROTATION_Y/MM_PER_ROTATION_Y
#define STEP_PER_MM_Z		STEPS_PER_ROTATION_Z/MM_PER_ROTATION_Z
#define STEP_PER_MM_E		STEPS_PER_ROTATION_E/MM_PER_ROTATION_E

#define ZERO_POINT_LENGTH_X	0
#define ZERO_POINT_LENGTH_Y	0
#define ZERO_POINT_LENGTH_Z	0	//mm

#define WORK_AREA_START_MM_X	0
#define WORK_AREA_STOP_MM_X		1000	//mm

#define WORK_AREA_START_MM_Y	0
#define WORK_AREA_STOP_MM_Y		1000	//mm

#define WORK_AREA_START_MM_Z	0
#define WORK_AREA_STOP_MM_Z		200	//mm

#define START_COMMENT	';'
#define END_CHAR		'\n'
#define MAXIMUM_WORD_SPLIT	16
#define MAXIMUM_WORD_LENGTH	64

#define INCHES_TO_MM	2.54
#define MAXIMUM_LINE_EXECUTE_BUFFER	8

#define MAXIMUM_HEATBED_WAIT_TIME			6*60*1000 //5DK in terms of 100us
#define MAXIMUM_EXTRUDER_HEAT_WAIT_TIME		6*60*1000 //5DK in terms of 100us
#define EXTRUDER_TEMP_HYSTER	0
#define BED_TEMP_HYSTER	5

#define EXTRUDER_MIN_TEMP	0;
#define EXTRUDER_MAX_TEMP	300;

#define HEATBED_MIN_TEMP	0;
#define HEATBED_MAX_TEMP	300;

#define MULT_FACTOR			100000



enum
{
	MAXIMUM_WORD_SPLIT_ERROR,
	MAXIMUM_WORD_LENGTH_ERROR,
	WRONG_START_LETTER_ERROR,
	WRONG_PARAMETER_ERROR,
	WRONG_TASK_ERROR,
	STEP_MOVEMENT_START_ACCELERATE_ERROR,
	TIMER_SET_PERIOD_ERROR,
	STEPPER_FUNC_STEP_REENTER_ERROR,
	STEPPER_MOVEMENT_COORDINATION_ERROR,
	PARAMETER_INDEX_ADDITION_SUBTRACTION_ERROR,
	ACCELERATION_ANALAYZER_ACCELERATION_EXCEEDING_ERROR,
	MOVEMENT_ANALAYZER_FEEDRATE_EXCEEDING_ERROR,
	STEP_MOVEMENT_START_FEED_ERROR,
	XYE_STEP_SYNCHRONISATION_ERROR,
	XYZE_STEP_SYNCHRONISATION_ERROR,
	EQUATION_SOLVER_MINUS_DELTA_ERROR,
	EQUATION_SOLVER_TWO_ROOT_RESULT_ERROR,
	EQUATION_SOLVER_NO_ROOT_FOUND_ERROR,
	PARSER_BUFFER_EMPTY_INDEX_BELOV_ZERO_ERROR,
	PARSER_BUFFER_EMPTY_INDEX_ABOVE_MAX_ERROR,
	PARSER_BUFFER_FILLED_INDEX_BELOV_ZERO_ERROR,
	PARSER_BUFFER_FILLED_INDEX_ABOVE_MAX_ERROR,
	DATA_COULDNT_BE_RPOCESSED_FOR_ACCELERATION_ANALAYZE,
};



enum
{
	ENABLE_STEPPER,
	DISABLE_STEPPER
};
enum
{
	TASK_COMPLETED,
	TASK_XYE_COMPLETED,
	TASK_RUNNING,
	TASK_IDLE,
	TASK_EXECUTE_ERROR,
};



enum
{
	G00_RAPID_MOVEMENT,
	G01_LINEAR_INTERPOLATION,
	G20_INCHES_MODE,
	G21_METRIC_MODE,
	G28_MOVE_TO_ORIGIN,
	G90_ABSOLUTE_MODE_SELECT,
	G91_INCREMENTAL_MODE_SELECT,
	G92_SET_POSITION,
	M82_SET_EXTRUDER_ABSOLUTE_MODE,
	M84_STOP_STEPPERS_IDLE,
	M104_SET_EXTRUDER_TEMP,
	M105_REQUEST_TEMP,
	M106_FAN_ON,
	M107_FAN_OFF,
	M109_SET_WAIT_EXTRUDER_TEMP,
	M117_DISPLAY_MESSAGE,
	M140_SET_BED_TEMP,
	M190_SET_WAIT_BED_TEMP,
	M204_SET_ACCELERATION,
	WRONG_PARAMETER

};


enum
{
	METRIC_MODE,
	INCHES_MODE
};
enum
{
	ABSOLUTE_MODE,
	INCREMENTAL_MODE
};
enum
{
	CIRCULAR_CLOCK_WISE,
	CIRCULAR_COUNTER_CLOCK_WISE,

};

enum
{
	DIR_NEGATIVE,
	DIR_POSITIVE
};

enum
{
	COORDINATE_X,
	COORDINATE_Y,
	COORDINATE_Z,
	EXTRUDER,
	I,
	J,
	K,
	RADIUS
};


enum
{
	TASK_PARSE_NOT_COMPLETED,
	TASK_PARSE_COMPLETED,

};
enum
{
	LASER_OFF,
	LASER_ON
};

enum
{
	COOLANT_OFF,
	COOLANT_ON
};

enum
{
	PARAMETER_X_OUTSIDE_WORK_AREA,
	PARAMETER_Y_OUTSIDE_WORK_AREA,
	PARAMETER_Z_OUTSIDE_WORK_AREA,
	BINARY_SEARCH_INDEX_ERROR,
	EXTRUDER_TEMP_READ_ERROR,
	HEATBED_TEMP_READ_ERROR,
	WRONG_MICROSTEP_ERROR
};

enum
{
	EXTURDER_HEATER_OFF,
	EXTRUDER_HEATER_ON
};

enum
{
	EXTURDER_COOLER_OFF,
	EXTRUDER_COOLER_ON
};

enum
{
	HEATBED_HEATER_OFF,
	HEATBED_HEATER_ON
};

enum
{
	LIMIT_SWITCH_NOT_PRESSED,
	LIMIT_SWITCH_PRESSED

};


enum
{
	DIR_BACKWARD_X,
	DIR_FORWARD_X

};

enum
{
	DIR_BACKWARD_Y,
	DIR_FORWARD_Y
};

enum
{
	DIR_FORWARD_Z,
	DIR_BACKWARD_Z
};


enum
{
	DIR_BACKWARD_E,
	DIR_FORWARD_E
};

enum
{
	HEAT_BED_HEAT_OFF,
	HEAT_BED_HEAT_UP,
	HEAT_BED_HEAT_UP_THEN_STEADY,
	HEAT_BED_HEAT_STEADY,
};

enum
{
	EXT_HEAT_OFF,
	EXT_HEAT_UP,
	EXT_HEAT_UP_THEN_STEADY,
	EXT_HEAT_STEADY,
};

typedef struct positionXYZE_
{
	float X;
	float Y;
	float Z;
	float E;
}positionXYZE;


typedef struct
{
	int32_t stepX;
	int32_t stepY;
	int32_t stepZ;
	int32_t stepE;
}stepPosXYZE;

typedef struct stepPosXY_
{
	int32_t stepX;
	int32_t stepY;
}stepPosXY;

typedef struct
{
	positionXYZE mmPosition;
	stepPosXYZE stepPosition;
}uniPosXYZE;




int32_t mmToStepX(float mm);
int32_t mmToStepY(float mm);
int32_t mmToStepZ(float mm);
int32_t mmToStepE(float mm);
float stepTommX(int64_t step);
float stepTommY(int64_t step);
float stepTommZ(int64_t step);
void setInchToMM (positionXYZE *position);

float getPulsePeriodXFrac(float feedRateX);
float getPulsePeriodYFrac(float feedRateY);
float getPulsePeriodEFrac(float feedRateE);

uint16_t getPulsePeriodX(float feedRateX);
uint16_t getPulsePeriodY(float feedRateY);
uint16_t getPulsePeriodZ(float feedRateZ);
float arctan(uint32_t stepX1, uint32_t stepY1, uint32_t stepX2, uint32_t stepY2);
float arctanFloatInpRad0_90(float x1, float y1, float x2, float y2);
float arctanFloatInpRad(float x1, float y1, float x2, float y2);
float angleToRad(float angle);
float getAngleFromMmPos(float subX, float subY);
float getAngleFromStepPos(int32_t subX, int32_t subY);
float getLinearmmLength(float startX, float startY, float stopX, float stopY);
void updataPosStepToMM(uniPosXYZE* position);
uint32_t absDifferentiate(uint32_t val1, uint32_t val2);
void parameterError(uint16_t index);
char getDir(uint32_t startPosAxis, uint32_t stopPosAxis);
uint16_t plusIndex(uint16_t index,uint16_t buffSize);
uint16_t minusIndex(uint16_t index,uint16_t buffSize);
uint16_t addSubtractIndex(uint16_t index,uint16_t buffSize,int16_t size);
uint16_t getIndex(uint16_t currentIndex, int16_t offset, uint16_t fullScale);
uint16_t binarySearch(uint16_t* array, uint16_t size, uint16_t search);
#endif /* PARAMETERS_H_ */
