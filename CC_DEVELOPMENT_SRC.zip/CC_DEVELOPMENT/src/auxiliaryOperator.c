/*
 * auxiliaryOperator.c
 *
 *  Created on: 16 �ub 2018
 *      Author: yzcifci
 */

#include "task_operator_interface.h"

struct toolChangeController_ toolChangeController;


uint8_t MfunctionExecuter(uint8_t mFunction)
{
	switch(mFunction)
	{
	case 0:

		break;
	case 1:

		break;
	case 2:

		break;
	case 3:

		break;

	case 4:

		break;

	case 5:


		break;
	case 6:  //tool change function
//		status=toolChangeRoutine(Gparser.TOOL);
		return TASK_COMPLETED;
		break;

	case 7:
		break;

	case 8:
		return TASK_COMPLETED;

	case 9:
		return TASK_COMPLETED;

	default:
		break;

	}
	return TASK_COMPLETED;
}



//uint8_t toolChangeRoutine(uint8_t tool)
//{
//	uint8_t status;
//	switch (toolChangeController.state)
//	{
//	case TOOL_CHANGE_START:
//		toolChangeStart(tool);
//		toolChangeController.state=TOOL_GOTO_CHANGE_POSITION;
//		return TASK_RUNNING;
//
//	case TOOL_GOTO_CHANGE_POSITION:
//		toolChangeController.state=toolGoToChangePosition();
//		return TASK_RUNNING;
//	case TOOL_GOTO_PUT_POSITION:
//		toolChangeController.state=toolChangePerform(toolChangeController.tool);
//
//	}
//}
//
//
//uint8_t toolGoToPosition()
//{
//	switch(toolChangeController.positionControlState)
//	{
//	case GOTO_POSITION_START:
//		goToPositionStart(toolChangeController.tool);
//		toolChangeController.positionControlState=GOTO_POSITION_RUNNING;
//		break;
//	case GOTO_POSITION_RUNNING:
//		toolChangeController.positionControlState=goToPositionRun(toolChangeController.tool);
//		break;
//	case GOTO_POSITION_END:
//		break;
//
//
//	}
//}
//
//uint8_t goToPositionRun()
//{
//	uint8_t status;
//	status= linearInterPolationPeriodicCall();
//	if(status==TASK_COMPLETED)return GOTO_POSITION_RUNNING;
//	return GOTO_POSITION_END;
//}
//void goToPositionStart(uint8_t tool)
//{
//	switch (tool)
//	{
//	case 1:
//		taskOperatorPrepare.linearInterPolationParameters.stopPos.stepX=mmToStepX(T1_POSITION_X);
//		taskOperatorPrepare.linearInterPolationParameters.stopPos.stepY=mmToStepY(T1_POSITION_Y);
//		taskOperatorPrepare.linearInterPolationParameters.stopPos.stepZ=mmToStepZ(T1_POSITION_Z-T1_POSITION_Z_PUT_OFFSET);
//		startLinearInterPolation(taskOperator.currentPos.stepPosition,
//				taskOperatorPrepare.linearInterPolationParameters.stopPos, MAXIMUM_START_STOP_FEED_RATE);
//	}
//}
//uint8_t toolGoToChangePosition()
//{
//	uint8_t status;
//	status= linearInterPolationPeriodicCall();
//	if(status==TASK_COMPLETED)return TOOL_GOTO_PUT_POSITION;
//	return TOOL_GOTO_CHANGE_POSITION;
//}
//
//
//void toolChangeStart(uint8_t tool)
//{
//	memset(toolChangeController, 0x0, sizeof(toolChangeController));
//	toolChangeController.tool=tool;
//}
//



uint8_t setSpeedExecuter(uint16_t speed)
{
	//todo setSpeedExecuter will be inserted here
	return TASK_COMPLETED;
}
