/*
 * serialCom.h
 *
 *  Created on: 13 �ub 2018
 *      Author: yzcifci
 */

#ifndef SERIALCOM_H_
#define SERIALCOM_H_
#include "stm32f4xx_hal.h"
#include "parameters.h"

/*
 * uart.h
 *
 *  Created on: 18 Oca 2018
 *      Author: yzcifci
 */

extern UART_HandleTypeDef UartHandle;
enum
{
	SERIAL_PORT_INIT_ERROR
};
void uartInit();
extern void serialPrint(char *pData,uint16_t Size );
void printLine(char *data);
void putChar(char data);
void uartTest();
void HAL_UART_MspInit(UART_HandleTypeDef* huart);
void USART2_IRQHandler(void);
void driverError(uint8_t index);
HAL_StatusTypeDef UART_WaitOnFlagUntilTimeoutX(UART_HandleTypeDef *huart, uint32_t Flag, FlagStatus Status, uint32_t Tickstart, uint32_t Timeout);



#endif /* SERIALCOM_H_ */
