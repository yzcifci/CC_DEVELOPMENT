/*
 * movement_control.h
 *
 *  Created on: 10 Oca 2018
 *      Author: yzcifci
 */

#ifndef MOVEMENT_CONTROL_H_
#define MOVEMENT_CONTROL_H_



#include "parameters.h"
#include "Gparser.h"


extern struct taskOperator_
{
	uint8_t task;
	uint8_t taskSubIndex;
	uint8_t currentTaskStatus;
	uniPosXYZE currentPos;

}taskOperator;

extern struct taskOperatorPrepare_
{
	uint16_t SPEEDparameter;
	uint16_t TOOLparameter;
	uint16_t M190_SET_WAIT_BED_TEMP_parameter;
	uint16_t M104_SET_EXTRUDER_TEMP_parameter;
	uint16_t M109_SET_WAIT_EXTRUDER_TEMP_parameter;
	char M117_DISPLAY_MESSAGE_parameter[64];



	char MFUNCTIONtaskParameter;

	struct
	{
		float feedRate;
		stepPosXYZE stopPos;
	}linearInterPolationParameters;

	struct
	{
		float feedRate;
		stepPosXY stopPos;
		stepPosXY centerPos;
		char direction;
		float radius;
	}circularInterPolationParameters;
}taskOperatorPrepare;

void initTaskOperator();
void taskStart();
void periodicMovementControl();
void taskController();
char taskQueueCheck();
void completeTask();
void updateLastTaskPosition();
void getTaskParameters(uint8_t task, uint8_t index);
void updatePositions(stepPosXYZE position);
void setCircularInterpolationIJparameters(stepPosXYZE currentPos,circularParameterPrototype *parameters);
void initailizeTaskParameters();
void _Error_Handler(char * file, int line);

#endif /* MOVEMENT_CONTROL_H_ */
