/*
 * movement_control.h
 *
 *  Created on: 10 Oca 2018
 *      Author: yzcifci
 */

#ifndef MOVEMENT_CONTROL_H_
#define MOVEMENT_CONTROL_H_



#include "parameters.h"
#include "Gparser.h"


extern struct taskOperator_
{
	uint8_t task;
	uint8_t taskSubIndex;
	uint8_t currentTaskStatus;
	uniPosXYZ currentPos;

}taskOperator;

extern struct taskOperatorPrepare_
{
	uint16_t SPEEDparameter;
	uint16_t TOOLparameter;
	char MFUNCTIONtaskParameter;

	struct
	{
		float feedRate;
		stepPosXYZ stopPos;
	}linearInterPolationParameters;

	struct
	{
		float feedRate;
		stepPosXY stopPos;
		stepPosXY centerPos;
		char direction;
		float radius;
	}circularInterPolationParameters;
}taskOperatorPrepare;

void initTaskOperator();
void taskStart();
void periodicMovementControl();
void taskController();
char taskQueueCheck();
void completeTask();
void updateLastTaskPosition();
void getTaskParameters(uint8_t task, uint8_t index);
void setCircularInterpolationIJparameters(stepPosXYZ currentPos,circularParameterPrototype *parameters);
void initailizeTaskParameters();
void _Error_Handler(char * file, int line);

#endif /* MOVEMENT_CONTROL_H_ */
