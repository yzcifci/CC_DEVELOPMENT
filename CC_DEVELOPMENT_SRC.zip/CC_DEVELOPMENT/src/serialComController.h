/*
 * serialComController.h
 *
 *  Created on: 13 �ub 2018
 *      Author: yzcifci
 */
#include "parameters.h"


#ifndef SERIALCOMCONTROLLER_H_
#define SERIALCOMCONTROLLER_H_
#define MAXIMUM_RECEIVE_BUFFER_LENGTH	128
extern struct serialInterFace_
{

	uint8_t RxBuffer[MAXIMUM_RECEIVE_BUFFER_LENGTH];
	uint16_t RxCounter;
	uint16_t lineCntr;

}serialInterFace;


void initSerialCom();
void resetSerialInterfaceParameters();
void serialLineParser(char receiveData);
void serialReceiveCopy(char* destination, char *source);
void sendResponse(char status);
#endif /* SERIALCOMCONTROLLER_H_ */
